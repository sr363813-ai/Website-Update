# WebNova Solutions website upgrade

## Added to the existing project

- Responsive portfolio gallery with filters and concept case-study detail dialogs. The gallery clearly labels sample work as concepts, not completed client engagements.
- Dedicated service landing pages for web development, SEO, UI/UX, e-commerce, maintenance, branding, business automation, and ERP/CRM.
- Dynamic title, description, canonical, Open Graph and Twitter metadata for supported SPA routes.
- XML sitemap entries for the new public pages and a WebSite JSON-LD block.
- Google PageSpeed Insights / Lighthouse mobile audit UI for performance, accessibility, best practices, SEO, and selected checks.
- Guided project brief builder with an optional server-side Gemini assistant endpoint.
- Floating WhatsApp contact action and contextual WhatsApp links.
- Admin-only Analytics tab that shows local browser event diagnostics, plus basic page-view, audit, and project-assistant event tracking.
- Mobile workspace navigation for the admin/client dashboard.

## Enable the AI project assistant on Netlify

1. Deploy this project to Netlify (the project now includes `netlify.toml` and `netlify/functions/project-assistant.mjs`).
2. In Netlify site settings, add `GEMINI_API_KEY` as a **Functions runtime** environment variable. Never put this key in a `VITE_` variable or client-side source code.
3. Optionally set `GEMINI_MODEL` to a model available to your Google AI account. The current default is `gemini-2.5-flash`.
4. Redeploy after adding or changing environment variables.
5. Test `POST /api/project-assistant` using the project assistant UI. The function applies request validation and a per-IP rate limit.

If the site is deployed somewhere other than Netlify, the frontend still prepares a structured project brief, but the AI endpoint must be adapted to that host's server-side function system.

## SEO audit notes

The audit tool calls Google's PageSpeed Insights API from the browser and does not require this project to crawl arbitrary sites from its own server. API quota and availability are controlled by Google; if requests are throttled, configure a suitable API key and quota policy using a server-side proxy before production use. Scores are lab results, not a ranking guarantee.

## Analytics notes

The new admin Analytics tab is intentionally labelled as a local preview. Events are stored in `localStorage` in the current browser only; they are not cross-visitor analytics. To report actual sessions and conversions across visitors/devices, connect a privacy-reviewed analytics provider and its reporting API, and display the aggregated data through a secured server-side endpoint.

## Validation

- TypeScript/TSX syntax transpilation checks passed for the modified application files.
- Netlify function JavaScript syntax check passed.
- `public/sitemap.xml` parses as valid XML.
- A complete Vite production build could not be run in this environment because project dependencies were not installed and `npm install` timed out. Run `npm install`, `npm run lint`, and `npm run build` in the project environment before production deployment.
