# SEO and visual improvements

## Added in this update
- New responsive, dark-gradient growth section with clearer value proposition and project CTAs.
- Industry-use-case cards for growing businesses, retail/e-commerce, education, and professional services.
- Scannable benefits list covering mobile-first design, semantic page structure, accessibility, performance, and conversion journeys.
- Added WebSite structured data, locale/social metadata, and additional relevant meta keywords.
- Expanded sitemap to include public blog, certificate verification, privacy, and terms pages.

## Before launch / ongoing SEO checklist
1. Confirm the business name, phone number, social profile URLs, and canonical domain in `index.html` are correct.
2. Add real project case studies, original helpful blog posts, and descriptive image alt text. Do not publish invented testimonials or results.
3. Connect Google Search Console and Bing Webmaster Tools; submit `/sitemap.xml` and monitor indexing and Core Web Vitals.
4. Verify all public routes load correctly on direct navigation and that protected/admin routes are not indexed.
5. Use descriptive page titles and unique meta descriptions for each indexable page.
6. Compress large images, use appropriately sized formats, and test mobile performance and accessibility.
7. Track meaningful conversions (qualified enquiry, call booking) and review search performance monthly.

Meta keywords are included for completeness but are not a meaningful Google ranking factor. SEO cannot guarantee rankings; results depend on competition, content, technical health, and ongoing work.
