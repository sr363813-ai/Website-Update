# WebNova Solutions — Cloudflare deployment

This project is configured as a Cloudflare Worker with static assets. It preserves the React/Vite TypeScript source and serves the built website from `dist`. The Worker also handles `/api/project-assistant` so the AI project assistant can run on Cloudflare without a Netlify function.

## Deploy from your computer

1. Install Node.js 20 or newer.
2. Extract this project ZIP and open a terminal in the folder containing `package.json` and `wrangler.jsonc`.
3. Install dependencies:

   ```bash
   npm install
   ```

4. Sign in to Cloudflare:

   ```bash
   npx wrangler login
   ```

5. Build and deploy the site:

   ```bash
   npm run deploy:cloudflare
   ```

Wrangler will upload the built `dist` assets and deploy `src/worker.js`. Use the URL printed by Wrangler to test the site.

## Enable AI project recommendations (optional)

Without a Gemini key, the website and project brief builder still work, but live AI recommendations return a helpful configuration message and the client can retain its structured brief fallback.

Set the key as a Worker secret (never put it in a `VITE_` variable):

```bash
npx wrangler secret put GEMINI_API_KEY
```

Paste your Gemini API key when prompted, then redeploy:

```bash
npm run deploy:cloudflare
```

The model defaults to `gemini-2.5-flash`; it can be changed in `wrangler.jsonc` under `vars.GEMINI_MODEL`.

## Cloudflare dashboard alternative

For the `wrangler deploy` workflow, use a local terminal with Wrangler as above. Do not upload the entire TypeScript source folder using a static drag-and-drop asset uploader. The project needs the Vite build step first. If you only upload `dist` as static files, the frontend can load, but the Worker API route for the AI assistant will not be deployed with it.

## Notes

- The original site pages, service pages, SEO metadata, portfolio, audit UI, dashboard and existing Firebase/EmailJS integrations have been preserved.
- The original `netlify/` function and `netlify.toml` are retained as source files for compatibility with the earlier deployment target; Cloudflare uses `src/worker.js` and `wrangler.jsonc`.
- Firebase and EmailJS client-side integrations still require their corresponding Firebase/EmailJS settings to be valid for the relevant features.
- Local analytics are browser-local only; this deployment does not convert them into a centralized analytics service.
- Build verification must be run in an environment where npm can install the dependencies. The source package includes the build/deploy commands but does not include `node_modules`.
