interface Env {
  TURNSTILE_SECRET_KEY?: string;
}
interface Context {
  request: Request;
  env: Env;
}

export async function onRequestPost({ request, env }: Context): Promise<Response> {
  const corsHeaders = { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' };
  if (!env.TURNSTILE_SECRET_KEY) {
    return new Response(JSON.stringify({ success: false, error: 'CAPTCHA server secret is not configured.' }), { status: 503, headers: corsHeaders });
  }
  let body: { token?: string };
  try {
    body = await request.json() as { token?: string };
  } catch {
    return new Response(JSON.stringify({ success: false, error: 'Invalid request.' }), { status: 400, headers: corsHeaders });
  }
  if (!body.token) {
    return new Response(JSON.stringify({ success: false, error: 'Missing CAPTCHA token.' }), { status: 400, headers: corsHeaders });
  }
  const formData = new FormData();
  formData.set('secret', env.TURNSTILE_SECRET_KEY);
  formData.set('response', body.token);
  const ip = request.headers.get('CF-Connecting-IP');
  if (ip) formData.set('remoteip', ip);
  try {
    const verification = await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify', { method: 'POST', body: formData });
    const result = await verification.json() as { success?: boolean };
    return new Response(JSON.stringify({ success: result.success === true }), { status: result.success ? 200 : 403, headers: corsHeaders });
  } catch {
    return new Response(JSON.stringify({ success: false, error: 'CAPTCHA verification service unavailable.' }), { status: 502, headers: corsHeaders });
  }
}
