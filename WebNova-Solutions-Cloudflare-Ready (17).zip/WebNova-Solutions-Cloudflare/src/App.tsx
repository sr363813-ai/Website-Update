import { AIPlannerSection, BrandPromiseSection } from './components/AIPlannerSection.tsx';
import React, { useEffect, useState } from 'react';
import { Navbar } from './components/Navbar.tsx';
import { Hero } from './components/Hero.tsx';
import { WhyWebNovaAndAI } from './components/WhyWebNovaAndAI.tsx';
import { AICommandCenter } from './components/AICommandCenter.tsx';
import { ConnectedEcosystem } from './components/ConnectedEcosystem.tsx';
import { ExperienceLab } from './components/ExperienceLab.tsx';
import { AssociateEcosystem } from './components/AssociateEcosystem.tsx';
import { ValueProps } from './components/ValueProps.tsx';
import { AboutWebNova } from './components/AboutWebNova.tsx';
import { ServicesSection } from './components/ServicesSection.tsx';
import { SEOContentSection } from './components/SEOContentSection.tsx';
import { ProcessSection } from './components/ProcessSection.tsx';
import { FaqSection } from './components/FaqSection.tsx';
import { TestimonialsSection } from './components/TestimonialsSection.tsx';
import { ContactSection } from './components/ContactSection.tsx';
import { Footer } from './components/Footer.tsx';
import { UserPortalModal } from './components/UserPortalModal.tsx';
import { SupportHub } from './components/SupportHub.tsx';
import { ScheduleCall } from './components/ScheduleCall.tsx';
import { BlogSection } from './components/BlogSection.tsx';
import { CertificateVerificationPage } from './components/DocumentsAdminPanel.tsx';
import { FormSecurityAndCapture } from './components/FormSecurityAndCapture.tsx';
import { FirebaseAuthRoute } from './components/FirebaseAuthRoute.tsx';
import { ServiceRequestPrompt } from './components/ServiceRequestPrompt.tsx';
import { FreelancerComingSoon } from './components/FreelancerComingSoon.tsx';
import { GoogleReviewsSection } from './components/GoogleReviewsSection.tsx';
import { LegalPage } from './components/LegalPage.tsx';
import { FloatingWhatsApp, PortfolioSection, ProjectAssistantSection, SEOAuditSection, ServiceLandingPage, servicePages } from './components/GrowthFeatures.tsx';
import { trackSiteEvent } from './lib/siteAnalytics';

function NotFoundPage() {
  return (
    <main className="min-h-screen flex items-center justify-center px-6 py-16 bg-[#f8faff] text-[#071531] relative overflow-hidden">
      <div className="absolute -top-24 -right-16 w-80 h-80 rounded-full bg-violet-300/30 blur-3xl" />
      <div className="absolute -bottom-24 -left-16 w-80 h-80 rounded-full bg-cyan-300/30 blur-3xl" />
      <div className="relative z-10 max-w-xl text-center">
        <img src="/webnova-logo.png" alt="WebNova Solutions" className="w-44 mx-auto mb-8" />
        <p className="text-sm font-bold tracking-[0.28em] uppercase text-blue-600 mb-3">Error 404</p>
        <h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight mb-4">This page went digital… somewhere else.</h1>
        <p className="text-slate-600 leading-relaxed mb-8">The page you’re looking for may have moved, been renamed, or no longer exists.</p>
        <a href="/" className="inline-flex items-center justify-center rounded-xl px-6 py-3 text-white font-semibold bg-gradient-to-r from-blue-600 to-violet-600 shadow-lg shadow-blue-600/20 hover:-translate-y-0.5 transition-transform">Back to WebNova Home</a>
        <p className="text-xs text-slate-500 mt-8">WebNova Solutions · We build websites that grow businesses.</p>
      </div>
    </main>
  );
}

function BlogPage() {
  useEffect(() => {
    document.title = 'WebNova Insights Blog | Web Development, AI & Digital Growth';
    const description = 'Explore practical guides on website development, AI automation, SEO, digital marketing, and UI/UX design from WebNova Solutions.';
    let meta = document.querySelector<HTMLMetaElement>('meta[name="description"]');
    if (!meta) { meta = document.createElement('meta'); meta.name = 'description'; document.head.appendChild(meta); }
    meta.content = description;
    let canonical = document.querySelector<HTMLLinkElement>('link[rel="canonical"]');
    if (!canonical) { canonical = document.createElement('link'); canonical.rel = 'canonical'; document.head.appendChild(canonical); }
    canonical.href = 'https://webnovasolutions.co.in/blog';
  }, []);
  return <div className="min-h-screen bg-white text-slate-900">
    <header className="sticky top-0 z-40 border-b border-slate-100 bg-white/95 backdrop-blur-xl">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3 sm:px-6">
        <a href="/" aria-label="WebNova home"><img src="/webnova-logo.png" alt="WebNova Solutions" className="h-10 w-auto object-contain" /></a>
        <nav className="flex items-center gap-4 text-sm font-semibold sm:gap-7"><a href="/" className="text-slate-600 hover:text-blue-700">Home</a><a href="/blog" className="text-blue-700">Blog</a><a href="/#services" className="text-slate-600 hover:text-blue-700">Services</a><a href="/#contact" className="rounded-full bg-gradient-to-r from-blue-600 to-violet-600 px-4 py-2 text-white">Contact</a></nav>
      </div>
    </header>
    <BlogSection />
    <footer className="border-t border-slate-100 px-4 py-6 text-center text-xs text-slate-500">© WebNova Solutions · <a className="text-blue-700" href="/verify-certificate">Verify an intern certificate</a> · <a className="text-blue-700" href="/">Back to home</a></footer>
  </div>;
}

function HomePage() {
  const [userPhone, setUserPhone] = useState<string | null>(null);
  const [isPortalOpen, setIsPortalOpen] = useState(false);

  const handleLoginClick = () => {
    window.location.assign('/portal');
  };

  const handleLoginSuccess = (phone: string) => {
    setUserPhone(phone);
    setIsPortalOpen(true);
  };

  const handleLogout = () => {
    setUserPhone(null);
    setIsPortalOpen(false);
  };

  const handleStartProject = () => {
    const quoteElement = document.getElementById('quotation');
    if (quoteElement) {
      quoteElement.scrollIntoView({ behavior: 'smooth' });
    } else {
      const contact = document.getElementById('contact');
      contact?.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleExploreWork = () => {
    const services = document.getElementById('services');
    services?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleExploreAITools = () => {
    const aiSection = document.getElementById('ai-command');
    aiSection?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-white text-slate-800 selection:bg-blue-600 selection:text-slate-900">
      {/* Navigation */}
      <Navbar
        onOpenLogin={handleLoginClick}
        userPhone={userPhone}
        onLogout={handleLogout}
      />

      {/* Main Content */}
      <main>
        {/* 1. Hero */}
        <Hero
          onStartProject={handleStartProject}
          onExploreWork={handleExploreWork}
        />

        {/* 2. AI planner and brand promise sections inspired by the live WebNova site */}
        <AIPlannerSection />
        <BrandPromiseSection />

        {/* Existing Why WebNova section */}
        <WhyWebNovaAndAI onExploreAITools={handleExploreAITools} />

        {/* 3. AI Command Center */}
        <AICommandCenter />

        {/* 4. Connected Ecosystem */}
        <ConnectedEcosystem />

        {/* 5. Modern Experience Lab */}
        <ExperienceLab />

        {/* 6. Associate Ecosystem */}
        <AssociateEcosystem />

        {/* 8. Value Props */}
        <ValueProps />

        {/* 9. About WebNova & Interactive Device Mockup */}
        <AboutWebNova />

        {/* 10. Our Services */}
        <ServicesSection />

        {/* Search-friendly growth content, industry use cases, and conversion paths */}
        <SEOContentSection />

        {/* New concept portfolio and project case-study gallery */}
        <PortfolioSection />

        {/* Live Google PageSpeed / Lighthouse audit */}
        <SEOAuditSection />

        {/* Guided project brief builder for qualified enquiries */}
        <ProjectAssistantSection />

        {/* 12. Our Process */}
        <ProcessSection />

        {/* Full-width consultation booking section */}
        <ScheduleCall />

        {/* 13. FAQ */}
        <FaqSection />

        {/* 14. Client Testimonials */}
        <TestimonialsSection />

        {/* Google Reviews and customer feedback */}
        <GoogleReviewsSection />

        {/* 16. Contact Section */}
        <ContactSection onStartProject={handleStartProject} />
      </main>

      {/* Footer */}
      <Footer />

      {/* Persistent WhatsApp contact entry point */}
      <FloatingWhatsApp />

      {/* First-visit service enquiry prompt; submissions feed the Form Inbox capture. */}
      <ServiceRequestPrompt />

      {/* Floating animated chatbot and support-ticket form */}
      <SupportHub />

      {/* Logged-In User Dashboard Modal */}
      {userPhone && (
        <UserPortalModal
          isOpen={isPortalOpen}
          onClose={() => setIsPortalOpen(false)}
          phone={userPhone}
          onLogout={handleLogout}
        />
      )}
    </div>
  );
}


function FeaturePage({ title, children }: { title: string; children: React.ReactNode }) {
  return <div className="min-h-screen bg-white text-slate-900"><header className="sticky top-0 z-40 border-b border-slate-200 bg-white/95 backdrop-blur-xl"><div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6"><a href="/" className="font-extrabold tracking-tight text-[#071531]">WebNova <span className="text-violet-600">Solutions</span></a><nav className="flex items-center gap-4 text-sm font-semibold"><a href="/" className="text-slate-600 hover:text-blue-700">Home</a><a href="/blog" className="text-slate-600 hover:text-blue-700">Blog</a><a href="/#contact" className="rounded-xl bg-gradient-to-r from-blue-600 to-violet-600 px-4 py-2 text-white">Contact</a></nav></div></header><h1 className="sr-only">{title}</h1>{children}<footer className="border-t border-slate-200 px-4 py-7 text-center text-xs text-slate-500">© {new Date().getFullYear()} WebNova Solutions · <a href="/privacy-policy" className="underline">Privacy</a> · <a href="/terms-and-conditions" className="underline">Terms</a> · <a href="/" className="underline">Home</a></footer><FloatingWhatsApp /></div>;
}

function RouteMetadata({ pathname }: { pathname: string }) {
  useEffect(() => {
    trackSiteEvent('page_view');
    const serviceSlug = pathname.startsWith('/services/') ? pathname.split('/')[2] : '';
    const service = serviceSlug ? servicePages[serviceSlug] : undefined;
    const metadata: Record<string, { title: string; description: string; canonical: string }> = {
      '/': { title: 'WebNova Solutions | Website Development, SEO & AI Automation', description: 'Build a stronger digital presence with WebNova Solutions: responsive websites, UI/UX design, SEO, business software and automation.', canonical: 'https://webnovasolutions.co.in/' },
      '/blog': { title: 'WebNova Insights | Website Development, SEO & Digital Growth', description: 'Practical guides on web development, SEO, AI automation, digital marketing and user experience from WebNova Solutions.', canonical: 'https://webnovasolutions.co.in/blog' },
      '/portfolio': { title: 'Portfolio Concepts | WebNova Solutions', description: 'Explore WebNova Solutions concept showcases for business websites, e-commerce experiences and digital business tools.', canonical: 'https://webnovasolutions.co.in/portfolio' },
      '/seo-audit': { title: 'Free Website SEO Audit | WebNova Solutions', description: 'Run a mobile Lighthouse audit for performance, accessibility, best practices and SEO signals with WebNova Solutions.', canonical: 'https://webnovasolutions.co.in/seo-audit' },
      '/project-assistant': { title: 'Project Brief Assistant | WebNova Solutions', description: 'Organize your website, e-commerce, software or SEO project requirements into a clear brief for WebNova Solutions.', canonical: 'https://webnovasolutions.co.in/project-assistant' },
      '/verify-certificate': { title: 'Certificate Verification | WebNova Solutions', description: 'Verify a WebNova Solutions training or internship certificate using its certificate ID.', canonical: 'https://webnovasolutions.co.in/verify-certificate' },
      '/privacy-policy': { title: 'Privacy Policy | WebNova Solutions', description: 'Read how WebNova Solutions handles information and privacy on its website.', canonical: 'https://webnovasolutions.co.in/privacy-policy' },
      '/terms-and-conditions': { title: 'Terms and Conditions | WebNova Solutions', description: 'Review the website terms and conditions for WebNova Solutions.', canonical: 'https://webnovasolutions.co.in/terms-and-conditions' },
    };
    const info = service ? { title: `${service.title} | WebNova Solutions`, description: service.description, canonical: `https://webnovasolutions.co.in/services/${serviceSlug}` } : metadata[pathname];
    let robots = document.querySelector<HTMLMetaElement>('meta[name="robots"]');
    if (!robots) { robots = document.createElement('meta'); robots.name = 'robots'; document.head.appendChild(robots); }
    robots.content = ['/admin','/portal','/user'].includes(pathname) || (!info && pathname.startsWith('/services/')) ? 'noindex, nofollow' : 'index, follow, max-image-preview:large';
    if (!info) return;
    document.title = info.title;
    let description = document.querySelector<HTMLMetaElement>('meta[name="description"]');
    if (!description) { description = document.createElement('meta'); description.name = 'description'; document.head.appendChild(description); }
    description.content = info.description;
    let canonical = document.querySelector<HTMLLinkElement>('link[rel="canonical"]');
    if (!canonical) { canonical = document.createElement('link'); canonical.rel = 'canonical'; document.head.appendChild(canonical); }
    canonical.href = info.canonical;
    let ogTitle = document.querySelector<HTMLMetaElement>('meta[property="og:title"]');
    if (!ogTitle) { ogTitle = document.createElement('meta'); ogTitle.setAttribute('property', 'og:title'); document.head.appendChild(ogTitle); }
    ogTitle.content = info.title;
    let ogDescription = document.querySelector<HTMLMetaElement>('meta[property="og:description"]');
    if (!ogDescription) { ogDescription = document.createElement('meta'); ogDescription.setAttribute('property', 'og:description'); document.head.appendChild(ogDescription); }
    ogDescription.content = info.description;
    let ogUrl = document.querySelector<HTMLMetaElement>('meta[property="og:url"]');
    if (!ogUrl) { ogUrl = document.createElement('meta'); ogUrl.setAttribute('property', 'og:url'); document.head.appendChild(ogUrl); }
    ogUrl.content = info.canonical;
    let twitterTitle = document.querySelector<HTMLMetaElement>('meta[name="twitter:title"]');
    if (!twitterTitle) { twitterTitle = document.createElement('meta'); twitterTitle.name = 'twitter:title'; document.head.appendChild(twitterTitle); }
    twitterTitle.content = info.title;
    let twitterDescription = document.querySelector<HTMLMetaElement>('meta[name="twitter:description"]');
    if (!twitterDescription) { twitterDescription = document.createElement('meta'); twitterDescription.name = 'twitter:description'; document.head.appendChild(twitterDescription); }
    twitterDescription.content = info.description;
  }, [pathname]);
  return null;
}


export default function App() {
  const pathname = typeof window !== 'undefined' ? window.location.pathname.replace(/\/$/, '') || '/' : '/';
  let page: React.ReactNode;
  if (pathname === '/privacy-policy') page = <LegalPage kind="privacy" />;
  else if (pathname === '/terms-and-conditions') page = <LegalPage kind="terms" />;
  else if (pathname === '/freelancer') page = <FreelancerComingSoon />;
  else if (pathname === '/admin') page = <FirebaseAuthRoute expectedRole="admin" />;
  else if (pathname === '/blog') page = <BlogPage />;
  else if (pathname === '/portfolio') page = <FeaturePage title="Portfolio"><PortfolioSection /></FeaturePage>;
  else if (pathname === '/seo-audit') page = <FeaturePage title="SEO Audit"><SEOAuditSection /></FeaturePage>;
  else if (pathname === '/project-assistant') page = <FeaturePage title="Project Assistant"><ProjectAssistantSection /></FeaturePage>;
  else if (pathname.startsWith('/services/')) page = <ServiceLandingPage slug={pathname.split('/')[2] || ''} />;
  else if (pathname === '/verify-certificate') page = <CertificateVerificationPage />;
  else if (pathname === '/portal' || pathname === '/user') page = <FirebaseAuthRoute expectedRole="client" />;
  else if (!['/', '/index.html'].includes(pathname)) page = <NotFoundPage />;
  else page = <HomePage />;
  return <><RouteMetadata pathname={pathname === '/index.html' ? '/' : pathname} /><FormSecurityAndCapture />{page}</>;
}
