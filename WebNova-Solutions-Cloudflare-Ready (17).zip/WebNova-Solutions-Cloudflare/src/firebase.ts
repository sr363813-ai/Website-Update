import { initializeApp, getApps, type FirebaseApp } from 'firebase/app';
import { getAuth, type Auth } from 'firebase/auth';
import { getFirestore, type Firestore } from 'firebase/firestore';

/**
 * WebNova Solutions Firebase project: webnova-solutions-451a4.
 * Environment variables can override these defaults for another deployment.
 * Firebase web config is public by design; security belongs in Auth + Firestore Rules.
 */
const firebaseConfig = {
  apiKey: (import.meta.env.VITE_FIREBASE_API_KEY as string | undefined) || 'AIzaSyDi6W22hLnVzI4ahrgpqENsSAk9yB_7060',
  authDomain: (import.meta.env.VITE_FIREBASE_AUTH_DOMAIN as string | undefined) || 'webnova-solutions-451a4.firebaseapp.com',
  databaseURL: (import.meta.env.VITE_FIREBASE_DATABASE_URL as string | undefined) || 'https://webnova-solutions-451a4-default-rtdb.firebaseio.com',
  projectId: (import.meta.env.VITE_FIREBASE_PROJECT_ID as string | undefined) || 'webnova-solutions-451a4',
  storageBucket: (import.meta.env.VITE_FIREBASE_STORAGE_BUCKET as string | undefined) || 'webnova-solutions-451a4.firebasestorage.app',
  messagingSenderId: (import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID as string | undefined) || '61484456044',
  appId: (import.meta.env.VITE_FIREBASE_APP_ID as string | undefined) || '1:61484456044:web:7a1a8c62b9c34e2c212049',
  measurementId: (import.meta.env.VITE_FIREBASE_MEASUREMENT_ID as string | undefined) || 'G-924MHYMBF4',
};

const requiredConfig = [
  firebaseConfig.apiKey,
  firebaseConfig.authDomain,
  firebaseConfig.projectId,
  firebaseConfig.appId,
];
export const firebaseConfigured = requiredConfig.every(
  (value) => typeof value === 'string' && value.trim().length > 0 &&
    !value.includes('YOUR_') && !value.includes('MY_'),
);

let app: FirebaseApp | null = null;
if (firebaseConfigured) {
  app = getApps().length ? getApps()[0] : initializeApp(firebaseConfig);
}

export const firebaseApp = app;
export const auth: Auth | null = app ? getAuth(app) : null;
export const db: Firestore | null = app ? getFirestore(app) : null;
