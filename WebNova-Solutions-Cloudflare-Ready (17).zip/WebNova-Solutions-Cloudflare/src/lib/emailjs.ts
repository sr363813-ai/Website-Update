import emailjs from '@emailjs/browser';

const publicKey = import.meta.env.VITE_EMAILJS_PUBLIC_KEY as string | undefined;
const serviceId = import.meta.env.VITE_EMAILJS_SERVICE_ID as string | undefined;
const templates = {
  otp: import.meta.env.VITE_EMAILJS_OTP_TEMPLATE_ID as string | undefined,
  welcome: import.meta.env.VITE_EMAILJS_WELCOME_TEMPLATE_ID as string | undefined,
  feedback: import.meta.env.VITE_EMAILJS_FEEDBACK_TEMPLATE_ID as string | undefined,
  contact: import.meta.env.VITE_EMAILJS_CONTACT_TEMPLATE_ID as string | undefined,
};

export type EmailTemplate = keyof typeof templates;

export async function sendWebNovaEmail(template: EmailTemplate, params: Record<string, string>) {
  const templateId = templates[template];
  if (!publicKey || !serviceId || !templateId || [publicKey, serviceId, templateId].some(v => !v || v.startsWith('YOUR_'))) {
    throw new Error('Email delivery is not configured yet. Add the EmailJS public key, service ID, and template IDs to your deployment environment.');
  }
  return emailjs.send(serviceId, templateId, params, { publicKey });
}
