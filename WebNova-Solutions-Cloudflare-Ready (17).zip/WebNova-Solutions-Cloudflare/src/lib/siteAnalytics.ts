export type SiteEvent = { id: string; name: string; path: string; at: string };
const STORAGE_KEY = 'webnova_site_events_v1';

export function trackSiteEvent(name: string) {
  if (typeof window === 'undefined') return;
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    const existing: SiteEvent[] = raw ? JSON.parse(raw) : [];
    existing.push({ id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`, name, path: window.location.pathname, at: new Date().toISOString() });
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(existing.slice(-500)));
  } catch { /* Analytics must never interrupt the visitor's main task. */ }
}

export function readSiteEvents(): SiteEvent[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    const parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed.filter((event) => event && typeof event.name === 'string' && typeof event.at === 'string') : [];
  } catch { return []; }
}

export function clearSiteEvents() {
  if (typeof window !== 'undefined') window.localStorage.removeItem(STORAGE_KEY);
}
