import React, { useState } from 'react';
import { Lightbulb, Handshake, TrendingUp, Headphones, Bot, CheckCircle2, ArrowRight } from 'lucide-react';

interface WhyWebNovaAndAIProps {
  onExploreAITools: () => void;
}

export const WhyWebNovaAndAI: React.FC<WhyWebNovaAndAIProps> = ({ onExploreAITools }) => {
  const [plannerStep, setPlannerStep] = useState<number>(0);

  const steps = [
    { title: 'Plan', desc: 'AI-assisted scoping, stack selection & wireframe roadmapping' },
    { title: 'Build', desc: 'Clean TypeScript architecture, rapid component delivery' },
    { title: 'Launch', desc: 'Automated CI/CD pipelines, edge optimization & zero downtime' },
    { title: 'Grow', desc: 'Lead scoring, conversion monitoring & proactive iteration' },
  ];

  return (
    <section className="py-12 relative z-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          {/* Card 1: Our Promise: Why WebNova? */}
          <div className="lg:col-span-6 bg-slate-50/60 border border-slate-200/80 rounded-2xl p-7 sm:p-8 backdrop-blur-xl flex flex-col justify-between hover:border-slate-200/80 transition-all shadow-xl">
            <div>
              <span className="text-[11px] font-bold uppercase tracking-wider text-blue-700 block mb-2">
                Our Promise
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight mb-3">
                Why WebNova?
              </h2>
              <p className="text-sm text-slate-600 leading-relaxed mb-8">
                We combine creativity, technology and strategy to build digital solutions that are simple, scalable and built for real business impact.
              </p>
            </div>

            {/* 4 Pillars Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-6 border-t border-slate-200/60">
              <div className="flex flex-col items-center text-center p-3 rounded-xl bg-white/40 border border-slate-200/50 hover:border-blue-500/30 transition-colors">
                <div className="w-10 h-10 rounded-lg bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-700 mb-2">
                  <Lightbulb className="w-5 h-5" />
                </div>
                <span className="text-xs font-semibold text-slate-700 leading-tight">
                  Innovative Solutions
                </span>
              </div>

              <div className="flex flex-col items-center text-center p-3 rounded-xl bg-white/40 border border-slate-200/50 hover:border-indigo-500/30 transition-colors">
                <div className="w-10 h-10 rounded-lg bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400 mb-2">
                  <Handshake className="w-5 h-5" />
                </div>
                <span className="text-xs font-semibold text-slate-700 leading-tight">
                  Reliable Partnership
                </span>
              </div>

              <div className="flex flex-col items-center text-center p-3 rounded-xl bg-white/40 border border-slate-200/50 hover:border-cyan-500/30 transition-colors">
                <div className="w-10 h-10 rounded-lg bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-700 mb-2">
                  <TrendingUp className="w-5 h-5" />
                </div>
                <span className="text-xs font-semibold text-slate-700 leading-tight">
                  Scalable Growth
                </span>
              </div>

              <div className="flex flex-col items-center text-center p-3 rounded-xl bg-white/40 border border-slate-200/50 hover:border-purple-500/30 transition-colors">
                <div className="w-10 h-10 rounded-lg bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-700 mb-2">
                  <Headphones className="w-5 h-5" />
                </div>
                <span className="text-xs font-semibold text-slate-700 leading-tight">
                  Human Support
                </span>
              </div>
            </div>
          </div>

          {/* Card 2: AI-enabled WebNova: Smart tools. Real impact. */}
          <div className="lg:col-span-6 bg-gradient-to-br from-slate-900/90 via-slate-900/70 to-indigo-950/40 border border-indigo-500/20 rounded-2xl p-7 sm:p-8 backdrop-blur-xl flex flex-col justify-between hover:border-indigo-500/40 transition-all shadow-xl relative overflow-hidden">
            {/* Subtle light streak */}
            <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-[11px] font-bold uppercase tracking-wider text-indigo-400">
                  AI-enabled WebNova
                </span>
                <span className="text-[10px] bg-indigo-950 text-indigo-300 border border-indigo-500/30 font-semibold px-2 py-0.5 rounded-full">
                  Smart Tech
                </span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight mb-3">
                Smart tools. Real impact.
              </h2>
              <p className="text-sm text-slate-600 leading-relaxed mb-6">
                From AI-powered features to our intelligent project planner, we use technology to help you build faster, smarter and better.
              </p>

              <button
                onClick={onExploreAITools}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold shadow-md shadow-blue-600/30 transition-colors mb-6"
              >
                <span>Explore AI tools</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Sub-card: AI Project Planner */}
            <div className="bg-white border border-indigo-500/30 rounded-xl p-4 sm:p-5">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-indigo-600/20 border border-indigo-500/40 flex items-center justify-center text-indigo-400">
                    <Bot className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-white tracking-wide">
                      AI Project Planner
                    </h4>
                    <span className="text-[10px] text-slate-500">
                      Step {plannerStep + 1} of 4: {steps[plannerStep].title}
                    </span>
                  </div>
                </div>

                {/* Animated status tag */}
                <span className="text-[10px] font-mono font-medium text-emerald-400 bg-emerald-950/50 px-2 py-0.5 rounded border border-emerald-500/30">
                  Ready to deploy
                </span>
              </div>

              {/* Step pills */}
              <div className="grid grid-cols-4 gap-2 mb-3">
                {steps.map((st, idx) => (
                  <button
                    key={st.title}
                    onClick={() => setPlannerStep(idx)}
                    className={`flex items-center justify-center gap-1.5 py-1.5 px-2 rounded-lg text-xs font-semibold transition-all ${
                      plannerStep === idx
                        ? 'bg-blue-600 text-white shadow-sm'
                        : idx < plannerStep
                        ? 'bg-blue-50 text-blue-700 border border-blue-800/40'
                        : 'bg-slate-50/60 text-slate-500 border border-slate-200/40 hover:text-slate-700'
                    }`}
                  >
                    <CheckCircle2 className="w-3 h-3 shrink-0" />
                    <span>{st.title}</span>
                  </button>
                ))}
              </div>

              <div className="p-2.5 rounded-lg bg-white/70 border border-slate-200/80 text-[11px] text-slate-600">
                <span className="font-semibold text-blue-700">{steps[plannerStep].title}: </span>
                {steps[plannerStep].desc}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
