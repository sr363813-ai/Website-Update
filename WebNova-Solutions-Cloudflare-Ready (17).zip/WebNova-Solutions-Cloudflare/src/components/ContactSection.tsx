import React, { useState } from 'react';
import { Mail, Phone, MapPin, Send, CheckCircle2, ArrowRight } from 'lucide-react';
import { sendWebNovaEmail } from '../lib/emailjs.ts';

interface ContactSectionProps {
  onStartProject: () => void;
}

export const ContactSection: React.FC<ContactSectionProps> = ({ onStartProject }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [sentSuccess, setSentSuccess] = useState(false);
  const [sending, setSending] = useState(false);
  const [sendError, setSendError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim() || !message.trim() || sending) return;
    setSending(true);
    setSendError('');
    try {
      await sendWebNovaEmail('contact', { from_name: name.trim(), reply_to: email.trim(), email: email.trim(), message: message.trim(), to_email: 'support@webnovasolutions.co.in' });
      setSentSuccess(true);
    } catch (error) {
      setSendError(error instanceof Error ? error.message : 'Message could not be sent. Please email support@webnovasolutions.co.in directly.');
    } finally { setSending(false); }
  };

  return (
    <section id="contact" className="py-20 relative z-10 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          {/* Left info column */}
          <div className="lg:col-span-5">
            <span className="text-[11px] font-bold uppercase tracking-wider text-blue-700 block mb-2">
              Contact
            </span>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight mb-4">
              Have an idea? Let&apos;s build it.
            </h2>
            <p className="text-sm text-slate-600 leading-relaxed mb-8">
              We&apos;d love to hear from you. Send us your ideas, questions or feedback and we&apos;ll get back to you soon.
            </p>

            <div className="space-y-4">
              <a
                href="mailto:support@webnovasolutions.co.in"
                className="flex items-center gap-3.5 p-3 rounded-xl bg-slate-50/50 border border-slate-200/80 hover:border-blue-500/40 text-slate-600 hover:text-slate-900 transition-all group"
              >
                <div className="w-9 h-9 rounded-lg bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-700 group-hover:scale-105 transition-transform">
                  <Mail className="w-4 h-4" />
                </div>
                <div className="text-xs">
                  <span className="text-[10px] text-slate-500 block font-mono">Email Us</span>
                  <span className="font-semibold">support@webnovasolutions.co.in</span>
                </div>
              </a>

              <a
                href="tel:+918765051912"
                className="flex items-center gap-3.5 p-3 rounded-xl bg-slate-50/50 border border-slate-200/80 hover:border-blue-500/40 text-slate-600 hover:text-slate-900 transition-all group"
              >
                <div className="w-9 h-9 rounded-lg bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-700 group-hover:scale-105 transition-transform">
                  <Phone className="w-4 h-4" />
                </div>
                <div className="text-xs">
                  <span className="text-[10px] text-slate-500 block font-mono">Call Direct</span>
                  <span className="font-semibold">+91 87650 51912</span>
                </div>
              </a>

              <div className="flex items-center gap-3.5 p-3 rounded-xl bg-slate-50/50 border border-slate-200/80 text-slate-600">
                <div className="w-9 h-9 rounded-lg bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-700">
                  <MapPin className="w-4 h-4" />
                </div>
                <div className="text-xs">
                  <span className="text-[10px] text-slate-500 block font-mono">Headquarters</span>
                  <span className="font-semibold">Lucknow, Uttar Pradesh, India</span>
                </div>
              </div>
            </div>

            {/* "Your idea matters" Vector Card (matches screenshot) */}
            <div className="mt-8 p-5 rounded-2xl bg-gradient-to-r from-blue-950/40 via-purple-950/30 to-indigo-950/40 border border-blue-500/20 relative overflow-hidden">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-extrabold text-white tracking-wide mb-1">
                    Your idea matters.
                  </h4>
                  <p className="text-[11px] text-slate-300 leading-snug">
                    Every landmark enterprise began with a simple conversation.
                  </p>
                </div>
                <div className="w-12 h-12 rounded-xl bg-blue-500/20 border border-blue-400/30 flex items-center justify-center text-blue-700 shrink-0">
                  <Send className="w-6 h-6" />
                </div>
              </div>
            </div>
          </div>

          {/* Right Contact Form */}
          <div className="lg:col-span-7">
            <div className="p-7 sm:p-9 rounded-2xl bg-white border border-slate-200 backdrop-blur-xl shadow-2xl">
              <h3 className="text-lg font-bold text-slate-900 mb-6">Send us a message</h3>

              {sentSuccess ? (
                <div className="py-8 text-center animate-in fade-in">
                  <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto mb-3" />
                  <h4 className="text-base font-bold text-slate-900 mb-2">Message Dispatched!</h4>
                  <p className="text-xs text-slate-600 max-w-sm mx-auto mb-5 leading-relaxed">
                    Thank you {name}. We&apos;ve routed your inquiry to our lead architect. You&apos;ll hear back within 24 hours.
                  </p>
                  <button
                    onClick={() => {
                      setSentSuccess(false);
                      setName('');
                      setEmail('');
                      setMessage('');
                      setSendError('');
                    }}
                    className="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold"
                  >
                    Send another message
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="text-xs font-semibold text-slate-600 block mb-1.5">
                        Name
                      </label>
                      <input
                        type="text"
                        required
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="Your Full Name"
                        className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200/80 rounded-xl text-xs text-slate-900 placeholder-slate-500 focus:outline-none focus:border-blue-500"
                      />
                    </div>
                    <div>
                      <label className="text-xs font-semibold text-slate-600 block mb-1.5">
                        Email
                      </label>
                      <input
                        type="email"
                        required
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="name@company.com"
                        className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200/80 rounded-xl text-xs text-slate-900 placeholder-slate-500 focus:outline-none focus:border-blue-500"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-slate-600 block mb-1.5">
                      Messages
                    </label>
                    <textarea
                      required
                      rows={4}
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      placeholder="Share your goals, project details, or questions..."
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200/80 rounded-xl text-xs text-slate-900 placeholder-slate-500 focus:outline-none focus:border-blue-500 resize-none"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3 rounded-xl bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white font-semibold text-xs shadow-lg shadow-blue-600/30 transition-all flex items-center justify-center gap-2"
                  >
                    <span>{sending ? 'Sending…' : 'Send Message'}</span>
                    <Send className="w-3.5 h-3.5" />
                  </button>
                  {sendError && <p role="alert" className="rounded-lg border border-rose-200 bg-rose-50 p-3 text-xs leading-5 text-rose-700">{sendError}</p>}
                </form>
              )}
            </div>
          </div>
        </div>

        {/* Big Bottom Banner: "Ready to build something great?" (matches screenshot) */}
        <div className="mt-16 p-8 sm:p-10 rounded-3xl bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-700 text-white flex flex-col sm:flex-row items-center justify-between gap-6 shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-80 h-80 bg-white/10 rounded-full blur-2xl pointer-events-none" />

          <div className="relative z-10 text-center sm:text-left">
            <h3 className="text-2xl sm:text-3xl font-extrabold tracking-tight mb-2">
              Ready to build something great?
            </h3>
            <p className="text-xs sm:text-sm text-blue-100 max-w-lg">
              Let&apos;s build software that accelerates growth and delivers sustainable competitive advantage.
            </p>
          </div>

          <button
            onClick={onStartProject}
            className="relative z-10 px-7 py-3.5 rounded-xl bg-white hover:bg-slate-100 text-slate-950 font-bold text-xs sm:text-sm shadow-xl transition-all flex items-center gap-2 shrink-0 group transform hover:-translate-y-0.5"
          >
            <span>Start a project</span>
            <ArrowRight className="w-4 h-4 text-blue-600 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>
      </div>
    </section>
  );
};
