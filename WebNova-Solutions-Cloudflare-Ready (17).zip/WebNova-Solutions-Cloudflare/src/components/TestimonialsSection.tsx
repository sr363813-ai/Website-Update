import React from 'react';
import { Star, Quote } from 'lucide-react';

export const TestimonialsSection: React.FC = () => {
  const testimonials = [
    {
      name: 'Ananya Sharma',
      role: 'Founder',
      company: 'Bloom & Co.',
      quote:
        'WebNova transformed our ideas into a beautiful website. The team is professional, responsive and truly understands business needs.',
      rating: 5,
      avatarColor: 'from-pink-500 to-rose-600',
    },
    {
      name: 'Rohit Mehta',
      role: 'Operations Head',
      company: 'Nexus Systems',
      quote:
        'Their ERP solution streamlined our operations and saved us hours every week. Highly recommended!',
      rating: 5,
      avatarColor: 'from-blue-500 to-indigo-600',
    },
    {
      name: 'Priya Nair',
      role: 'CEO',
      company: 'GrowthWave',
      quote:
        'The AI tools and support from WebNova have been a game changer for our growth. Fantastic team!',
      rating: 5,
      avatarColor: 'from-purple-500 to-cyan-500',
    },
  ];

  return (
    <section id="testimonials" className="py-20 relative z-10 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-14">
          <span className="text-[11px] font-bold uppercase tracking-wider text-blue-700 block mb-2">
            Client Testimonials
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight mb-4">
            Trusted by businesses, loved by clients.
          </h2>
          <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
            Here&apos;s what our clients say about working with us.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {testimonials.map((t) => (
            <div
              key={t.name}
              className="p-7 rounded-2xl bg-white/80 border border-slate-200/80 backdrop-blur-xl hover:border-blue-500/30 transition-all flex flex-col justify-between group hover:-translate-y-1 shadow-lg"
            >
              <div>
                {/* 5-star rating */}
                <div className="flex items-center gap-1 mb-5">
                  {[...Array(t.rating)].map((_, i) => (
                    <Star
                      key={i}
                      className="w-4 h-4 fill-amber-400 text-amber-400"
                    />
                  ))}
                </div>

                <Quote className="w-6 h-6 text-slate-600 mb-3 group-hover:text-blue-700 transition-colors" />

                <p className="text-xs sm:text-sm text-slate-700 leading-relaxed mb-6 italic">
                  &ldquo;{t.quote}&rdquo;
                </p>
              </div>

              <div className="flex items-center gap-3 pt-4 border-t border-slate-200/80">
                <div
                  className={`w-9 h-9 rounded-full bg-gradient-to-tr ${t.avatarColor} flex items-center justify-center text-white text-xs font-bold shrink-0 shadow-md`}
                >
                  {t.name
                    .split(' ')
                    .map((n) => n[0])
                    .join('')}
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-900">{t.name}</h4>
                  <p className="text-[11px] text-slate-500">
                    {t.role}, <span className="text-blue-700 font-medium">{t.company}</span>
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
