import React, { useEffect, useMemo, useState } from 'react';
import { Download, Search, Trash2, Inbox, RefreshCw } from 'lucide-react';
import { FORM_SUBMISSIONS_KEY, FormSubmission, readFormSubmissions } from './FormSecurityAndCapture';
import { collection, deleteDoc, doc, limit, onSnapshot, orderBy, query } from 'firebase/firestore';
import { db, firebaseConfigured } from '../firebase';

const card = 'rounded-2xl border border-slate-200 bg-white p-5 shadow-sm';
export function FormInboxPanel() {
  const [items, setItems] = useState<FormSubmission[]>(readFormSubmissions);
  const [query, setQuery] = useState('');
  const [selected, setSelected] = useState<FormSubmission | null>(null);
  const [cloudMode, setCloudMode] = useState(false);
  const [cloudError, setCloudError] = useState('');
  const refresh = () => setItems(readFormSubmissions());
  useEffect(() => {
    const update = () => refresh();
    window.addEventListener('webnova-form-submission', update);
    window.addEventListener('storage', update);
    let unsubscribe: (() => void) | undefined;
    if (firebaseConfigured && db) {
      const q = query(collection(db, 'formSubmissions'), orderBy('createdAt', 'desc'), limit(500));
      unsubscribe = onSnapshot(q, (snapshot) => {
        const remote: FormSubmission[] = snapshot.docs.map((entry) => {
          const value = entry.data();
          const created = value.createdAt?.toDate?.();
          return { id: String(value.id || entry.id), firestoreDocId: entry.id, submittedAt: created ? created.toISOString() : String(value.submittedAt || ''), page: String(value.page || ''), formName: String(value.formName || 'Website form'), fields: (value.fields || {}) as Record<string, string> };
        });
        const remoteIds = new Set(remote.map(item => item.id));
        const localOnly = readFormSubmissions().filter(item => !remoteIds.has(item.id));
        setItems([...remote, ...localOnly]); setCloudMode(true); setCloudError('');
      }, (error) => { setCloudError(error.message || 'Unable to load cloud submissions. Check Firestore rules and admin role.'); setCloudMode(false); });
    }
    return () => { unsubscribe?.(); window.removeEventListener('webnova-form-submission', update); window.removeEventListener('storage', update); };
  }, []);
  const filtered = useMemo(() => items.filter(item => `${item.id} ${item.page} ${item.formName} ${Object.values(item.fields).join(' ')}`.toLowerCase().includes(query.toLowerCase())), [items, query]);
  const exportCsv = () => {
    const headers = ['id', 'submittedAt', 'page', 'formName', 'fields'];
    const rows = filtered.map(item => [item.id, item.submittedAt, item.page, item.formName, JSON.stringify(item.fields)]);
    const csv = [headers, ...rows].map(row => row.map(value => `"${String(value).replace(/"/g, '""')}"`).join(',')).join('\r\n');
    const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8;' }));
    const a = document.createElement('a'); a.href = url; a.download = 'webnova-form-inbox.csv'; a.click(); URL.revokeObjectURL(url);
  };
  const remove = async (id: string) => { const item = items.find(entry => entry.id === id); if (item?.firestoreDocId && db) { try { await deleteDoc(doc(db, 'formSubmissions', item.firestoreDocId)); } catch (error) { setCloudError(error instanceof Error ? error.message : 'Could not delete cloud submission.'); return; } } const next = items.filter(entry => entry.id !== id); localStorage.setItem(FORM_SUBMISSIONS_KEY, JSON.stringify(next.filter(entry => !entry.firestoreDocId))); setItems(next); if (selected?.id === id) setSelected(null); };
  return <div className="space-y-5">
    <section className={`${card} bg-gradient-to-r from-[#071531] via-blue-950 to-violet-950 text-white`}>
      <div className="flex flex-wrap items-start justify-between gap-4"><div><div className="flex items-center gap-2 text-cyan-300"><Inbox size={18}/><span className="text-xs font-bold uppercase tracking-[.2em]">Website submissions</span></div><h2 className="mt-3 text-2xl font-extrabold">Form Inbox</h2><p className="mt-2 max-w-2xl text-sm leading-6 text-blue-100">Review enquiries, quotes, booking requests, newsletter signups, support forms and other captured website form submissions.</p></div><div className="flex gap-2"><button onClick={refresh} className="inline-flex items-center gap-2 rounded-xl border border-white/20 px-4 py-2 text-sm font-semibold hover:bg-white/10"><RefreshCw size={15}/> Refresh</button><button onClick={exportCsv} className="inline-flex items-center gap-2 rounded-xl bg-white px-4 py-2 text-sm font-bold text-blue-950"><Download size={15}/> Export CSV</button></div></div>
      <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-3"><div className="rounded-xl border border-white/10 bg-white/5 p-4"><p className="text-xs text-blue-200">Total submissions</p><p className="mt-1 text-2xl font-extrabold">{items.length}</p></div><div className="rounded-xl border border-white/10 bg-white/5 p-4"><p className="text-xs text-blue-200">Today</p><p className="mt-1 text-2xl font-extrabold">{items.filter(i => new Date(i.submittedAt).toDateString() === new Date().toDateString()).length}</p></div><div className="col-span-2 rounded-xl border border-amber-300/20 bg-amber-400/10 p-4 sm:col-span-1"><p className="text-xs text-amber-100">Storage mode</p><p className="mt-1 text-sm font-bold">{cloudMode ? 'Firebase / shared inbox' : 'This browser only'}</p></div></div>
    </section>
    {cloudError && <p role="alert" className="rounded-xl border border-rose-200 bg-rose-50 p-3 text-sm text-rose-800">{cloudError}</p>}
    <section className={card}>
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3"><div><h3 className="font-extrabold">Captured form entries</h3><p className="mt-1 text-xs text-slate-500">Passwords, OTPs and secret/token fields are intentionally excluded.</p></div><label className="flex items-center gap-2 rounded-xl border border-slate-200 px-3"><Search size={15} className="text-slate-400"/><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search submissions" className="w-48 py-2 text-sm outline-none"/></label></div>
      {filtered.length ? <div className="space-y-3">{filtered.map(item => <article key={item.id} className="rounded-xl border border-slate-200 p-4 transition hover:border-blue-200 hover:bg-blue-50/30"><div className="flex flex-wrap items-start justify-between gap-3"><div className="min-w-0 flex-1"><div className="flex flex-wrap items-center gap-2"><h4 className="font-bold text-slate-900">{item.formName}</h4><span className="rounded-full bg-blue-50 px-2 py-1 text-[10px] font-bold text-blue-700">{item.page}</span></div><p className="mt-1 text-xs text-slate-500">{item.id} · {new Date(item.submittedAt).toLocaleString()}</p><div className="mt-3 flex flex-wrap gap-2">{Object.entries(item.fields).slice(0, 4).map(([key, value]) => <span key={key} className="max-w-full truncate rounded-lg bg-slate-100 px-2 py-1 text-xs text-slate-700"><strong>{key}:</strong> {value}</span>)}</div></div><div className="flex gap-2"><button onClick={() => setSelected(selected?.id === item.id ? null : item)} className="rounded-lg border border-slate-200 px-3 py-2 text-xs font-bold text-blue-700">{selected?.id === item.id ? 'Hide details' : 'View details'}</button><button onClick={() => remove(item.id)} title="Delete submission" className="rounded-lg border border-rose-100 p-2 text-rose-600"><Trash2 size={15}/></button></div></div>{selected?.id === item.id && <div className="mt-4 rounded-xl bg-slate-50 p-4"><dl className="grid gap-3 sm:grid-cols-2">{Object.entries(item.fields).map(([key, value]) => <div key={key} className="min-w-0"><dt className="text-xs font-bold uppercase tracking-wide text-slate-500">{key}</dt><dd className="mt-1 break-words text-sm text-slate-800">{value}</dd></div>)}</dl></div>}</article>)}</div> : <div className="py-12 text-center"><Inbox size={32} className="mx-auto text-slate-300"/><h3 className="mt-3 font-bold">No form submissions found</h3><p className="mt-1 text-sm text-slate-500">Once visitors submit a form, entries appear here. Configure Firebase and deploy the included Firestore rules to share submissions across devices.</p></div>}
    </section>
    <p className="rounded-xl border border-amber-200 bg-amber-50 p-4 text-xs leading-5 text-amber-900"><strong>Security note:</strong> passwords, OTPs, tokens, and payment secrets are excluded from capture. For production, enable server-verified Turnstile and deploy the supplied Firestore security rules. Public submissions are write-only; only an authenticated admin role can read or delete them.</p>
  </div>;
}
