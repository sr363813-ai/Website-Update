import React, { useState } from 'react';
import { X, CheckCircle2, Clock, FileText, Send, User, ShieldCheck, Download, ArrowUpRight } from 'lucide-react';
import { Logo } from './Logo.tsx';

interface UserPortalModalProps {
  isOpen: boolean;
  onClose: () => void;
  phone: string;
  onLogout: () => void;
}

export const UserPortalModal: React.FC<UserPortalModalProps> = ({
  isOpen,
  onClose,
  phone,
  onLogout,
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'deliverables' | 'invoices' | 'support'>('overview');
  const [supportMessage, setSupportMessage] = useState('');
  const [messages, setMessages] = useState<{ sender: 'user' | 'agent'; text: string; time: string }[]>([
    {
      sender: 'agent',
      text: 'Hello! Welcome to your WebNova Client Workspace. Your sprint 2 milestone is currently ahead of schedule.',
      time: '10:14 AM',
    },
  ]);

  if (!isOpen) return null;

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!supportMessage.trim()) return;
    const newMsg = { sender: 'user' as const, text: supportMessage, time: 'Just now' };
    setMessages((prev) => [...prev, newMsg]);
    setSupportMessage('');

    setTimeout(() => {
      setMessages((prev) => [
        ...prev,
        {
          sender: 'agent',
          text: 'Acknowledged! Our lead architect Vikram Sen is reviewing this note and will push the update to staging.',
          time: 'Just now',
        },
      ]);
    }, 1000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-white border border-blue-500/40 rounded-3xl max-w-4xl w-full max-h-[92vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-50/90 border-b border-slate-200 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-4">
            <Logo size="sm" />
            <div className="h-4 w-px bg-slate-700 hidden sm:block" />
            <div className="hidden sm:flex items-center gap-2">
              <span className="text-xs font-semibold text-slate-900">Client Portal</span>
              <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-500/30">
                Active Session
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <span className="text-xs font-mono text-slate-500 hidden sm:inline">{phone}</span>
            <button
              onClick={onLogout}
              className="px-2.5 py-1 text-xs text-rose-400 hover:text-rose-300 hover:bg-rose-950/40 rounded transition-colors"
            >
              Logout
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-500 hover:text-white rounded-lg hover:bg-slate-100"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-200 bg-white/60 px-6 shrink-0 overflow-x-auto">
          {[
            { id: 'overview', label: 'Project Overview' },
            { id: 'deliverables', label: 'Deliverables & Code' },
            { id: 'invoices', label: 'Invoices & Milestones' },
            { id: 'support', label: 'Direct Architect Chat' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as typeof activeTab)}
              className={`py-3 px-4 text-xs font-semibold border-b-2 transition-all whitespace-nowrap ${
                activeTab === tab.id
                  ? 'border-blue-500 text-blue-700 bg-blue-500/5'
                  : 'border-transparent text-slate-500 hover:text-white'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        <div className="p-6 overflow-y-auto flex-1">
          {activeTab === 'overview' && (
            <div className="space-y-6">
              {/* Active Project Banner */}
              <div className="p-5 rounded-2xl bg-gradient-to-r from-blue-950/60 via-slate-900 to-indigo-950/60 border border-blue-500/30">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
                  <div>
                    <span className="text-[10px] font-mono text-blue-700 uppercase tracking-widest block mb-1">
                      Project WN-9024 · Enterprise Tier
                    </span>
                    <h3 className="text-lg font-bold text-slate-900">
                      Next-Gen E-Commerce & ERP Cloud Migration
                    </h3>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-1 rounded-full bg-blue-500/20 text-blue-700 text-xs font-semibold border border-blue-500/30">
                      Sprint 2 of 4
                    </span>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs text-slate-600">
                    <span>Overall Project Completion</span>
                    <span className="font-mono text-cyan-700 font-bold">68%</span>
                  </div>
                  <div className="w-full h-2 bg-white rounded-full overflow-hidden">
                    <div className="w-[68%] h-full bg-gradient-to-r from-blue-500 to-cyan-400 rounded-full" />
                  </div>
                </div>
              </div>

              {/* Sprint Roadmap items */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-4 rounded-xl bg-slate-50/60 border border-slate-200">
                  <div className="flex items-center gap-2 text-xs font-bold text-emerald-400 mb-1">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Sprint 1: Architecture & UI</span>
                  </div>
                  <p className="text-[11px] text-slate-500">Design systems, Figma tokens, high-speed Vite + React shell.</p>
                  <span className="text-[10px] text-slate-500 font-mono mt-2 block">Completed 04 Oct</span>
                </div>

                <div className="p-4 rounded-xl bg-slate-50/60 border border-blue-500/30 bg-blue-950/20">
                  <div className="flex items-center gap-2 text-xs font-bold text-blue-700 mb-1">
                    <Clock className="w-4 h-4" />
                    <span>Sprint 2: ERP Integration</span>
                  </div>
                  <p className="text-[11px] text-slate-600">Live inventory syncing, ledger database, role authorizations.</p>
                  <span className="text-[10px] text-cyan-700 font-mono mt-2 block">In Progress (Deploying Oct 18)</span>
                </div>

                <div className="p-4 rounded-xl bg-slate-50/60 border border-slate-200">
                  <div className="flex items-center gap-2 text-xs font-bold text-slate-500 mb-1">
                    <Clock className="w-4 h-4" />
                    <span>Sprint 3: AI Pipeline & Testing</span>
                  </div>
                  <p className="text-[11px] text-slate-500">Lead qualification scoring, automated email drip rules.</p>
                  <span className="text-[10px] text-slate-500 font-mono mt-2 block">Scheduled Oct 25</span>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'deliverables' && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-slate-50/60 border border-slate-200 flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-bold text-slate-900 mb-0.5">Staging Environment Deployment</h4>
                  <p className="text-[11px] text-slate-500">https://staging.alpha-webnova.dev</p>
                </div>
                <a
                  href="#hero"
                  className="px-3 py-1.5 rounded-lg bg-blue-600 text-white text-xs font-semibold flex items-center gap-1.5 hover:bg-blue-500"
                >
                  <span>Open Preview</span>
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </a>
              </div>

              <div className="p-4 rounded-xl bg-slate-50/60 border border-slate-200 flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-bold text-slate-900 mb-0.5">Figma System Master File (v3.2)</h4>
                  <p className="text-[11px] text-slate-500">48 Component screens & complete token guide</p>
                </div>
                <button className="px-3 py-1.5 rounded-lg bg-slate-100 text-slate-700 text-xs font-semibold flex items-center gap-1.5 hover:bg-slate-700">
                  <Download className="w-3.5 h-3.5" />
                  <span>Download Assets</span>
                </button>
              </div>

              <div className="p-4 rounded-xl bg-slate-50/60 border border-slate-200 flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-bold text-slate-900 mb-0.5">Database Schema & API Specifications</h4>
                  <p className="text-[11px] text-slate-500">OpenAPI 3.1 & PostgreSQL Migrations</p>
                </div>
                <button className="px-3 py-1.5 rounded-lg bg-slate-100 text-slate-700 text-xs font-semibold flex items-center gap-1.5 hover:bg-slate-700">
                  <Download className="w-3.5 h-3.5" />
                  <span>Download Spec</span>
                </button>
              </div>
            </div>
          )}

          {activeTab === 'invoices' && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-slate-50/60 border border-slate-200 flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs font-bold text-slate-900">Invoice #INV-2024-081</span>
                    <span className="text-[10px] text-emerald-400 bg-emerald-950/70 border border-emerald-500/30 px-2 py-0.5 rounded font-mono">
                      PAID
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500">Milestone 1: Project Kickoff & UI System</p>
                </div>
                <div className="text-right">
                  <div className="text-xs font-bold text-white font-mono">₹ 45,000</div>
                  <button className="text-[10px] text-blue-700 hover:underline">Download PDF</button>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-slate-50/60 border border-blue-500/30 flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs font-bold text-slate-900">Invoice #INV-2024-099</span>
                    <span className="text-[10px] text-cyan-700 bg-cyan-950/70 border border-cyan-500/30 px-2 py-0.5 rounded font-mono">
                      DUE UPON SPRINT 2 COMPLETION
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500">Milestone 2: ERP Integration & Database Engine</p>
                </div>
                <div className="text-right">
                  <div className="text-xs font-bold text-white font-mono">₹ 45,000</div>
                  <button className="text-[10px] text-blue-700 hover:underline">View Proforma</button>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'support' && (
            <div className="flex flex-col h-[340px]">
              <div className="flex-1 space-y-3 overflow-y-auto pr-2 mb-4">
                {messages.map((m, idx) => (
                  <div
                    key={idx}
                    className={`flex flex-col ${
                      m.sender === 'user' ? 'items-end' : 'items-start'
                    }`}
                  >
                    <div
                      className={`max-w-md p-3 rounded-xl text-xs leading-relaxed ${
                        m.sender === 'user'
                          ? 'bg-blue-600 text-white rounded-br-none'
                          : 'bg-slate-50 border border-slate-200 text-slate-700 rounded-bl-none'
                      }`}
                    >
                      {m.text}
                    </div>
                    <span className="text-[9px] text-slate-500 font-mono mt-1">{m.time}</span>
                  </div>
                ))}
              </div>

              <form onSubmit={handleSendMessage} className="flex gap-2">
                <input
                  type="text"
                  value={supportMessage}
                  onChange={(e) => setSupportMessage(e.target.value)}
                  placeholder="Message your dedicated Solutions Architect..."
                  className="flex-1 px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:border-blue-500"
                />
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold flex items-center gap-1.5"
                >
                  <span>Send</span>
                  <Send className="w-3.5 h-3.5" />
                </button>
              </form>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
