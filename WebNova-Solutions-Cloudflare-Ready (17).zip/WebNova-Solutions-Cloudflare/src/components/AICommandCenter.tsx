import React, { useState } from 'react';
import { Target, Calculator, RefreshCw, ShieldCheck, Check, Sparkles, ChevronRight, X } from 'lucide-react';

export const AICommandCenter: React.FC = () => {
  const [selectedTool, setSelectedTool] = useState<string | null>(null);

  // Tool 1 state: Lead Scoring
  const [leadIndustry, setLeadIndustry] = useState('E-commerce');
  const [leadBudget, setLeadBudget] = useState('₹ 1,00,000+');
  const [leadTimeline, setLeadTimeline] = useState('Immediate (< 1 month)');

  // Tool 2 state: Quote Assistant
  const [quoteType, setQuoteType] = useState('Web App + ERP');
  const [quotePages, setQuotePages] = useState('5-10 Pages');

  // Tool 3 state: Auto Follow Up
  const [flowActive, setFlowActive] = useState(true);

  // Tool 4 state: User Portal
  const [portalRole, setPortalRole] = useState<'Client' | 'Manager' | 'Admin'>('Client');

  const tools = [
    {
      id: 'lead-scoring',
      title: 'AI Lead Scoring',
      description: 'Find high-potential leads automatically.',
      icon: <Target className="w-5 h-5 text-purple-700" />,
      color: 'from-purple-500/10 to-purple-600/20 border-purple-500/30',
      badge: 'Predictive NLP',
    },
    {
      id: 'quote-assistant',
      title: 'Smart Quote Assistant',
      description: 'Generate quotes in seconds.',
      icon: <Calculator className="w-5 h-5 text-cyan-700" />,
      color: 'from-cyan-500/10 to-cyan-600/20 border-cyan-500/30',
      badge: 'Instant Est.',
    },
    {
      id: 'follow-up',
      title: 'Auto Follow-Up Flow',
      description: 'Keep your pipeline active.',
      icon: <RefreshCw className="w-5 h-5 text-blue-700" />,
      color: 'from-blue-500/10 to-blue-600/20 border-blue-500/30',
      badge: 'Automated Drips',
    },
    {
      id: 'user-portal',
      title: 'Secure User Portal',
      description: 'Role-based access and security.',
      icon: <ShieldCheck className="w-5 h-5 text-emerald-400" />,
      color: 'from-emerald-500/10 to-emerald-600/20 border-emerald-500/30',
      badge: '256-bit Auth',
    },
  ];

  return (
    <section id="ai-command" className="py-20 relative z-10 bg-white">
      {/* Background radial highlight */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-4xl h-72 bg-blue-600/5 blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-14">
          <span className="text-[11px] font-bold uppercase tracking-wider text-blue-700 block mb-2">
            AI Command Center
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight mb-4">
            Smarter work. Powered by AI.
          </h2>
          <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
            Our AI command center helps you find leads, create quotes, follow up automatically and manage users — all in one place.
          </p>
        </div>

        {/* 4 Interactive Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {tools.map((tool) => (
            <div
              key={tool.id}
              onClick={() => setSelectedTool(selectedTool === tool.id ? null : tool.id)}
              className={`p-6 rounded-2xl border backdrop-blur-xl transition-all cursor-pointer group flex flex-col justify-between ${
                selectedTool === tool.id
                  ? 'bg-slate-50 border-blue-400 ring-2 ring-blue-500/30 shadow-xl shadow-blue-500/10 -translate-y-1'
                  : 'bg-slate-50/50 border-slate-200/80 hover:border-slate-200 hover:bg-white hover:-translate-y-0.5'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-4">
                  <div className="w-11 h-11 rounded-xl bg-slate-100/80 border border-slate-200/60 flex items-center justify-center group-hover:scale-110 transition-transform">
                    {tool.icon}
                  </div>
                  <span className="text-[10px] font-mono text-slate-500 bg-white/60 px-2 py-0.5 rounded border border-slate-200">
                    {tool.badge}
                  </span>
                </div>

                <h3 className="text-base font-bold text-slate-900 mb-2 group-hover:text-blue-700 transition-colors">
                  {tool.title}
                </h3>
                <p className="text-xs text-slate-500 leading-relaxed mb-4">
                  {tool.description}
                </p>
              </div>

              <div className="flex items-center justify-between pt-3 border-t border-slate-200/60 text-xs text-blue-700 font-medium">
                <span>{selectedTool === tool.id ? 'Close simulator' : 'Try simulator'}</span>
                <ChevronRight
                  className={`w-4 h-4 transition-transform ${
                    selectedTool === tool.id ? 'rotate-90' : 'group-hover:translate-x-1'
                  }`}
                />
              </div>
            </div>
          ))}
        </div>

        {/* Live Interactive Simulator Drawer */}
        {selectedTool && (
          <div className="mt-8 p-6 sm:p-8 rounded-2xl bg-white border border-blue-500/40 shadow-2xl animate-in fade-in slide-in-from-top-4 duration-200">
            <div className="flex items-center justify-between pb-4 mb-6 border-b border-slate-200">
              <div className="flex items-center gap-3">
                <Sparkles className="w-5 h-5 text-blue-700 animate-spin" />
                <h4 className="text-base font-bold text-slate-900">
                  Interactive Simulator: {tools.find((t) => t.id === selectedTool)?.title}
                </h4>
              </div>
              <button
                onClick={() => setSelectedTool(null)}
                className="p-1 text-slate-500 hover:text-white rounded-lg hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Sub-simulator 1: AI Lead Scoring */}
            {selectedTool === 'lead-scoring' && (
              <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
                <div className="md:col-span-7 space-y-4">
                  <div>
                    <label className="text-xs font-semibold text-slate-600 block mb-1.5">
                      Target Industry
                    </label>
                    <div className="flex flex-wrap gap-2">
                      {['E-commerce', 'SaaS & Tech', 'Healthcare', 'Real Estate'].map((ind) => (
                        <button
                          key={ind}
                          onClick={() => setLeadIndustry(ind)}
                          className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                            leadIndustry === ind
                              ? 'bg-blue-600 text-white shadow-sm'
                              : 'bg-slate-100 text-slate-600 hover:bg-slate-700'
                          }`}
                        >
                          {ind}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-slate-600 block mb-1.5">
                      Declared Budget Range
                    </label>
                    <div className="flex flex-wrap gap-2">
                      {['₹ 25,000 - 50,000', '₹ 50,000 - 1,00,000', '₹ 1,00,000+'].map((bg) => (
                        <button
                          key={bg}
                          onClick={() => setLeadBudget(bg)}
                          className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                            leadBudget === bg
                              ? 'bg-purple-600 text-white shadow-sm'
                              : 'bg-slate-100 text-slate-600 hover:bg-slate-700'
                          }`}
                        >
                          {bg}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-slate-600 block mb-1.5">
                      Implementation Timeline
                    </label>
                    <div className="flex flex-wrap gap-2">
                      {['Immediate (< 1 month)', '1 - 3 months', 'Exploring / Next Quarter'].map((tl) => (
                        <button
                          key={tl}
                          onClick={() => setLeadTimeline(tl)}
                          className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                            leadTimeline === tl
                              ? 'bg-indigo-600 text-white shadow-sm'
                              : 'bg-slate-100 text-slate-600 hover:bg-slate-700'
                          }`}
                        >
                          {tl}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="md:col-span-5 p-5 rounded-xl bg-white/80 border border-purple-500/30 text-center">
                  <div className="text-xs text-purple-700 font-semibold mb-1">
                    AI Lead Probability Score
                  </div>
                  <div className="text-4xl font-extrabold text-white font-mono my-2">
                    {leadBudget === '₹ 1,00,000+' ? '94/100' : leadBudget.includes('50,000') ? '82/100' : '68/100'}
                  </div>
                  <div className="inline-block px-3 py-1 rounded-full text-xs font-semibold bg-emerald-950 text-emerald-400 border border-emerald-500/30 mb-3">
                    High Conversion Opportunity
                  </div>
                  <p className="text-xs text-slate-600 leading-snug">
                    Prospect scored based on intent keywords, budget viability ({leadBudget}), and high fit for WebNova {leadIndustry} systems.
                  </p>
                </div>
              </div>
            )}

            {/* Sub-simulator 2: Smart Quote Assistant */}
            {selectedTool === 'quote-assistant' && (
              <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
                <div className="md:col-span-7 space-y-4">
                  <div>
                    <label className="text-xs font-semibold text-slate-600 block mb-1.5">
                      Solution Type
                    </label>
                    <div className="flex flex-wrap gap-2">
                      {['Custom Website', 'Web App + ERP', 'Mobile App', 'AI Automation Engine'].map((t) => (
                        <button
                          key={t}
                          onClick={() => setQuoteType(t)}
                          className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                            quoteType === t
                              ? 'bg-cyan-600 text-white shadow-sm'
                              : 'bg-slate-100 text-slate-600 hover:bg-slate-700'
                          }`}
                        >
                          {t}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-slate-600 block mb-1.5">
                      Scope Scale
                    </label>
                    <div className="flex flex-wrap gap-2">
                      {['1-5 Pages / MVP', '5-10 Pages', 'Comprehensive Enterprise'].map((p) => (
                        <button
                          key={p}
                          onClick={() => setQuotePages(p)}
                          className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                            quotePages === p
                              ? 'bg-blue-600 text-white shadow-sm'
                              : 'bg-slate-100 text-slate-600 hover:bg-slate-700'
                          }`}
                        >
                          {p}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="md:col-span-5 p-5 rounded-xl bg-white/80 border border-cyan-500/30 text-center">
                  <div className="text-xs text-cyan-700 font-semibold mb-1">
                    Instant AI Scoped Quote
                  </div>
                  <div className="text-3xl font-extrabold text-white font-mono my-2">
                    {quoteType.includes('ERP') ? '₹ 75,000 – ₹ 1,40,000' : '₹ 35,000 – ₹ 65,000'}
                  </div>
                  <div className="text-xs text-slate-500 mb-2 font-mono">
                    Estimated Delivery: 2–4 Weeks · 100% Milestone Based
                  </div>
                  <a
                    href="#quotation"
                    className="inline-block px-4 py-2 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-lg transition-colors"
                  >
                    Lock this quote in
                  </a>
                </div>
              </div>
            )}

            {/* Sub-simulator 3: Auto Follow-Up Flow */}
            {selectedTool === 'follow-up' && (
              <div>
                <div className="flex items-center justify-between mb-4">
                  <span className="text-xs text-slate-600">
                    Live Pipeline Drip Automation Status:
                  </span>
                  <button
                    onClick={() => setFlowActive(!flowActive)}
                    className={`px-3 py-1 rounded-full text-xs font-semibold transition-all ${
                      flowActive
                        ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/30'
                        : 'bg-slate-100 text-slate-500'
                    }`}
                  >
                    {flowActive ? 'Active & Monitoring' : 'Paused'}
                  </button>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="p-3.5 rounded-xl bg-white/70 border border-slate-200">
                    <div className="text-[10px] text-blue-700 font-mono mb-1">STAGE 1 · INSTANT</div>
                    <div className="text-xs font-bold text-slate-900 mb-1">Proposal Dispatch</div>
                    <p className="text-[11px] text-slate-500">Automated interactive brochure and custom video walkthrough delivered via email.</p>
                  </div>
                  <div className="p-3.5 rounded-xl bg-white/70 border border-slate-200">
                    <div className="text-[10px] text-indigo-400 font-mono mb-1">STAGE 2 · DAY 3</div>
                    <div className="text-xs font-bold text-slate-900 mb-1">Relevant Case Studies</div>
                    <p className="text-[11px] text-slate-500">Pushes matched client success metrics & ROI projections to client WhatsApp.</p>
                  </div>
                  <div className="p-3.5 rounded-xl bg-white/70 border border-slate-200">
                    <div className="text-[10px] text-purple-700 font-mono mb-1">STAGE 3 · DAY 5</div>
                    <div className="text-xs font-bold text-slate-900 mb-1">Direct Call Scheduling</div>
                    <p className="text-[11px] text-slate-500">Sends one-click VIP calendar link with engineering lead.</p>
                  </div>
                </div>
              </div>
            )}

            {/* Sub-simulator 4: Secure User Portal */}
            {selectedTool === 'user-portal' && (
              <div>
                <div className="flex items-center gap-3 mb-4">
                  <span className="text-xs text-slate-600 font-semibold">Simulate Role:</span>
                  {(['Client', 'Manager', 'Admin'] as const).map((role) => (
                    <button
                      key={role}
                      onClick={() => setPortalRole(role)}
                      className={`px-3 py-1 rounded-lg text-xs font-medium transition-all ${
                        portalRole === role
                          ? 'bg-emerald-600 text-white'
                          : 'bg-slate-100 text-slate-500 hover:text-slate-700'
                      }`}
                    >
                      {role} View
                    </button>
                  ))}
                </div>
                <div className="p-4 rounded-xl bg-white/80 border border-slate-200 grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
                  <div>
                    <span className="text-slate-500 block mb-1">Access Level</span>
                    <span className="font-bold text-slate-900">{portalRole} Dashboard (Encrypted)</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block mb-1">Authentication Method</span>
                    <span className="font-bold text-emerald-400">OTP via SMS / WhatsApp + JWT</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block mb-1">Permissions</span>
                    <span className="font-bold text-slate-900">
                      {portalRole === 'Client' && 'View Milestones, Invoices, Deliverables'}
                      {portalRole === 'Manager' && 'Approve PRs, Assign Sprints, Manage Clients'}
                      {portalRole === 'Admin' && 'Full Root, Financials, DB Schemas'}
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </section>
  );
};
