import React from 'react';
import { ArrowLeft, BriefcaseBusiness, Sparkles, Rocket } from 'lucide-react';

export function FreelancerComingSoon() {
  React.useEffect(() => {
    document.title = 'WebNova Freelancer Network — Coming Soon';
    let meta = document.querySelector<HTMLMetaElement>('meta[name="description"]');
    if (!meta) { meta = document.createElement('meta'); meta.name = 'description'; document.head.appendChild(meta); }
    meta.content = 'The WebNova Freelancer Network is coming soon. Connect with talented independent professionals and discover new opportunities.';
  }, []);
  return <main className="relative flex min-h-screen items-center justify-center overflow-hidden bg-[#071126] px-5 py-16 text-white">
    <div className="pointer-events-none absolute -left-24 top-0 h-80 w-80 rounded-full bg-blue-600/25 blur-3xl" />
    <div className="pointer-events-none absolute -right-20 bottom-0 h-96 w-96 rounded-full bg-violet-600/25 blur-3xl" />
    <section className="relative z-10 mx-auto max-w-3xl text-center">
      <a href="/" className="mb-12 inline-flex items-center gap-2 text-sm font-semibold text-blue-200 transition hover:text-white"><ArrowLeft size={16}/> Back to WebNova</a>
      <div className="mx-auto mb-7 flex h-20 w-20 items-center justify-center rounded-3xl border border-white/15 bg-white/10 shadow-2xl shadow-blue-950/40"><BriefcaseBusiness size={34} className="text-cyan-300"/></div>
      <p className="mb-4 inline-flex items-center gap-2 rounded-full border border-cyan-300/25 bg-cyan-300/10 px-4 py-2 text-xs font-bold uppercase tracking-[.22em] text-cyan-200"><Sparkles size={14}/> Building something better</p>
      <h1 className="text-4xl font-black tracking-tight sm:text-6xl">WebNova <span className="bg-gradient-to-r from-cyan-300 to-violet-300 bg-clip-text text-transparent">Freelancer</span></h1>
      <h2 className="mt-4 text-2xl font-bold text-white/90 sm:text-3xl">Coming Soon</h2>
      <p className="mx-auto mt-5 max-w-xl text-base leading-7 text-slate-300">A new space for independent talent, meaningful collaborations, and exciting digital projects. We’re preparing the experience and will be ready to welcome you soon.</p>
      <div className="mx-auto mt-9 flex max-w-md items-center justify-center gap-3 rounded-2xl border border-white/10 bg-white/5 p-4 text-left"><div className="rounded-xl bg-violet-400/15 p-3 text-violet-200"><Rocket size={22}/></div><div><p className="font-bold">Great work starts with great people.</p><p className="mt-1 text-sm text-slate-400">Check back soon for launch updates.</p></div></div>
      <a href="/#contact" className="mt-8 inline-flex items-center justify-center rounded-xl bg-gradient-to-r from-blue-600 to-violet-600 px-6 py-3 font-bold shadow-lg shadow-blue-950/30 transition hover:-translate-y-0.5">Talk to our team</a>
      <p className="mt-12 text-xs text-slate-500">© {new Date().getFullYear()} WebNova Solutions</p>
    </section>
  </main>;
}
