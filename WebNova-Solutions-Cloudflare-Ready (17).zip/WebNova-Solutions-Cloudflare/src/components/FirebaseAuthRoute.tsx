import React, { useEffect, useState } from 'react';
import {
  GoogleAuthProvider, createUserWithEmailAndPassword, onAuthStateChanged,
  sendEmailVerification, sendPasswordResetEmail, signInWithEmailAndPassword,
  signInWithPopup, signOut, updateProfile, type User,
} from 'firebase/auth';
import { doc, getDoc, setDoc, serverTimestamp } from 'firebase/firestore';
import { ArrowLeft, Eye, EyeOff, LoaderCircle, LockKeyhole, Mail, ShieldCheck, UserRound, Sparkles } from 'lucide-react';
import { auth, db, firebaseConfigured } from '../firebase';
import { DashboardPage } from './DashboardPage';

type Role = 'admin' | 'client';
type Mode = 'login' | 'register' | 'reset';

const friendlyError = (error: unknown) => {
  const code = (error as { code?: string })?.code || '';
  const messages: Record<string, string> = {
    'auth/invalid-email': 'Please enter a valid email address.',
    'auth/invalid-credential': 'Email or password is incorrect.',
    'auth/user-not-found': 'No account was found for this email.',
    'auth/wrong-password': 'Email or password is incorrect.',
    'auth/email-already-in-use': 'An account already exists for this email. Please sign in.',
    'auth/weak-password': 'Choose a password with at least 6 characters.',
    'auth/too-many-requests': 'Too many attempts. Wait a while and try again.',
    'auth/popup-closed-by-user': 'The Google sign-in window was closed before completion.',
    'auth/operation-not-allowed': 'Enable this sign-in method in Firebase Console → Authentication → Sign-in method.',
    'auth/network-request-failed': 'Network error. Check your connection and try again.',
  };
  return messages[code] || (error instanceof Error ? error.message : 'Something went wrong. Please try again.');
};

export function FirebaseAuthRoute({ expectedRole }: { expectedRole: Role }) {
  const [mode, setMode] = useState<Mode>('login');
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [message, setMessage] = useState('');
  const [messageType, setMessageType] = useState<'error' | 'success' | 'info'>('info');
  const [resolvedRole, setResolvedRole] = useState<Role | null>(null);

  useEffect(() => {
    if (!auth) { setLoading(false); return; }
    return onAuthStateChanged(auth, async (nextUser) => {
      setUser(nextUser);
      setResolvedRole(null);
      if (!nextUser) { setLoading(false); return; }
      if (!nextUser.emailVerified) { setLoading(false); return; }
      try {
        const profileRef = doc(db!, 'users', nextUser.uid);
        const profile = await getDoc(profileRef);
        let role = profile.exists() ? profile.data().role : null;

        // Safe self-healing for client accounts only. Firestore rules permit a user
        // to create their own profile only with role='client'; this cannot grant admin.
        if (!profile.exists() && expectedRole === 'client') {
          await setDoc(profileRef, {
            uid: nextUser.uid,
            email: nextUser.email,
            displayName: nextUser.displayName || '',
            role: 'client',
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
          role = 'client';
        }
        if (role === 'admin' || role === 'client') setResolvedRole(role);
      } catch (error) {
        setMessage(friendlyError(error)); setMessageType('error');
      } finally { setLoading(false); }
    });
  }, []);

  const showMessage = (text: string, type: 'error' | 'success' | 'info' = 'info') => { setMessage(text); setMessageType(type); };

  const submit = async (event: React.FormEvent) => {
    event.preventDefault(); setMessage('');
    if (!auth || !db) { showMessage('Firebase is not configured yet. Add your Firebase web-app settings to the .env file, then restart the dev server.', 'error'); return; }
    setBusy(true);
    try {
      if (mode === 'reset') {
        await sendPasswordResetEmail(auth, email.trim());
        showMessage('Password reset email sent. Check your inbox and spam folder.', 'success');
      } else if (mode === 'register') {
        if (expectedRole === 'admin') throw new Error('Admin accounts cannot be created from the public website. Create the account in Firebase Console, then assign role: admin in Firestore.');
        if (password.length < 6) throw new Error('Choose a password with at least 6 characters.');
        const credential = await createUserWithEmailAndPassword(auth, email.trim(), password);
        if (name.trim()) await updateProfile(credential.user, { displayName: name.trim() });
        await setDoc(doc(db, 'users', credential.user.uid), {
          uid: credential.user.uid, email: credential.user.email, displayName: name.trim(), role: 'client',
          createdAt: serverTimestamp(), updatedAt: serverTimestamp(),
        });
        await sendEmailVerification(credential.user);
        showMessage('Account created. Verify your email using the link we sent before signing in to the client portal.', 'success');
        await signOut(auth);
        setMode('login'); setPassword('');
      } else {
        const credential = await signInWithEmailAndPassword(auth, email.trim(), password);
        if (!credential.user.emailVerified) {
          await sendEmailVerification(credential.user);
          await signOut(auth);
          throw new Error('Please verify your email first. We sent a fresh verification link to your inbox.');
        }
        const profileRef = doc(db, 'users', credential.user.uid);
        let profile = await getDoc(profileRef);
        let actualRole = profile.exists() ? profile.data().role : null;
        // Repair an older client account whose Auth user exists but profile was never created.
        if (!profile.exists() && expectedRole === 'client') {
          await setDoc(profileRef, {
            uid: credential.user.uid,
            email: credential.user.email,
            displayName: credential.user.displayName || '',
            role: 'client',
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
          profile = await getDoc(profileRef);
          actualRole = profile.exists() ? profile.data().role : null;
        }
        if (actualRole !== expectedRole) {
          await signOut(auth);
          throw new Error(actualRole ? `This account is registered as ${actualRole}. Use the ${actualRole === 'admin' ? 'admin' : 'client'} sign-in page.` : 'Your account role has not been configured. Contact the WebNova administrator.');
        }
        setResolvedRole(actualRole);
      }
    } catch (error) { showMessage(friendlyError(error), 'error'); }
    finally { setBusy(false); }
  };

  const googleSignIn = async () => {
    if (!auth || !db) { showMessage('Add your Firebase configuration first.', 'error'); return; }
    setBusy(true); setMessage('');
    try {
      const result = await signInWithPopup(auth, new GoogleAuthProvider());
      const profileRef = doc(db, 'users', result.user.uid);
      let profile = await getDoc(profileRef);

      // Only client sign-in may create a missing client profile. Google sign-in
      // never grants or creates admin access; an admin must already be assigned
      // role='admin' in users/{uid} by the project owner.
      if (!profile.exists() && expectedRole === 'client') {
        await setDoc(profileRef, {
          uid: result.user.uid,
          email: result.user.email,
          displayName: result.user.displayName || '',
          role: 'client',
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
        profile = await getDoc(profileRef);
      }

      const actualRole = profile.exists() ? profile.data().role : null;
      if (actualRole !== expectedRole) {
        await signOut(auth);
        throw new Error(actualRole
          ? `This account is assigned the ${actualRole} role. Use the ${actualRole === 'admin' ? 'admin' : 'client'} workspace.`
          : 'No workspace profile exists for this account. Ask the WebNova administrator to create users/{your exact Firebase UID} with the correct role.');
      }
      setResolvedRole(expectedRole);
    } catch (error) { showMessage(friendlyError(error), 'error'); }
    finally { setBusy(false); }
  };

  if (loading) return <div className="min-h-screen grid place-items-center bg-slate-50 text-slate-700"><LoaderCircle className="animate-spin"/> <span className="ml-2">Checking secure session…</span></div>;
  if (user && !user.emailVerified) return <AuthMessage title="Verify your email" detail={`A verification link is required before opening the ${expectedRole} workspace. Check ${user.email || 'your inbox'} and spam folder.`} onAction={async () => { try { await sendEmailVerification(user); setMessage('Verification email sent.'); } catch (e) { setMessage(friendlyError(e)); } }} onLogout={async () => { if (auth) await signOut(auth); }} message={message}/>;
  if (user && resolvedRole === expectedRole) return <DashboardPage role={expectedRole === 'admin' ? 'admin' : 'user'} onLogout={async () => { if (auth) await signOut(auth); }} currentUser={user}/>;
  if (user && resolvedRole && resolvedRole !== expectedRole) return <AuthMessage title="Wrong workspace" detail={`You are signed in as ${resolvedRole}. This page is for ${expectedRole === 'admin' ? 'administrators' : 'clients'}.`} onAction={() => { window.location.assign(resolvedRole === 'admin' ? '/admin' : '/portal'); }} actionLabel="Open correct workspace" onLogout={async () => { if (auth) await signOut(auth); }} />;
  if (user && !resolvedRole) return <AuthMessage title="Workspace role not configured" detail={expectedRole === 'admin' ? 'Your account is signed in, but it is not assigned the admin role. In Firebase Console, open Firestore Database → users → create a document whose ID is your exact Authentication UID, then set uid (string) to that UID, email (string) to your email, role (string) to admin, and displayName (string) to your name. Never assign admin from public signup.' : 'Your account profile could not be loaded or created. Check that this site uses the correct Firebase project and that the published Firestore rules allow a signed-in user to create their own client profile.'} actionLabel="Sign out" onAction={async () => { if (auth) await signOut(auth); }} onLogout={async () => { if (auth) await signOut(auth); }} />;

  const title = expectedRole === 'admin' ? 'Admin workspace' : 'Client portal';
  return <main className="relative min-h-screen overflow-hidden bg-[#f5f7ff] px-4 py-10 text-slate-900 sm:px-6 sm:py-16">
    <div className="pointer-events-none absolute -left-24 top-0 h-80 w-80 rounded-full bg-cyan-300/30 blur-3xl"/><div className="pointer-events-none absolute -right-20 bottom-0 h-96 w-96 rounded-full bg-violet-300/30 blur-3xl"/>
    <div className="relative mx-auto grid max-w-5xl overflow-hidden rounded-[2rem] border border-white bg-white shadow-2xl shadow-blue-950/10 md:grid-cols-[.9fr_1.1fr]">
      <aside className="relative hidden flex-col justify-between overflow-hidden bg-[#071531] p-10 text-white md:flex"><div className="absolute -right-20 top-16 h-64 w-64 rounded-full border border-cyan-300/20"/><div className="absolute -right-8 top-28 h-44 w-44 rounded-full border border-violet-300/30"/><div className="relative"><a href="/" className="inline-flex items-center gap-3"><img src="/webnova-mark.png" alt="" className="h-12 w-12 object-contain"/><span className="text-xl font-extrabold">WebNova <span className="text-cyan-300">Solutions</span></span></a><div className="mt-20 inline-flex items-center gap-2 rounded-full border border-cyan-300/20 bg-cyan-300/10 px-3 py-1.5 text-xs font-bold text-cyan-200"><Sparkles size={14}/> Secure workspace</div><h1 className="mt-6 text-4xl font-black leading-tight">Your digital business, <span className="bg-gradient-to-r from-cyan-300 to-violet-300 bg-clip-text text-transparent">in one place.</span></h1><p className="mt-5 max-w-sm leading-7 text-slate-300">Sign in to manage projects, support requests, documents and updates with WebNova Solutions.</p></div><div className="relative flex items-center gap-3 text-xs text-slate-400"><ShieldCheck size={17} className="text-cyan-300"/> Email verification and role-based workspace access</div></aside>
      <section className="p-6 sm:p-10 lg:p-12"><a href="/" className="inline-flex items-center gap-2 text-sm font-semibold text-slate-500 hover:text-blue-700"><ArrowLeft size={16}/> Back to website</a>
        <div className="mt-8"><div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-blue-600 to-violet-600 text-white shadow-lg shadow-blue-600/20">{expectedRole === 'admin' ? <ShieldCheck size={24}/> : <UserRound size={24}/>}</div><p className="mt-5 text-xs font-extrabold uppercase tracking-[.2em] text-blue-700">WebNova Solutions</p><h2 className="mt-2 text-3xl font-black tracking-tight">{mode === 'register' ? 'Create your account' : mode === 'reset' ? 'Reset your password' : `Welcome to your ${title}`}</h2><p className="mt-2 text-sm leading-6 text-slate-500">{mode === 'register' ? 'Create a client account to access your workspace.' : mode === 'reset' ? 'We will email you a secure password reset link.' : `Sign in securely to continue to the ${title.toLowerCase()}.`}</p></div>
        {!firebaseConfigured && <div className="mt-5 rounded-xl border border-amber-200 bg-amber-50 p-3 text-sm leading-6 text-amber-900"><strong>Firebase setup needed.</strong> Add the six VITE_FIREBASE values from your Firebase web app to `.env` (or your hosting environment variables). Authentication will remain unavailable until configured.</div>}
        <form data-form-name={`Authentication ${mode} - ${expectedRole}`} onSubmit={submit} className="mt-6 space-y-4" data-no-global-captcha="false">
          {mode === 'register' && <label className="block text-sm font-bold">Full name<div className="relative mt-2"><UserRound size={17} className="absolute left-3 top-3.5 text-slate-400"/><input name="displayName" autoComplete="name" required value={name} onChange={e=>setName(e.target.value)} className="w-full rounded-xl border border-slate-200 bg-slate-50 py-3 pl-10 pr-4 outline-none focus:border-blue-500 focus:bg-white" placeholder="Your full name"/></div></label>}
          <label className="block text-sm font-bold">Email address<div className="relative mt-2"><Mail size={17} className="absolute left-3 top-3.5 text-slate-400"/><input name="email" type="email" autoComplete="email" required value={email} onChange={e=>setEmail(e.target.value)} className="w-full rounded-xl border border-slate-200 bg-slate-50 py-3 pl-10 pr-4 outline-none focus:border-blue-500 focus:bg-white" placeholder="you@example.com"/></div></label>
          {mode !== 'reset' && <label className="block text-sm font-bold">Password<div className="relative mt-2"><LockKeyhole size={17} className="absolute left-3 top-3.5 text-slate-400"/><input name="password" type={showPassword?'text':'password'} autoComplete={mode==='register'?'new-password':'current-password'} minLength={6} required value={password} onChange={e=>setPassword(e.target.value)} className="w-full rounded-xl border border-slate-200 bg-slate-50 py-3 pl-10 pr-12 outline-none focus:border-blue-500 focus:bg-white" placeholder={mode==='register'?'At least 6 characters':'Enter your password'}/><button type="button" aria-label={showPassword?'Hide password':'Show password'} onClick={()=>setShowPassword(!showPassword)} className="absolute right-3 top-3 text-slate-400">{showPassword?<EyeOff size={18}/>:<Eye size={18}/>}</button></div></label>}
          {mode === 'login' && <div className="flex justify-end"><button type="button" onClick={()=>{setMode('reset');setMessage('');}} className="text-sm font-bold text-blue-700 hover:text-violet-700">Forgot password?</button></div>}
          <button disabled={busy || !firebaseConfigured} className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-blue-600 to-violet-600 py-3.5 font-extrabold text-white shadow-lg shadow-blue-600/20 transition hover:-translate-y-0.5 disabled:cursor-not-allowed disabled:opacity-50">{busy&&<LoaderCircle size={17} className="animate-spin"/>}{mode==='register'?'Create client account':mode==='reset'?'Send reset link':'Sign in securely'}</button>
        </form>
        {mode==='login' && <><div className="my-5 flex items-center gap-3 text-xs text-slate-400"><span className="h-px flex-1 bg-slate-200"/>or continue with<span className="h-px flex-1 bg-slate-200"/></div><button onClick={googleSignIn} disabled={busy||!firebaseConfigured} className="flex w-full items-center justify-center gap-3 rounded-xl border border-slate-200 bg-white py-3 text-sm font-bold text-slate-700 hover:bg-slate-50 disabled:opacity-50"><GoogleMark/> Continue with Google</button></>}
        {message && <p role="status" className={`mt-5 rounded-xl border p-3 text-sm leading-6 ${messageType==='error'?'border-rose-200 bg-rose-50 text-rose-800':messageType==='success'?'border-emerald-200 bg-emerald-50 text-emerald-800':'border-blue-100 bg-blue-50 text-blue-800'}`}>{message}</p>}
        <div className="mt-6 text-center text-sm text-slate-500">{mode==='reset'?<button onClick={()=>{setMode('login');setMessage('');}} className="font-bold text-blue-700">Back to sign in</button>:mode==='register'?<>Already registered? <button onClick={()=>{setMode('login');setMessage('');}} className="font-bold text-blue-700">Sign in</button></>:expectedRole==='client'?<>New to WebNova? <button onClick={()=>{setMode('register');setMessage('');}} className="font-bold text-blue-700">Create a client account</button></>:<span>Administrator accounts are created and assigned by your Firebase project owner.</span>}</div>
        <p className="mt-6 text-center text-[11px] leading-5 text-slate-400">Never share your password or verification codes. Admin access is assigned separately in Firebase.</p>
      </section>
    </div>
  </main>;
}

function AuthMessage({title,detail,onAction,actionLabel='Resend verification email',onLogout,message}:{title:string;detail:string;onAction:()=>void|Promise<void>;actionLabel?:string;onLogout:()=>void|Promise<void>;message?:string}) {
 return <main className="grid min-h-screen place-items-center bg-slate-50 px-4"><section className="w-full max-w-lg rounded-3xl border border-slate-200 bg-white p-8 text-center shadow-xl"><div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-blue-50 text-blue-700"><Mail size={27}/></div><h1 className="mt-5 text-2xl font-black">{title}</h1><p className="mt-3 text-sm leading-6 text-slate-600">{detail}</p>{message&&<p className="mt-3 text-sm text-blue-700">{message}</p>}<button onClick={onAction} className="mt-6 w-full rounded-xl bg-blue-600 px-4 py-3 font-bold text-white">{actionLabel}</button>{actionLabel !== 'Sign out' && <button onClick={onLogout} className="mt-3 w-full rounded-xl border border-slate-200 px-4 py-3 font-bold text-slate-700">Sign out</button>}<a href="/" className="mt-5 inline-block text-sm font-semibold text-blue-700">Back to website</a></section></main>;
}
function GoogleMark(){return <svg viewBox="0 0 24 24" aria-hidden="true" className="h-5 w-5"><path fill="#4285F4" d="M21.35 12.23c0-.72-.06-1.42-.18-2.09H12v3.95h5.24a4.48 4.48 0 0 1-1.95 2.94v2.41h3.16c1.85-1.7 2.9-4.2 2.9-7.21Z"/><path fill="#34A853" d="M12 21.6c2.65 0 4.87-.88 6.49-2.38l-3.16-2.41c-.88.59-2 .94-3.33.94-2.56 0-4.73-1.73-5.5-4.06H3.24v2.49A9.8 9.8 0 0 0 12 21.6Z"/><path fill="#FBBC05" d="M6.5 13.69a5.9 5.9 0 0 1 0-3.38V7.82H3.24a9.82 9.82 0 0 0 0 8.36l3.26-2.49Z"/><path fill="#EA4335" d="M12 6.25c1.44 0 2.73.49 3.75 1.47l2.81-2.81C16.86 3.32 14.64 2.4 12 2.4a9.8 9.8 0 0 0-8.76 5.42L6.5 10.3c.77-2.33 2.94-4.05 5.5-4.05Z"/></svg>}
