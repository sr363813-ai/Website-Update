import React, { useEffect, useState } from 'react';

const GOOGLE_REVIEW_URL = 'https://g.page/r/Cd2bxe22kevQEBM/review';

export function GoogleReviewsSection() {
  const [visible, setVisible] = useState(true);
  useEffect(() => {
    const read = () => setVisible(localStorage.getItem('webnova_google_reviews_visible') !== 'false');
    read(); window.addEventListener('storage', read);
    return () => window.removeEventListener('storage', read);
  }, []);
  if (!visible) return null;
  return (
    <section id="google-reviews" className="relative overflow-hidden bg-gradient-to-br from-slate-50 via-white to-blue-50 px-4 py-16 sm:px-6 sm:py-20">
      <div className="mx-auto max-w-6xl">
        <div className="mx-auto max-w-3xl text-center">
          <span className="inline-flex items-center gap-2 rounded-full border border-blue-100 bg-white px-4 py-2 text-sm font-semibold text-blue-700 shadow-sm">
            <span aria-hidden="true" className="text-lg">★</span> Google Reviews & Feedback
          </span>
          <h2 className="mt-5 text-3xl font-extrabold tracking-tight text-slate-900 sm:text-5xl">Tell us about your experience.</h2>
          <p className="mx-auto mt-4 max-w-2xl text-base leading-7 text-slate-600 sm:text-lg">
            Worked with WebNova Solutions? We welcome your honest feedback—what went well, what we could improve, and how we helped your business.
          </p>
          <div className="mt-6 flex items-center justify-center gap-1 text-3xl text-amber-400" aria-label="Five star rating prompt">
            {Array.from({ length: 5 }, (_, i) => <span key={i} aria-hidden="true">★</span>)}
          </div>
          <a href={GOOGLE_REVIEW_URL} target="_blank" rel="noopener noreferrer"
            className="mt-8 inline-flex items-center justify-center gap-3 rounded-xl bg-blue-700 px-7 py-4 font-bold text-white shadow-lg shadow-blue-700/20 transition hover:-translate-y-0.5 hover:bg-blue-800 focus:outline-none focus:ring-4 focus:ring-blue-300">
            <svg aria-hidden="true" viewBox="0 0 24 24" className="h-5 w-5" fill="currentColor"><path d="M21.35 11.1H12v2.95h5.35c-.25 1.5-1.8 4.4-5.35 4.4a6.45 6.45 0 1 1 0-12.9c1.95 0 3.25.83 4 1.55l2.17-2.1A9.5 9.5 0 1 0 12 21.5c5.48 0 9.1-3.85 9.1-9.28 0-.62-.07-1.03-.15-1.12h.4Z"/></svg>
            Share Your Experience on Google <span aria-hidden="true">↗</span>
          </a>
          <p className="mt-4 text-sm text-slate-500">Your review is public on Google and helps us improve our service.</p>
        </div>
        <div className="mt-12 grid gap-4 border-t border-slate-200 pt-8 sm:grid-cols-3">
          <div className="rounded-2xl border border-slate-200 bg-white p-5 text-center"><div className="text-2xl">💬</div><h3 className="mt-2 font-bold text-slate-900">Share your experience</h3><p className="mt-1 text-sm leading-6 text-slate-600">Tell others what working with our team was like.</p></div>
          <div className="rounded-2xl border border-slate-200 bg-white p-5 text-center"><div className="text-2xl">🤝</div><h3 className="mt-2 font-bold text-slate-900">Help others choose</h3><p className="mt-1 text-sm leading-6 text-slate-600">Your honest review helps businesses find the right partner.</p></div>
          <div className="rounded-2xl border border-slate-200 bg-white p-5 text-center"><div className="text-2xl">📍</div><h3 className="mt-2 font-bold text-slate-900">WebNova Solutions</h3><p className="mt-1 text-sm leading-6 text-slate-600">Headquarters: Lucknow, Uttar Pradesh, India</p><a className="mt-2 inline-block text-sm font-semibold text-blue-700 hover:underline" href={GOOGLE_REVIEW_URL} target="_blank" rel="noopener noreferrer">Open Google review page ↗</a></div>
        </div>
      </div>
    </section>
  );
}
