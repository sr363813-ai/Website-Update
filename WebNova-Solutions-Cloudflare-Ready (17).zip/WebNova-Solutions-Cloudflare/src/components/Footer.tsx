import React from 'react';
import { Mail, Phone, MapPin, Instagram, Linkedin, Youtube, Facebook, MessageCircle } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-[#050811] border-t border-slate-200/80 pt-16 pb-12 relative z-10 text-slate-500">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 mb-12">
          {/* Brand Info */}
          <div className="lg:col-span-2 space-y-4">
            <div className="inline-flex items-center rounded-xl bg-white px-3 py-2 shadow-sm">
              <img src="/webnova-logo.png" alt="WebNova Solutions — We build websites that grow businesses" className="w-40 h-auto object-contain" loading="lazy" />
            </div>
            <p className="text-xs text-slate-500 max-w-sm leading-relaxed">
              WebNova Solutions is a full-stack digital studio crafting high-converting websites, automated business systems, AI-driven workflows, and cross-platform mobile apps.
            </p>
            <div className="text-[11px] font-mono text-slate-500">
              Websites · Systems · AI · ERP · Connected Products
            </div>

            {/* Official social channels */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <a href="https://www.instagram.com/webnovasolutions.co.in/" target="_blank" rel="noreferrer" className="social-link" aria-label="Instagram" title="Instagram"><Instagram className="w-4 h-4" /></a>
              <a href="https://www.linkedin.com/company/webnova-solutionsw/posts/?viewAsMember=true" target="_blank" rel="noreferrer" className="social-link" aria-label="LinkedIn" title="LinkedIn"><Linkedin className="w-4 h-4" /></a>
              <a href="https://www.youtube.com/@webnovasolutions01" target="_blank" rel="noreferrer" className="social-link" aria-label="YouTube" title="YouTube"><Youtube className="w-4 h-4" /></a>
              <a href="https://www.facebook.com/profile.php?id=61594806735401" target="_blank" rel="noreferrer" className="social-link" aria-label="Facebook" title="Facebook"><Facebook className="w-4 h-4" /></a>
              <a href="https://wa.me/918765051912" target="_blank" rel="noreferrer" className="social-link" aria-label="WhatsApp" title="WhatsApp"><MessageCircle className="w-4 h-4" /></a>
            </div>
          </div>

          {/* Column 1: Explore */}
          <div>
            <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-4">
              Explore
            </h4>
            <ul className="space-y-2.5 text-xs">
              <li>
                <a href="#hero" className="hover:text-blue-700 transition-colors">
                  Home
                </a>
              </li>
              <li>
                <a href="#about" className="hover:text-blue-700 transition-colors">
                  About
                </a>
              </li>
              <li>
                <a href="#services" className="hover:text-blue-700 transition-colors">
                  Services
                </a>
              </li>
              <li><a href="/portfolio" className="hover:text-blue-700 transition-colors">Portfolio &amp; concepts</a></li>
              <li><a href="/seo-audit" className="hover:text-blue-700 transition-colors">Free SEO audit</a></li>
              <li><a href="/project-assistant" className="hover:text-blue-700 transition-colors">Project assistant</a></li>
              <li><a href="/blog" className="hover:text-blue-700 transition-colors">Blog &amp; guides</a></li>
              <li>
                <a href="#testimonials" className="hover:text-blue-700 transition-colors">
                  Stories
                </a>
              </li>
              <li>
                <a href="#contact" className="hover:text-blue-700 transition-colors">
                  Contact
                </a>
              </li>
            </ul>
          </div>

          {/* Column 2: Platforms */}
          <div>
            <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-4">
              Platforms
            </h4>
            <ul className="space-y-2.5 text-xs">
              <li>
                <a href="#platforms" className="hover:text-blue-700 transition-colors">
                  WebNova Solutions
                </a>
              </li>
              <li>
                <a href="#platforms" className="hover:text-blue-700 transition-colors">
                  WebNova ERP
                </a>
              </li>
              <li>
                <a href="#platforms" className="hover:text-blue-700 transition-colors">
                  WebNova App
                </a>
              </li>
              <li>
                <a href="#ai-command" className="hover:text-blue-700 transition-colors">
                  WebNova Gullak
                </a>
              </li>
            </ul>
          </div>

          {/* Column 3: Connect */}
          <div>
            <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-4">
              Connect
            </h4>
            <ul className="space-y-3 text-xs">
              <li className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-blue-700 shrink-0" />
                <a
                  href="mailto:support@webnovasolutions.co.in"
                  className="hover:text-white transition-colors truncate"
                >
                  support@webnovasolutions.co.in
                </a>
              </li>
              <li className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-cyan-700 shrink-0" />
                <a href="tel:+918765051912" className="hover:text-white transition-colors">
                  +91 87650 51912
                </a>
              </li>
              <li className="flex items-center gap-2">
                <MapPin className="w-3.5 h-3.5 text-purple-700 shrink-0" />
                <span>India</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar: Copyright & Legal */}
        <div className="pt-8 border-t border-slate-200/80 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
          <div>
            © 2026 WebNova Solutions. All rights reserved.
          </div>
          <div className="flex flex-wrap items-center gap-4 text-slate-500">
            <a href="/portal" className="hover:text-blue-600 transition-colors">User Portal</a>
            <a href="/admin" className="hover:text-blue-600 transition-colors">Admin Login</a>
            <span>|</span>
            <a href="/privacy-policy" className="hover:text-blue-600 transition-colors">
              Privacy Policy
            </a>
            <span>|</span>
            <a href="/terms-and-conditions" className="hover:text-blue-600 transition-colors">
              Terms &amp; Conditions
            </a>
            <span>|</span>
            <a href="/" className="hover:text-blue-600 transition-colors">
              Home
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};
