import React, { useState } from 'react';
import { ChevronDown } from 'lucide-react';

export const FaqSection: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs = [
    {
      question: 'What services does WebNova Solutions offer?',
      answer:
        'We are an end-to-end digital studio offering custom website design & development, enterprise business systems (ERP & CRM), mobile applications (iOS/Android), AI automation copilots, and cloud architecture consulting.',
    },
    {
      question: 'How long does a project take?',
      answer:
        'Standard corporate and landing websites typically take 2 to 3 weeks from discovery to deployment. Custom web applications, ERP integrations, and complex AI pipeline builds range from 4 to 8 weeks depending on exact scope and custom feature sets.',
    },
    {
      question: 'Do you provide ongoing support?',
      answer:
        'Yes. We offer continuous SLA-backed maintenance plans including 24/7 uptime monitoring, critical security patching, automated daily backups, and dedicated monthly development sprint hours for feature iterations.',
    },
    {
      question: 'What are your pricing plans?',
      answer:
        'We work on milestone-based transparent fixed-price models as well as flexible monthly retainer sprints. You can use our WebNova Gullak tool or Smart Quote Assistant on this page to get an immediate customized estimate.',
    },
    {
      question: 'Can WebNova migrate our legacy database to modern ERP?',
      answer:
        'Absolutely. We have specialized migration pipelines that safely extract, normalize, and load legacy SQL, Excel, and spreadsheet data into our modern high-speed PostgreSQL and Cloud SQL ERP environments with zero data loss.',
    },
  ];

  return (
    <section className="py-20 relative z-10 bg-white">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-14">
          <span className="text-[11px] font-bold uppercase tracking-wider text-blue-700 block mb-2">
            FAQ
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight mb-4">
            Good questions. Clear answers.
          </h2>
          <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
            Find quick answers to the most common questions about our services, process and more.
          </p>
        </div>

        <div className="space-y-3.5">
          {faqs.map((faq, idx) => {
            const isOpen = openIndex === idx;
            return (
              <div
                key={faq.question}
                className={`rounded-2xl border transition-all duration-200 overflow-hidden ${
                  isOpen
                    ? 'bg-slate-50/90 border-blue-500/40 shadow-lg shadow-blue-950/20'
                    : 'bg-slate-50/40 border-slate-200/80 hover:border-slate-200'
                }`}
              >
                <button
                  onClick={() => setOpenIndex(isOpen ? null : idx)}
                  className="w-full px-6 py-4.5 flex items-center justify-between text-left focus:outline-none"
                >
                  <span className="text-sm sm:text-base font-bold text-slate-900 pr-4">
                    {faq.question}
                  </span>
                  <div
                    className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 transition-transform duration-200 ${
                      isOpen
                        ? 'bg-blue-600 text-white rotate-180'
                        : 'bg-slate-100 text-slate-500'
                    }`}
                  >
                    <ChevronDown className="w-4 h-4" />
                  </div>
                </button>

                {isOpen && (
                  <div className="px-6 pb-5 pt-1 text-xs sm:text-sm text-slate-600 leading-relaxed border-t border-slate-200/60 animate-in fade-in duration-150">
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
