import React from 'react';
import { Search, PenTool, Terminal, LineChart } from 'lucide-react';

export const ProcessSection: React.FC = () => {
  const steps = [
    {
      num: '01',
      title: 'Discover',
      desc: 'Understand your goals & needs.',
      details: 'Deep architecture auditing, stakeholder interviews, user journey maps, and technical boundary definition.',
      icon: <Search className="w-4 h-4 text-blue-700" />,
      color: 'from-blue-600 to-indigo-600',
    },
    {
      num: '02',
      title: 'Design',
      desc: 'Create the right strategy & design.',
      details: 'Interactive wireframing, high-fidelity Figma components, design systems, and rapid feedback loops.',
      icon: <PenTool className="w-4 h-4 text-cyan-700" />,
      color: 'from-cyan-500 to-blue-600',
    },
    {
      num: '03',
      title: 'Build',
      desc: 'Develop, test & launch.',
      details: 'Pragmatic TypeScript engineering, test-driven validation, CI/CD automated deployment, and edge caching.',
      icon: <Terminal className="w-4 h-4 text-purple-700" />,
      color: 'from-indigo-600 to-purple-600',
    },
    {
      num: '04',
      title: 'Grow',
      desc: 'Measure, optimize & scale.',
      details: 'Analytics tracking, conversion rate optimization, automated AI follow-ups, and ongoing feature sprints.',
      icon: <LineChart className="w-4 h-4 text-emerald-400" />,
      color: 'from-purple-600 to-emerald-500',
    },
  ];

  return (
    <section className="py-20 relative z-10 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-14">
          <span className="text-[11px] font-bold uppercase tracking-wider text-blue-700 block mb-2">
            Our Process
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight mb-4">
            From idea to impact.
          </h2>
          <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
            A simple, clear process to turn your vision into reality.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 relative">
          {steps.map((st, idx) => (
            <div
              key={st.num}
              className="p-6 rounded-2xl bg-slate-50/40 border border-slate-200/80 hover:border-blue-500/30 transition-all flex flex-col justify-between group hover:-translate-y-1 relative"
            >
              <div>
                <div className="flex items-center justify-between mb-4">
                  <div
                    className={`w-10 h-10 rounded-full bg-gradient-to-r ${st.color} flex items-center justify-center text-white text-xs font-mono font-bold shadow-md shadow-blue-900/30`}
                  >
                    {st.num}
                  </div>
                  <div className="p-2 rounded-lg bg-slate-100/60 text-slate-600">
                    {st.icon}
                  </div>
                </div>

                <h3 className="text-lg font-bold text-slate-900 mb-1.5 group-hover:text-blue-700 transition-colors">
                  {st.title}
                </h3>
                <p className="text-xs font-medium text-blue-700/90 mb-3">
                  {st.desc}
                </p>
                <p className="text-[11px] text-slate-500 leading-relaxed">
                  {st.details}
                </p>
              </div>

              <div className="pt-4 mt-6 border-t border-slate-200/60 flex items-center justify-between text-[10px] text-slate-500 font-mono">
                <span>Phase {idx + 1}</span>
                <span>Agile Iteration</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
