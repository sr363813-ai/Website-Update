import React from 'react';
import { Layers, Award, MessageSquare, Clock, HeartHandshake } from 'lucide-react';

export const ValueProps: React.FC = () => {
  const values = [
    {
      title: 'End-to-end solutions',
      desc: 'From initial design wireframes to production deployment and server hardening.',
      icon: <Layers className="w-5 h-5 text-blue-700" />,
    },
    {
      title: 'Skilled & experienced team',
      desc: 'Engineers, UI designers, and systems architects with enterprise track records.',
      icon: <Award className="w-5 h-5 text-purple-700" />,
    },
    {
      title: 'Transparent communication',
      desc: 'Weekly milestone reviews, clear Kanban visibility, and direct Slack/WhatsApp channels.',
      icon: <MessageSquare className="w-5 h-5 text-cyan-700" />,
    },
    {
      title: 'On-time delivery',
      desc: 'Sprint-based agile execution designed to guarantee agreed go-live milestones.',
      icon: <Clock className="w-5 h-5 text-indigo-400" />,
    },
    {
      title: 'Continuous support',
      desc: '24/7 proactive monitoring, vulnerability patching, and regular feature updates.',
      icon: <HeartHandshake className="w-5 h-5 text-emerald-400" />,
    },
  ];

  return (
    <section className="py-20 relative z-10 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-14">
          <span className="text-[11px] font-bold uppercase tracking-wider text-blue-700 block mb-2">
            Why WebNova
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight mb-4">
            More than just a service provider.
          </h2>
          <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
            We're your long-term digital partner, committed to your success.
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
          {values.map((v) => (
            <div
              key={v.title}
              className="p-5 rounded-2xl bg-slate-50/40 border border-slate-200/80 hover:border-blue-500/30 transition-all flex flex-col items-center text-center group"
            >
              <div className="w-12 h-12 rounded-xl bg-white border border-slate-200 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                {v.icon}
              </div>
              <h3 className="text-xs sm:text-sm font-bold text-slate-900 mb-2 leading-tight">
                {v.title}
              </h3>
              <p className="text-[11px] text-slate-500 leading-relaxed">
                {v.desc}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
