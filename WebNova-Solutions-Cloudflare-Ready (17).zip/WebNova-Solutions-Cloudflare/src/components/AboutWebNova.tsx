import React, { useState } from 'react';
import { Monitor, Cpu, Database, Smartphone, Globe, ArrowRight, ShieldCheck, Check } from 'lucide-react';

interface AboutWebNovaProps {
  onLearnMore?: () => void;
}

export const AboutWebNova: React.FC<AboutWebNovaProps> = ({ onLearnMore }) => {
  const [activeTab, setActiveTab] = useState<'Websites' | 'Systems' | 'AI Tools' | 'ERP' | 'Apps'>('Websites');
  const [showStoryModal, setShowStoryModal] = useState(false);

  const showcaseData = {
    Websites: {
      title: 'High-Converting Corporate & SaaS Sites',
      metric: '99/100 Google Lighthouse',
      features: ['Next.js App Router & SSR', 'Bespoke UI/UX with Micro-animations', 'Global CDN Edge Caching'],
      previewLabel: 'https://webnovasolutions.co.in/live-preview',
    },
    Systems: {
      title: 'Mission-Critical Business Automation',
      metric: 'Zero-Downtime Reliability',
      features: ['Automated Lead Scrapers & Webhooks', 'Stripe & Razorpay Billing Integrations', 'Custom Postgres & Cloud SQL Pipelines'],
      previewLabel: 'system.engine://v4.operations',
    },
    'AI Tools': {
      title: 'Intelligent Enterprise Agents & Copilots',
      metric: '< 150ms Response Latency',
      features: ['Private Context RAG Systems', 'Dynamic Quotation Engines', 'Natural Language Lead Qualification'],
      previewLabel: 'ai.webnova://agent-orchestrator',
    },
    ERP: {
      title: 'Connected Operational Infrastructure',
      metric: '100% Data Traceability',
      features: ['Inventory & Real-Time Stock Tracking', 'Multi-Branch Ledger & Taxation', 'Custom Role-Based Granular Permissions'],
      previewLabel: 'erp.webnova.internal://v2/ledger',
    },
    Apps: {
      title: 'Unified iOS & Android Mobile Ecosystems',
      metric: '60 FPS Native Performance',
      features: ['React Native & Flutter Codebases', 'Offline SQLite Sync & Queueing', 'Instant Push Notifications & Biometrics'],
      previewLabel: 'mobile.app://ios-android-bridge',
    },
  };

  const currentShowcase = showcaseData[activeTab];

  return (
    <section id="about" className="py-20 relative z-10 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left Text */}
          <div className="lg:col-span-5">
            <span className="text-[11px] font-bold uppercase tracking-wider text-blue-700 block mb-2">
              About WebNova
            </span>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight leading-tight mb-4">
              Make digital growth feel simple.
            </h2>
            <p className="text-sm text-slate-600 leading-relaxed mb-6">
              WebNova Solutions is a digital studio focused on websites, systems, AI-enabled tools, ERP and connected digital products that help businesses grow in the digital world.
            </p>
            <p className="text-xs text-slate-500 leading-relaxed mb-8">
              We eliminate technical friction so founders, enterprise operators, and fast-growing teams can focus on expanding market share and serving customers.
            </p>

            <button
              onClick={() => setShowStoryModal(true)}
              className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs transition-all shadow-md shadow-blue-600/30 flex items-center gap-2"
            >
              <span>Learn more about us</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Right: Multi-Device Digital Mockup with Interactive Category Tabs */}
          <div className="lg:col-span-7">
            <div className="bg-[#090e1a] border border-blue-500/30 rounded-2xl p-6 sm:p-8 backdrop-blur-xl shadow-2xl relative">
              {/* Category selector pills */}
              <div className="flex flex-wrap items-center gap-2 mb-6 pb-4 border-b border-slate-200">
                {(['Websites', 'Systems', 'AI Tools', 'ERP', 'Apps'] as const).map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setActiveTab(tab)}
                    className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
                      activeTab === tab
                        ? 'bg-blue-600 text-white shadow-md shadow-blue-600/20'
                        : 'bg-slate-50 text-slate-500 hover:text-slate-700 border border-slate-200'
                    }`}
                  >
                    {tab === 'Websites' && <Globe className="w-3.5 h-3.5" />}
                    {tab === 'Systems' && <Cpu className="w-3.5 h-3.5" />}
                    {tab === 'AI Tools' && <Monitor className="w-3.5 h-3.5" />}
                    {tab === 'ERP' && <Database className="w-3.5 h-3.5" />}
                    {tab === 'Apps' && <Smartphone className="w-3.5 h-3.5" />}
                    <span>{tab}</span>
                  </button>
                ))}
              </div>

              {/* Simulated Device Screen Mockup */}
              <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-2xl">
                {/* Browser/Window Header */}
                <div className="bg-slate-50/90 px-4 py-2.5 flex items-center justify-between border-b border-slate-200">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-rose-500/80" />
                    <span className="w-2.5 h-2.5 rounded-full bg-amber-500/80" />
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500/80" />
                  </div>
                  <div className="text-[10px] font-mono text-slate-500 bg-white/70 px-3 py-1 rounded border border-slate-200/80 max-w-[220px] truncate">
                    {currentShowcase.previewLabel}
                  </div>
                  <div className="w-12" />
                </div>

                {/* Inner Screen Content */}
                <div className="p-5 sm:p-6 bg-gradient-to-br from-slate-950 via-[#070b14] to-slate-900">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <span className="text-[10px] font-mono text-blue-400 uppercase tracking-widest block mb-1">
                        WebNova Showcase · {activeTab}
                      </span>
                      <h4 className="text-base sm:text-lg font-bold text-white">
                        {currentShowcase.title}
                      </h4>
                    </div>
                    <span className="text-xs font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-500/30 px-2.5 py-1 rounded-full font-semibold">
                      {currentShowcase.metric}
                    </span>
                  </div>

                  {/* Feature checklist */}
                  <div className="space-y-2 mb-4">
                    {currentShowcase.features.map((feat) => (
                      <div key={feat} className="flex items-center gap-2 text-xs text-slate-300">
                        <Check className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                        <span>{feat}</span>
                      </div>
                    ))}
                  </div>

                  {/* Wireframe UI visualization */}
                  <div className="grid grid-cols-3 gap-3 pt-4 border-t border-slate-200/80">
                    <div className="p-3 rounded-lg bg-white border border-slate-200">
                      <div className="h-2 w-12 bg-blue-500/40 rounded mb-2" />
                      <div className="h-4 w-16 bg-slate-700 rounded mb-1" />
                      <div className="h-1.5 w-10 bg-slate-100 rounded" />
                    </div>
                    <div className="p-3 rounded-lg bg-white border border-slate-200">
                      <div className="h-2 w-10 bg-purple-500/40 rounded mb-2" />
                      <div className="h-4 w-14 bg-slate-700 rounded mb-1" />
                      <div className="h-1.5 w-12 bg-slate-100 rounded" />
                    </div>
                    <div className="p-3 rounded-lg bg-white border border-slate-200">
                      <div className="h-2 w-14 bg-emerald-500/40 rounded mb-2" />
                      <div className="h-4 w-12 bg-slate-700 rounded mb-1" />
                      <div className="h-1.5 w-8 bg-slate-100 rounded" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Story Modal */}
      {showStoryModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
          <div className="bg-[#0c1222] border border-blue-500/40 rounded-2xl max-w-lg w-full p-6 sm:p-8 shadow-2xl relative">
            <h3 className="text-xl font-bold text-white mb-2">Our Story & Mission</h3>
            <p className="text-xs text-blue-300 font-mono mb-4">Founded with a vision to digitize ambitious brands.</p>
            <div className="space-y-3 text-xs text-slate-300 leading-relaxed mb-6">
              <p>
                At WebNova Solutions, we bridge the gap between creative visual aesthetics and heavy-duty engineering. We believe software shouldn&apos;t just look phenomenal — it must drive measurable revenue, eliminate manual human hours, and scale gracefully.
              </p>
              <p>
                Over the past several years, our team has architected digital experiences for e-commerce brands, high-growth startups, and established enterprises across India and global markets.
              </p>
            </div>
            <button
              onClick={() => setShowStoryModal(false)}
              className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs"
            >
              Close Overview
            </button>
          </div>
        </div>
      )}
    </section>
  );
};
