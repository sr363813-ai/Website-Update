import React, { useState } from 'react';
import { PiggyBank, Sparkles, CheckCircle2, TrendingUp, DollarSign } from 'lucide-react';

export const WebNovaGullak: React.FC = () => {
  const [budget, setBudget] = useState<number>(50000);
  const [currency, setCurrency] = useState<'INR' | 'USD'>('INR');
  const [goal, setGoal] = useState<string>('Business Growth');
  const [calculatedPlan, setCalculatedPlan] = useState<{
    leadBoost: string;
    roiMultiplier: string;
    allocation: { label: string; pct: number; color: string }[];
    bars: number[];
  }>({
    leadBoost: '+140% Inbound Leads',
    roiMultiplier: '3.8x Projected ROI',
    allocation: [
      { label: 'Web Architecture & UX', pct: 40, color: 'bg-blue-500' },
      { label: 'AI Lead Automation', pct: 25, color: 'bg-purple-500' },
      { label: 'Performance SEO & Ads', pct: 25, color: 'bg-cyan-500' },
      { label: 'Cloud Infrastructure', pct: 10, color: 'bg-emerald-500' },
    ],
    bars: [35, 52, 68, 85, 110, 145],
  });

  const [isCalculating, setIsCalculating] = useState(false);

  const handleGeneratePlan = () => {
    setIsCalculating(true);
    setTimeout(() => {
      let leadBoost = '+140% Inbound Leads';
      let roiMultiplier = '3.8x Projected ROI';
      let allocation = [
        { label: 'Web Architecture & UX', pct: 40, color: 'bg-blue-500' },
        { label: 'AI Lead Automation', pct: 25, color: 'bg-purple-500' },
        { label: 'Performance SEO & Ads', pct: 25, color: 'bg-cyan-500' },
        { label: 'Cloud Infrastructure', pct: 10, color: 'bg-emerald-500' },
      ];
      let bars = [35, 50, 70, 90, 115, 150];

      if (goal === 'Lead Generation') {
        leadBoost = '+210% Pipeline Volume';
        roiMultiplier = '4.5x Pipeline Return';
        allocation = [
          { label: 'Conversion Funnels & Landing', pct: 30, color: 'bg-blue-500' },
          { label: 'AI Lead Scoring Engine', pct: 35, color: 'bg-purple-500' },
          { label: 'Direct Inbound Campaigns', pct: 25, color: 'bg-cyan-500' },
          { label: 'CRM Integration', pct: 10, color: 'bg-emerald-500' },
        ];
        bars = [40, 65, 88, 115, 140, 185];
      } else if (goal === 'E-commerce Scale') {
        leadBoost = '+185% Cart Conversions';
        roiMultiplier = '5.2x Revenue Velocity';
        allocation = [
          { label: 'Storefront Speed & Checkout', pct: 45, color: 'bg-blue-500' },
          { label: 'Automated Cart Recovery AI', pct: 20, color: 'bg-purple-500' },
          { label: 'Performance Retargeting', pct: 25, color: 'bg-cyan-500' },
          { label: 'ERP Inventory Sync', pct: 10, color: 'bg-emerald-500' },
        ];
        bars = [50, 75, 105, 135, 165, 210];
      } else if (goal === 'Brand Awareness') {
        leadBoost = '+300% Organic Reach';
        roiMultiplier = '3.2x Authority Index';
        allocation = [
          { label: 'Brand Experience & Motion', pct: 50, color: 'bg-blue-500' },
          { label: 'Creative Content Hub', pct: 25, color: 'bg-purple-500' },
          { label: 'SEO & PR Distribution', pct: 15, color: 'bg-cyan-500' },
          { label: 'Hosting & CDN', pct: 10, color: 'bg-emerald-500' },
        ];
        bars = [30, 48, 72, 95, 120, 160];
      }

      setCalculatedPlan({
        leadBoost,
        roiMultiplier,
        allocation,
        bars,
      });
      setIsCalculating(false);
    }, 450);
  };

  const currencySymbol = currency === 'INR' ? '₹' : '$';

  return (
    <section className="py-20 relative z-10 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-14">
          <span className="text-[11px] font-bold uppercase tracking-wider text-blue-700 block mb-2">
            WebNova Gullak
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight mb-4">
            AI Budget & Growth Planner
          </h2>
          <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
            Plan your budget, track your goals and get AI-powered insights for smarter business growth.
          </p>
        </div>

        {/* The Gullak Planner Container (matches screenshot) */}
        <div className="bg-white border border-blue-500/30 rounded-2xl p-6 sm:p-10 shadow-2xl backdrop-blur-xl">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            {/* Left Inputs */}
            <div className="lg:col-span-6 space-y-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-700">
                    <PiggyBank className="w-4 h-4" />
                  </div>
                  <h3 className="text-lg font-bold text-slate-900">
                    WebNova Gullak
                  </h3>
                </div>

                {/* Currency Switcher */}
                <div className="flex items-center bg-slate-50 border border-slate-200 rounded-lg p-0.5 text-xs">
                  <button
                    onClick={() => {
                      setCurrency('INR');
                      if (currency === 'USD') setBudget(budget * 80);
                    }}
                    className={`px-2.5 py-1 rounded font-semibold transition-all ${
                      currency === 'INR' ? 'bg-blue-600 text-white' : 'text-slate-500 hover:text-white'
                    }`}
                  >
                    INR (₹)
                  </button>
                  <button
                    onClick={() => {
                      setCurrency('USD');
                      if (currency === 'INR') setBudget(Math.round(budget / 80));
                    }}
                    className={`px-2.5 py-1 rounded font-semibold transition-all ${
                      currency === 'USD' ? 'bg-blue-600 text-white' : 'text-slate-500 hover:text-white'
                    }`}
                  >
                    USD ($)
                  </button>
                </div>
              </div>

              {/* Monthly Budget Input */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-xs font-semibold text-slate-600">
                    Monthly Budget
                  </label>
                  <span className="text-xs font-mono text-cyan-700">
                    {currencySymbol} {budget.toLocaleString()}
                  </span>
                </div>
                <div className="relative">
                  <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-sm text-slate-500 font-mono">
                    {currencySymbol}
                  </span>
                  <input
                    type="number"
                    value={budget}
                    onChange={(e) => setBudget(Math.max(1000, Number(e.target.value)))}
                    className="w-full pl-8 pr-4 py-2.5 bg-slate-50/90 border border-slate-200/80 rounded-xl text-slate-900 text-sm focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                    placeholder="Enter monthly budget"
                  />
                </div>
                {/* Quick budget presets */}
                <div className="flex gap-2 mt-2.5">
                  {(currency === 'INR' ? [25000, 50000, 100000, 200000] : [500, 1000, 2500, 5000]).map((preset) => (
                    <button
                      key={preset}
                      onClick={() => setBudget(preset)}
                      className={`text-[11px] font-medium px-2.5 py-1 rounded-md border transition-all ${
                        budget === preset
                          ? 'bg-blue-950 border-blue-400 text-blue-700'
                          : 'bg-slate-50/60 border-slate-200 text-slate-500 hover:text-white'
                      }`}
                    >
                      {currencySymbol} {preset.toLocaleString()}
                    </button>
                  ))}
                </div>
              </div>

              {/* Goal Select */}
              <div>
                <label className="text-xs font-semibold text-slate-600 block mb-2">
                  Primary Business Goal
                </label>
                <select
                  value={goal}
                  onChange={(e) => setGoal(e.target.value)}
                  className="w-full px-4 py-2.5 bg-slate-50/90 border border-slate-200/80 rounded-xl text-slate-900 text-sm focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                >
                  <option value="Business Growth">Business Growth (All-in-one Expansion)</option>
                  <option value="Lead Generation">Lead Generation (High Conversion Pipeline)</option>
                  <option value="Brand Awareness">Brand Awareness (Modern Authority)</option>
                  <option value="E-commerce Scale">E-commerce Scale (D2C Velocity)</option>
                </select>
              </div>

              {/* CTA Button */}
              <button
                onClick={handleGeneratePlan}
                disabled={isCalculating}
                className="w-full py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-sm shadow-lg shadow-blue-600/30 transition-all flex items-center justify-center gap-2"
              >
                <Sparkles className={`w-4 h-4 ${isCalculating ? 'animate-spin' : ''}`} />
                <span>{isCalculating ? 'Computing Growth Matrix...' : 'Get AI Plan'}</span>
              </button>
            </div>

            {/* Right Output: "Your Growth Plan" (matches screenshot) */}
            <div className="lg:col-span-6 bg-white/70 border border-slate-200 rounded-xl p-6 sm:p-7 relative overflow-hidden">
              <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-200/80">
                <h4 className="text-sm font-bold text-white tracking-wide">
                  Your Growth Plan
                </h4>
                <div className="flex items-center gap-1.5 text-xs font-semibold text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-500/20">
                  <TrendingUp className="w-3.5 h-3.5" />
                  <span>{calculatedPlan.roiMultiplier}</span>
                </div>
              </div>

              {/* Checklist items */}
              <div className="space-y-2.5 mb-6">
                <div className="flex items-center gap-2.5 text-xs text-slate-700">
                  <CheckCircle2 className="w-4 h-4 text-blue-700 shrink-0" />
                  <span className="font-medium">Smart Budget Allocation</span>
                  <span className="text-[10px] text-slate-500">· Optimized for {goal}</span>
                </div>
                <div className="flex items-center gap-2.5 text-xs text-slate-700">
                  <CheckCircle2 className="w-4 h-4 text-cyan-700 shrink-0" />
                  <span className="font-medium">Growth Suggestions</span>
                  <span className="text-[10px] text-cyan-700 font-mono">({calculatedPlan.leadBoost})</span>
                </div>
                <div className="flex items-center gap-2.5 text-xs text-slate-700">
                  <CheckCircle2 className="w-4 h-4 text-purple-700 shrink-0" />
                  <span className="font-medium">Track Progress</span>
                  <span className="text-[10px] text-slate-500">· Automated Sprint KPIs</span>
                </div>
              </div>

              {/* Allocation Progress Bar */}
              <div className="mb-6">
                <div className="flex items-center justify-between text-[11px] text-slate-500 mb-2">
                  <span>Recommended Capital Split</span>
                  <span className="font-mono text-slate-900">100% Accounted</span>
                </div>
                <div className="w-full h-3 bg-slate-50 rounded-full overflow-hidden flex">
                  {calculatedPlan.allocation.map((item) => (
                    <div
                      key={item.label}
                      style={{ width: `${item.pct}%` }}
                      className={`${item.color} h-full transition-all duration-500`}
                      title={`${item.label}: ${item.pct}%`}
                    />
                  ))}
                </div>

                <div className="grid grid-cols-2 gap-2 mt-3">
                  {calculatedPlan.allocation.map((item) => (
                    <div key={item.label} className="flex items-center gap-2 text-[11px] text-slate-600">
                      <span className={`w-2 h-2 rounded-full ${item.color} shrink-0`} />
                      <span className="truncate">{item.label}</span>
                      <span className="font-mono text-slate-500 shrink-0">{item.pct}%</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Interactive Projection Chart (Visual bars matching screenshot) */}
              <div className="pt-4 border-t border-slate-200/80">
                <div className="flex items-center justify-between text-[11px] text-slate-500 mb-2">
                  <span>6-Month Projected Growth Trajectory</span>
                  <span className="text-cyan-700 font-mono font-medium">Month 1 to 6</span>
                </div>
                <div className="flex items-end justify-between h-20 gap-2 pt-2 px-2 bg-slate-50/60 rounded-lg">
                  {calculatedPlan.bars.map((height, i) => (
                    <div key={i} className="flex-1 flex flex-col items-center gap-1">
                      <div
                        style={{ height: `${(height / 220) * 100}%` }}
                        className="w-full bg-gradient-to-t from-blue-600 to-cyan-400 rounded-t-sm transition-all duration-500 hover:brightness-125"
                      />
                      <span className="text-[9px] text-slate-500 font-mono">M{i + 1}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
