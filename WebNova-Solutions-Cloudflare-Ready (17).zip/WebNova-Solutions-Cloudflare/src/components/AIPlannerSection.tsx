import React, { useState } from 'react';
import { Sparkles, ArrowRight } from 'lucide-react';

export const AIPlannerSection: React.FC = () => {
  const [idea, setIdea] = useState('');
  const [budget, setBudget] = useState('');
  const [timeline, setTimeline] = useState('');
  const [result, setResult] = useState('');
  const suggest = () => {
    if (!idea.trim()) { setResult('Describe your project idea first, and we’ll suggest a suitable service path.'); return; }
    const lower = idea.toLowerCase();
    const service = /erp|inventory|school|student|billing|admin|dashboard|management/.test(lower)
      ? 'a custom business system or ERP'
      : /shop|store|ecommerce|sell|payment|product/.test(lower)
      ? 'an e-commerce website'
      : /app|mobile|platform|portal|booking/.test(lower)
      ? 'a web application or customer portal'
      : /seo|marketing|social|traffic|brand/.test(lower)
      ? 'digital marketing and brand growth services'
      : 'a responsive business website';
    setResult(`Suggested direction: ${service}. ${budget ? `Budget: ${budget}. ` : ''}${timeline ? `Timeline: ${timeline}. ` : ''}This is an initial guide, not a quotation. Contact WebNova for a tailored scope and final estimate.`);
  };
  return <section id="ai-planner" className="relative overflow-hidden bg-gradient-to-br from-sky-50 via-white to-violet-50 py-16 sm:py-20">
    <div className="pointer-events-none absolute inset-0 opacity-40" style={{backgroundImage:'radial-gradient(#94a3b8 0.7px, transparent 0.7px)',backgroundSize:'8px 8px'}} />
    <div className="relative mx-auto grid max-w-7xl items-center gap-10 px-4 sm:px-6 lg:grid-cols-12 lg:px-8">
      <div className="lg:col-span-7">
        <p className="mb-5 flex items-center gap-3 text-sm font-bold uppercase tracking-[.22em] text-slate-500"><span className="h-px w-7 bg-blue-600"/>AI-enabled WebNova</p>
        <h2 className="max-w-3xl text-4xl font-extrabold leading-tight tracking-[-.04em] text-[#071531] sm:text-6xl">Smart tools for <span className="bg-gradient-to-r from-blue-600 to-violet-600 bg-clip-text text-transparent">faster decisions.</span></h2>
        <p className="mt-5 max-w-2xl text-base leading-7 text-slate-600 sm:text-lg">WebNova includes AI-style guidance for project planning, service matching, quotation direction, and support conversations. These tools help visitors understand what they need before the first call.</p>
        <div className="mt-8 grid gap-3 sm:grid-cols-2">
          {[['AI Planner','Suggests a suitable WebNova service from your requirements.'],['Quote Direction','Provides an initial estimate direction before a final quotation.'],['Smart Assistant','Helps answer common questions and route enquiries.'],['OTP Security','Supports secure account and form workflows when configured.']].map(([title,desc])=><div key={title} className="rounded-2xl border border-slate-200 bg-white/90 p-5 shadow-sm"><h3 className="font-bold text-[#071531]">{title}</h3><p className="mt-2 text-sm leading-6 text-slate-600">{desc}</p></div>)}
        </div>
      </div>
      <div className="lg:col-span-5">
        <div className="rounded-3xl border border-blue-100 bg-white/95 p-6 shadow-xl shadow-blue-950/5 sm:p-7">
          <div className="mb-6 flex items-center justify-between"><p className="text-xs font-extrabold uppercase tracking-[.18em] text-slate-500">AI Project Planner</p><span className="h-3 w-3 rounded-full bg-emerald-400 ring-4 ring-emerald-100"/></div>
          <label htmlFor="planner-idea" className="mb-2 block text-[11px] font-bold uppercase tracking-wider text-slate-500">What do you want to build?</label>
          <textarea id="planner-idea" value={idea} onChange={e=>setIdea(e.target.value)} placeholder="Example: I need a school ERP with admin login, fees, student records, and reports..." rows={4} className="w-full rounded-xl border border-slate-200 bg-white p-3 text-sm text-slate-800 outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100"/>
          <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div><label htmlFor="planner-budget" className="mb-2 block text-[11px] font-bold uppercase tracking-wider text-slate-500">Budget range</label><select id="planner-budget" value={budget} onChange={e=>setBudget(e.target.value)} className="w-full rounded-xl border border-slate-200 bg-white p-3 text-sm"><option value="">Choose budget</option><option>Under ₹10,000</option><option>₹10,000–₹30,000</option><option>₹30,000–₹75,000</option><option>₹75,000+</option><option>Need guidance</option></select></div>
            <div><label htmlFor="planner-timeline" className="mb-2 block text-[11px] font-bold uppercase tracking-wider text-slate-500">Timeline</label><select id="planner-timeline" value={timeline} onChange={e=>setTimeline(e.target.value)} className="w-full rounded-xl border border-slate-200 bg-white p-3 text-sm"><option value="">Choose timeline</option><option>Within 1 week</option><option>2–4 weeks</option><option>1–2 months</option><option>Flexible</option></select></div>
          </div>
          <button onClick={suggest} className="mt-4 inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-blue-600 to-violet-600 px-5 py-3 text-xs font-extrabold uppercase tracking-wide text-white shadow-lg shadow-blue-600/20 hover:-translate-y-0.5"><Sparkles size={15}/>Generate AI suggestion<ArrowRight size={15}/></button>
          <div aria-live="polite" className="mt-4 min-h-20 rounded-2xl border border-dashed border-blue-200 bg-blue-50/50 p-4 text-sm leading-6 text-slate-600">{result || 'Describe your idea and WebNova planner will suggest a suitable service path.'}</div>
          <a href="/#contact" className="mt-4 inline-flex items-center gap-2 text-sm font-bold text-blue-700">Discuss your project <ArrowRight size={15}/></a>
        </div>
      </div>
    </div>
  </section>;
};

export const BrandPromiseSection: React.FC = () => <section className="border-y border-slate-100 bg-white">
  <div className="mx-auto grid max-w-7xl gap-6 px-4 py-10 sm:px-6 md:grid-cols-[.8fr_2.5fr_.35fr] md:items-center lg:px-8">
    <div><p className="text-[10px] font-extrabold uppercase tracking-[.2em] text-violet-600">WN / 01</p><p className="mt-3 text-xs font-bold uppercase tracking-[.16em] text-slate-500">Our brand promise</p></div>
    <h2 className="text-2xl font-extrabold leading-tight tracking-[-.035em] text-[#071531] sm:text-3xl lg:text-4xl">We create digital experiences that feel <span className="text-violet-600">clear</span>, look <span className="text-violet-600">distinctive</span>, and help businesses move <span className="text-violet-600">forward.</span></h2>
    <div className="hidden text-right text-5xl font-black text-[#071531] md:block">W<span className="text-violet-600">+</span></div>
  </div>
  <div className="bg-[#071531] text-white"><div className="mx-auto grid max-w-7xl gap-5 px-4 py-5 text-xs sm:px-6 md:grid-cols-[1.5fr_1fr_1fr_1.2fr] md:items-center lg:px-8"><div><p className="text-[10px] font-extrabold uppercase tracking-widest text-cyan-300">Why WebNova</p><p className="mt-1 font-bold">Digital work with a clear purpose.</p></div><p><span className="mr-2 text-violet-300">01</span> Responsive by design</p><p><span className="mr-2 text-violet-300">02</span> Built for real business needs</p><p><span className="mr-2 text-violet-300">03</span> Direct founder-led communication</p></div></div>
</section>;
