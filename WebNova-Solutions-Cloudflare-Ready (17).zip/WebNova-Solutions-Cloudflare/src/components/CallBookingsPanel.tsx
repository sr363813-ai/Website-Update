import React, { useEffect, useMemo, useState } from 'react';
import { CalendarClock, CheckCircle2, Clock3, Download, Mail, MessageCircle, Phone, RefreshCw, Search, Video } from 'lucide-react';
import { collection, onSnapshot, orderBy, query, updateDoc, doc, serverTimestamp } from 'firebase/firestore';
import { db, firebaseConfigured } from '../firebase';
import { CALL_BOOKINGS_KEY, readCallBookings, type CallBooking } from './ScheduleCall';

const panel = 'rounded-2xl border border-slate-200 bg-white p-5 shadow-sm';
type Status = CallBooking['status'];
const statuses: Status[] = ['Pending', 'Contacted', 'Confirmed', 'Completed', 'Cancelled'];

export function CallBookingsPanel() {
  const [items, setItems] = useState<CallBooking[]>(readCallBookings);
  const [search, setSearch] = useState('');
  const [cloudMode, setCloudMode] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    const refresh = () => setItems(readCallBookings());
    window.addEventListener('webnova-call-booking', refresh);
    window.addEventListener('storage', refresh);
    if (!firebaseConfigured || !db) return () => {
      window.removeEventListener('webnova-call-booking', refresh);
      window.removeEventListener('storage', refresh);
    };
    const q = query(collection(db, 'callBookings'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, snapshot => {
      const remote: CallBooking[] = snapshot.docs.map(entry => {
        const value = entry.data();
        const created = value.createdAt?.toDate?.();
        return {
          id: String(value.id || entry.id), firestoreDocId: entry.id,
          name: String(value.name || ''), email: String(value.email || ''), phone: String(value.phone || ''),
          service: String(value.service || ''), date: String(value.date || ''), time: String(value.time || ''),
          meeting: value.meeting || 'Google Meet', details: String(value.details || ''),
          status: (value.status || 'Pending') as Status,
          submittedAt: created ? created.toISOString() : String(value.submittedAt || ''),
        };
      });
      const ids = new Set(remote.map(item => item.id));
      const localOnly = readCallBookings().filter(item => !ids.has(item.id));
      setItems([...remote, ...localOnly].sort((a,b) => b.submittedAt.localeCompare(a.submittedAt)));
      setCloudMode(true); setError('');
    }, err => { setCloudMode(false); setError(err.message || 'Could not load shared call bookings. Check Firestore rules.'); });
    return () => { unsubscribe(); window.removeEventListener('webnova-call-booking', refresh); window.removeEventListener('storage', refresh); };
  }, []);

  const filtered = useMemo(() => items.filter(item => `${item.id} ${item.name} ${item.email} ${item.phone} ${item.service} ${item.status}`.toLowerCase().includes(search.toLowerCase())), [items, search]);
  const updateStatus = async (item: CallBooking, status: Status) => {
    const updated = { ...item, status };
    const next = readCallBookings().map(existing => existing.id === item.id ? updated : existing);
    if (!next.some(existing => existing.id === item.id)) next.unshift(updated);
    localStorage.setItem(CALL_BOOKINGS_KEY, JSON.stringify(next));
    setItems(current => current.map(existing => existing.id === item.id ? updated : existing));
    if (item.firestoreDocId && db) {
      try { await updateDoc(doc(db, 'callBookings', item.firestoreDocId), { status, statusUpdatedAt: serverTimestamp() }); }
      catch (err) { setError(err instanceof Error ? `${err.message} — status saved locally only.` : 'Status saved locally only; cloud update failed.'); }
    }
  };
  const exportCsv = () => {
    const headers = ['Reference','Submitted','Name','Email','Phone','Service','Date','Time IST','Meeting','Status','Project details'];
    const rows = filtered.map(b => [b.id,b.submittedAt,b.name,b.email,b.phone,b.service,b.date,b.time,b.meeting,b.status,b.details]);
    const csv = [headers, ...rows].map(row => row.map(value => `"${String(value ?? '').replace(/"/g,'""')}"`).join(',')).join('\r\n');
    const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8;' }));
    const a = document.createElement('a'); a.href = url; a.download = 'webnova-call-bookings.csv'; a.click(); URL.revokeObjectURL(url);
  };

  return <div className="space-y-5">
    <section className={`${panel} bg-gradient-to-r from-[#071531] via-blue-950 to-violet-950 text-white`}>
      <div className="flex flex-wrap items-start justify-between gap-4"><div><div className="flex items-center gap-2 text-cyan-300"><CalendarClock size={19}/><span className="text-xs font-bold uppercase tracking-[.2em]">Consultation management</span></div><h2 className="mt-3 text-2xl font-extrabold">Schedule Call Requests</h2><p className="mt-2 max-w-2xl text-sm leading-6 text-blue-100">Every consultation request appears here. Review client details, contact the requester, and track each booking from pending to completed.</p></div><button onClick={exportCsv} className="inline-flex items-center gap-2 rounded-xl bg-white px-4 py-2 text-sm font-bold text-blue-950"><Download size={15}/> Export CSV</button></div>
      <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-4">{[{label:'All requests',value:items.length},{label:'Pending',value:items.filter(b=>b.status==='Pending').length},{label:'Confirmed',value:items.filter(b=>b.status==='Confirmed').length},{label:'Completed',value:items.filter(b=>b.status==='Completed').length}].map(stat=><div key={stat.label} className="rounded-xl border border-white/10 bg-white/5 p-4"><p className="text-xs text-blue-200">{stat.label}</p><p className="mt-1 text-2xl font-extrabold">{stat.value}</p></div>)}</div>
      <div className="mt-4 flex items-center gap-2 text-xs text-blue-100"><span className={`h-2 w-2 rounded-full ${cloudMode?'bg-emerald-400':'bg-amber-400'}`}/>{cloudMode?'Shared Firebase bookings connected':'Local browser mode — connect Firebase for cross-device admin access'}</div>
    </section>
    {error && <p role="alert" className="rounded-xl border border-amber-200 bg-amber-50 p-3 text-sm text-amber-900">{error}</p>}
    <section className={panel}>
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3"><div><h3 className="font-extrabold">Booking requests</h3><p className="mt-1 text-xs text-slate-500">Dates and times are the visitor's preferred slot, not a confirmed appointment.</p></div><label className="flex items-center gap-2 rounded-xl border border-slate-200 px-3"><Search size={15} className="text-slate-400"/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search bookings" className="w-48 py-2 text-sm outline-none"/></label></div>
      {filtered.length ? <div className="space-y-3">{filtered.map(item=><article key={item.id} className="rounded-xl border border-slate-200 p-4 hover:border-blue-200"><div className="flex flex-wrap items-start justify-between gap-4"><div className="min-w-0 flex-1"><div className="flex flex-wrap items-center gap-2"><h4 className="font-bold text-slate-900">{item.name || 'Unnamed requester'}</h4><span className="rounded-full bg-blue-50 px-2 py-1 text-[10px] font-bold text-blue-700">{item.id}</span><span className={`rounded-full px-2 py-1 text-[10px] font-bold ${item.status==='Confirmed'?'bg-emerald-100 text-emerald-700':item.status==='Cancelled'?'bg-rose-100 text-rose-700':'bg-amber-100 text-amber-800'}`}>{item.status}</span></div><p className="mt-1 text-sm text-slate-600">{item.service}</p><div className="mt-3 flex flex-wrap gap-3 text-xs text-slate-600"><span className="inline-flex items-center gap-1"><CalendarClock size={14}/>{item.date} · {item.time} IST</span><span className="inline-flex items-center gap-1"><Video size={14}/>{item.meeting}</span><span className="inline-flex items-center gap-1"><Mail size={14}/>{item.email}</span><span className="inline-flex items-center gap-1"><Phone size={14}/>{item.phone}</span></div><p className="mt-3 whitespace-pre-wrap break-words text-sm leading-6 text-slate-700">{item.details}</p><p className="mt-2 text-[11px] text-slate-400">Submitted {item.submittedAt ? new Date(item.submittedAt).toLocaleString() : 'recently'}</p></div><div className="flex min-w-[150px] flex-col gap-2"><label className="text-xs font-semibold text-slate-600">Update status<select value={item.status} onChange={e=>void updateStatus(item,e.target.value as Status)} className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-2 py-2 text-xs font-semibold text-slate-800">{statuses.map(status=><option key={status}>{status}</option>)}</select></label><a href={`mailto:${encodeURIComponent(item.email)}?subject=${encodeURIComponent(`WebNova consultation ${item.id}`)}`} className="inline-flex items-center justify-center gap-2 rounded-lg border border-slate-200 px-3 py-2 text-xs font-bold text-blue-700"><Mail size={14}/> Email client</a><a href={`https://wa.me/${item.phone.replace(/\D/g,'')}?text=${encodeURIComponent(`Hi ${item.name}, this is WebNova Solutions regarding your consultation request ${item.id}.`)}`} target="_blank" rel="noreferrer" className="inline-flex items-center justify-center gap-2 rounded-lg border border-emerald-200 bg-emerald-50 px-3 py-2 text-xs font-bold text-emerald-700"><MessageCircle size={14}/> WhatsApp</a></div></div></article>)}</div> : <div className="py-12 text-center"><CalendarClock size={34} className="mx-auto text-slate-300"/><h3 className="mt-3 font-bold">No call requests yet</h3><p className="mt-1 text-sm text-slate-500">When someone submits the Schedule a Call form, their details will appear here.</p></div>}
    </section>
    <p className="rounded-xl border border-blue-100 bg-blue-50 p-4 text-xs leading-5 text-blue-900"><strong>Admin workflow:</strong> Review the preferred slot, contact the client, update status, and send the confirmed meeting link manually. This page does not automatically create a Zoom or Google Meet meeting.</p>
  </div>;
}
