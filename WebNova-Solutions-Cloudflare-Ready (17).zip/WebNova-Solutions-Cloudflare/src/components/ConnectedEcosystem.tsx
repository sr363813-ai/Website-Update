import React from 'react';
import { Sparkles, Database, Smartphone, ArrowUpRight } from 'lucide-react';

export const ConnectedEcosystem: React.FC = () => {
  const platforms = [
    {
      id: 'solutions',
      title: 'WebNova Solutions',
      subtitle: 'Digital studio & consulting for your growth.',
      badge: 'Core Studio',
      icon: <Sparkles className="w-5 h-5 text-blue-700" />,
      features: ['Modern React & Next.js Stacks', 'High-Converting Web Design', 'Cloud Architecture & APIs'],
      gradient: 'from-blue-600/10 via-blue-500/5 to-transparent border-blue-500/20 hover:border-blue-500/40',
      tagColor: 'text-blue-700 bg-blue-50 border-blue-500/30',
    },
    {
      id: 'erp',
      title: 'WebNova ERP',
      subtitle: 'Manage operations, finance & resources.',
      badge: 'Business Core',
      icon: <Database className="w-5 h-5 text-cyan-700" />,
      features: ['Real-time Inventory & Billing', 'Automated Payroll & HRMS', 'Multi-tenant Data Security'],
      gradient: 'from-cyan-600/10 via-cyan-500/5 to-transparent border-cyan-500/20 hover:border-cyan-500/40',
      tagColor: 'text-cyan-700 bg-cyan-950/60 border-cyan-500/30',
    },
    {
      id: 'app',
      title: 'WebNova App',
      subtitle: 'Mobile apps for modern businesses.',
      badge: 'Cross-Platform',
      icon: <Smartphone className="w-5 h-5 text-purple-700" />,
      features: ['iOS & Android Native Performance', 'Offline-First Data Sync', 'Instant Push Notifications'],
      gradient: 'from-purple-600/10 via-purple-500/5 to-transparent border-purple-500/20 hover:border-purple-500/40',
      tagColor: 'text-purple-700 bg-purple-950/60 border-purple-500/30',
    },
  ];

  return (
    <section id="platforms" className="py-20 relative z-10 bg-white/90">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-14">
          <span className="text-[11px] font-bold uppercase tracking-wider text-blue-700 block mb-2">
            Connected Ecosystem
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight mb-4">
            One ecosystem. Endless possibilities.
          </h2>
          <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
            Our connected platforms work together to help you build, operate and grow your business — seamlessly.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {platforms.map((platform) => (
            <div
              key={platform.id}
              className={`p-7 rounded-2xl bg-gradient-to-b ${platform.gradient} border backdrop-blur-xl transition-all duration-300 hover:-translate-y-1 group flex flex-col justify-between`}
            >
              <div>
                <div className="flex items-center justify-between mb-5">
                  <div className="w-11 h-11 rounded-xl bg-slate-50 border border-slate-200/60 flex items-center justify-center group-hover:scale-105 transition-transform">
                    {platform.icon}
                  </div>
                  <span
                    className={`text-[10px] font-semibold px-2.5 py-0.5 rounded-full border ${platform.tagColor}`}
                  >
                    {platform.badge}
                  </span>
                </div>

                <h3 className="text-xl font-bold text-slate-900 mb-2 group-hover:text-blue-700 transition-colors">
                  {platform.title}
                </h3>
                <p className="text-xs text-slate-600 leading-relaxed mb-6">
                  {platform.subtitle}
                </p>

                <ul className="space-y-2 mb-8">
                  {platform.features.map((feat) => (
                    <li key={feat} className="flex items-center gap-2 text-xs text-slate-500">
                      <span className="w-1.5 h-1.5 rounded-full bg-blue-400 shrink-0" />
                      <span>{feat}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <a
                href="#services"
                className="flex items-center justify-between pt-4 border-t border-slate-200/80 text-xs font-semibold text-slate-600 group-hover:text-blue-700 transition-colors"
              >
                <span>Learn more</span>
                <ArrowUpRight className="w-4 h-4 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
              </a>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
