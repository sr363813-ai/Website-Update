import React from 'react';
import { Palette, Cpu, ShieldCheck } from 'lucide-react';

export const AssociateEcosystem: React.FC = () => {
  const associates = [
    {
      title: 'WebNova Creative',
      desc: 'Design & branding that inspires.',
      icon: <Palette className="w-5 h-5 text-purple-700" />,
      color: 'border-purple-500/20 bg-purple-950/20',
    },
    {
      title: 'Business Systems',
      desc: 'Process, automate, scale.',
      icon: <Cpu className="w-5 h-5 text-cyan-700" />,
      color: 'border-cyan-500/20 bg-cyan-950/20',
    },
    {
      title: 'Secure Flow',
      desc: 'Build smarter with AI compliance.',
      icon: <ShieldCheck className="w-5 h-5 text-indigo-400" />,
      color: 'border-indigo-500/20 bg-indigo-950/20',
    },
  ];

  return (
    <section id="ecosystem" className="py-20 relative z-10 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          <div className="lg:col-span-5">
            <span className="text-[11px] font-bold uppercase tracking-wider text-blue-700 block mb-2">
              Our Associate Ecosystem
            </span>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight mb-4">
              Together for greater impact.
            </h2>
            <p className="text-sm text-slate-600 leading-relaxed mb-6">
              We work with trusted partners and associate platforms to deliver more value, faster. From creative branding to automated enterprise pipelines, our network brings end-to-end execution.
            </p>
          </div>

          <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-3 gap-4">
            {associates.map((item) => (
              <div
                key={item.title}
                className={`p-5 rounded-2xl border ${item.color} backdrop-blur-xl transition-all hover:-translate-y-1`}
              >
                <div className="w-10 h-10 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-center mb-4">
                  {item.icon}
                </div>
                <h3 className="text-sm font-bold text-slate-900 mb-1.5">{item.title}</h3>
                <p className="text-xs text-slate-500 leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
