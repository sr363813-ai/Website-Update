import React, { useEffect, useState } from 'react';
import { ArrowRight, CheckCircle2, ClipboardList, Cpu, Globe2, ShieldCheck, Sparkles, X } from 'lucide-react';

const services = [
  'Website Design & Development', 'Mobile App Development', 'UI/UX Design',
  'E-commerce Development', 'ERP / CRM / Billing Software', 'AI Automation & Chatbots',
  'SEO & Digital Marketing', 'Website Maintenance', 'Other / Not Sure Yet',
];

export function ServiceRequestPrompt() {
  const [open, setOpen] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    if (sessionStorage.getItem('webnova_service_prompt_dismissed') === '1') return;
    const timer = window.setTimeout(() => setOpen(true), 2600);
    return () => window.clearTimeout(timer);
  }, []);

  const dismiss = () => {
    sessionStorage.setItem('webnova_service_prompt_dismissed', '1');
    setOpen(false);
  };
  const onSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setSubmitted(true);
    sessionStorage.setItem('webnova_service_prompt_dismissed', '1');
  };
  if (!open) return null;

  return <div className="fixed inset-0 z-[100] flex items-center justify-center overflow-y-auto bg-[#071531]/65 p-3 backdrop-blur-md sm:p-6" role="dialog" aria-modal="true" aria-labelledby="service-prompt-title">
    <div className="relative my-auto grid w-full max-w-5xl overflow-hidden rounded-[28px] border border-white/70 bg-white shadow-[0_30px_100px_-28px_rgba(4,14,40,.55)] lg:grid-cols-[.88fr_1.12fr]">
      <button type="button" onClick={dismiss} aria-label="Close service request form" className="absolute right-4 top-4 z-10 flex h-10 w-10 items-center justify-center rounded-full border border-slate-200 bg-white/90 text-slate-600 shadow-sm transition hover:rotate-90 hover:bg-slate-50"><X size={18}/></button>
      <aside className="relative overflow-hidden bg-gradient-to-br from-[#071531] via-[#102b65] to-[#5b21b6] p-6 text-white sm:p-8 lg:p-10">
        <div className="absolute -right-20 -top-20 h-64 w-64 rounded-full bg-cyan-400/20 blur-3xl"/><div className="absolute -bottom-20 -left-20 h-64 w-64 rounded-full bg-violet-400/25 blur-3xl"/>
        <div className="relative"><div className="inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-3 py-1.5 text-xs font-bold text-cyan-100"><Sparkles size={14}/> YOUR NEXT DIGITAL STEP</div>
          <h2 id="service-prompt-title" className="mt-6 max-w-md text-3xl font-black leading-tight tracking-tight sm:text-4xl">Need a service? <span className="bg-gradient-to-r from-cyan-300 to-violet-300 bg-clip-text text-transparent">WebNova is here to help.</span></h2>
          <p className="mt-4 max-w-md text-sm leading-6 text-blue-100 sm:text-base">Tell us what you’re planning. Our team will review your request and get in touch to discuss the right solution for your business.</p>
          <div className="mt-7 space-y-3">{[{icon:Globe2,text:'Websites and digital experiences'},{icon:Cpu,text:'AI, automation and business systems'},{icon:ClipboardList,text:'Clear next steps, no pressure'}].map(({icon:Icon,text})=><div key={text} className="flex items-center gap-3 rounded-xl border border-white/10 bg-white/[.07] p-3 text-sm text-white/95"><span className="flex h-9 w-9 items-center justify-center rounded-lg bg-white/10 text-cyan-200"><Icon size={18}/></span>{text}</div>)}</div>
          <div className="mt-8 flex items-center gap-2 text-xs text-blue-100"><ShieldCheck size={15} className="text-emerald-300"/> Your details are used to respond to this enquiry.</div>
        </div>
      </aside>
      <div className="p-5 sm:p-8 lg:p-10">
        {submitted ? <div className="flex min-h-[420px] flex-col items-center justify-center text-center"><span className="flex h-16 w-16 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-600"><CheckCircle2 size={34}/></span><h3 className="mt-5 text-2xl font-extrabold text-[#071531]">Thanks for reaching out!</h3><p className="mt-2 max-w-sm text-sm leading-6 text-slate-600">Your service enquiry has been submitted. It appears in the Form Inbox on this browser; shared admin access requires Firebase to be configured.</p><button type="button" onClick={dismiss} className="mt-6 rounded-xl bg-gradient-to-r from-blue-600 to-violet-600 px-6 py-3 text-sm font-bold text-white shadow-lg shadow-blue-600/20">Continue to website</button></div> : <>
          <div className="pr-10"><p className="text-xs font-extrabold uppercase tracking-[.18em] text-indigo-600">Service enquiry</p><h3 className="mt-2 text-2xl font-extrabold tracking-tight text-[#071531] sm:text-3xl">Let’s build something great.</h3><p className="mt-2 text-sm leading-6 text-slate-500">Complete this short form and we’ll contact you soon.</p></div>
          <form aria-label="Service Request Form" data-form-name="Service Request" onSubmit={onSubmit} className="mt-6 space-y-4">
            <div className="grid gap-4 sm:grid-cols-2"><div><label htmlFor="service-request-name" className="mb-1.5 block text-xs font-bold text-slate-700">Full name <span className="text-rose-500">*</span></label><input id="service-request-name" name="full_name" autoComplete="name" required maxLength={100} placeholder="Your name" className="w-full rounded-xl border border-slate-200 bg-white px-3.5 py-3 text-sm text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-blue-400 focus:ring-4 focus:ring-blue-100"/></div><div><label htmlFor="service-request-email" className="mb-1.5 block text-xs font-bold text-slate-700">Work email <span className="text-rose-500">*</span></label><input id="service-request-email" name="email" type="email" autoComplete="email" required maxLength={160} placeholder="you@company.com" className="w-full rounded-xl border border-slate-200 bg-white px-3.5 py-3 text-sm text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-blue-400 focus:ring-4 focus:ring-blue-100"/></div></div>
            <div className="grid gap-4 sm:grid-cols-2"><div><label htmlFor="service-request-phone" className="mb-1.5 block text-xs font-bold text-slate-700">Phone / WhatsApp</label><input id="service-request-phone" name="phone" type="tel" autoComplete="tel" maxLength={30} placeholder="+91 87650 51912" className="w-full rounded-xl border border-slate-200 bg-white px-3.5 py-3 text-sm text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-blue-400 focus:ring-4 focus:ring-blue-100"/></div><div><label htmlFor="service-request-type" className="mb-1.5 block text-xs font-bold text-slate-700">Service needed <span className="text-rose-500">*</span></label><select id="service-request-type" name="service_requested" required defaultValue="" className="w-full rounded-xl border border-slate-200 bg-white px-3.5 py-3 text-sm text-slate-900 outline-none transition focus:border-blue-400 focus:ring-4 focus:ring-blue-100"><option value="" disabled>Select a service</option>{services.map(service=><option key={service}>{service}</option>)}</select></div></div>
            <div><label htmlFor="service-request-budget" className="mb-1.5 block text-xs font-bold text-slate-700">Estimated budget</label><select id="service-request-budget" name="estimated_budget" defaultValue="Not sure yet" className="w-full rounded-xl border border-slate-200 bg-white px-3.5 py-3 text-sm text-slate-900 outline-none transition focus:border-blue-400 focus:ring-4 focus:ring-blue-100"><option>Not sure yet</option><option>Under ₹10,000</option><option>₹10,000–₹25,000</option><option>₹25,000–₹50,000</option><option>₹50,000–₹1,00,000</option><option>₹1,00,000+</option></select></div>
            <div><label htmlFor="service-request-message" className="mb-1.5 block text-xs font-bold text-slate-700">Tell us briefly about your project <span className="text-rose-500">*</span></label><textarea id="service-request-message" name="project_requirements" required maxLength={1200} rows={3} placeholder="What would you like to build or improve?" className="w-full resize-y rounded-xl border border-slate-200 bg-white px-3.5 py-3 text-sm text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-blue-400 focus:ring-4 focus:ring-blue-100"/></div>
            <label className="flex items-start gap-2 text-xs leading-5 text-slate-500"><input type="checkbox" name="contact_consent" value="yes" required className="mt-0.5 h-4 w-4 rounded accent-indigo-600"/><span>I agree that WebNova Solutions may contact me about this enquiry.</span></label>
            <button type="submit" className="group flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-blue-600 via-indigo-600 to-violet-600 px-5 py-3.5 text-sm font-extrabold text-white shadow-lg shadow-indigo-600/20 transition hover:-translate-y-0.5 hover:shadow-xl focus:outline-none focus:ring-4 focus:ring-indigo-200">Send service request <ArrowRight size={17} className="transition-transform group-hover:translate-x-1"/></button><p className="text-center text-[11px] leading-5 text-slate-400">A quick enquiry, not a commitment. You can close this form anytime.</p>
          </form>
        </>}
      </div>
    </div>
  </div>;
}
