import React from 'react';
import { ArrowRight, Sparkles, Compass } from 'lucide-react';
import { NetworkSphere } from './NetworkSphere.tsx';

interface HeroProps {
  onStartProject: () => void;
  onExploreWork: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onStartProject, onExploreWork }) => {
  return (
    <section
      id="hero"
      className="relative min-h-[90vh] pt-28 pb-16 lg:pt-36 lg:pb-24 flex items-center overflow-hidden"
    >
      {/* Background radial atmosphere */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[700px] h-[400px] bg-gradient-to-tr from-blue-700/10 via-indigo-600/10 to-purple-800/10 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute top-12 left-10 w-72 h-72 bg-blue-500/5 rounded-full blur-3xl pointer-events-none" />

      {/* Subtle background tech grid */}
      <div
        className="absolute inset-0 opacity-[0.03] pointer-events-none"
        style={{
          backgroundImage: `radial-gradient(circle at 1px 1px, #60a5fa 1px, transparent 0)`,
          backgroundSize: '36px 36px',
        }}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          {/* Left Column: Hero Copy & Actions */}
          <div className="lg:col-span-7 flex flex-col items-start text-left">
            {/* Pill Kicker */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-50 border border-blue-500/30 text-blue-700 text-xs font-semibold mb-6 backdrop-blur-md shadow-inner">
              <Sparkles className="w-3.5 h-3.5 text-blue-700 animate-pulse" />
              <span>WebNova digital studio</span>
            </div>

            {/* Headline */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-slate-900 tracking-tight leading-[1.1] mb-6">
              Where ideas <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-700 via-indigo-600 to-purple-700 animate-gradient">
                go digital.
              </span>
            </h1>

            {/* Subtitle */}
            <p className="text-base sm:text-lg text-slate-600 max-w-xl font-normal leading-relaxed mb-8">
              We build websites, systems and digital products that move businesses forward.
            </p>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center gap-4 mb-14">
              <button
                onClick={onExploreWork}
                className="px-6 py-3 rounded-xl bg-blue-600 text-white font-semibold text-sm hover:bg-blue-500 transition-all duration-200 shadow-lg shadow-blue-600/30 hover:shadow-blue-500/50 flex items-center gap-2 transform hover:-translate-y-0.5"
              >
                <Compass className="w-4 h-4 text-blue-200" />
                <span>Explore our work</span>
              </button>

              <button
                onClick={onStartProject}
                className="px-6 py-3 rounded-xl bg-white hover:bg-slate-100 text-slate-700 hover:text-white font-semibold text-sm border border-slate-200/80 hover:border-slate-300 transition-all duration-200 flex items-center gap-2 group backdrop-blur-sm"
              >
                <span>Start a project</span>
                <ArrowRight className="w-4 h-4 text-blue-700 group-hover:translate-x-1 transition-transform" />
              </button>
            </div>

            {/* Stats Metric Strip (matching screenshot) */}
            <div className="grid grid-cols-3 gap-6 sm:gap-10 pt-6 border-t border-slate-200/80 w-full max-w-lg">
              <div>
                <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-mono tabular-nums tracking-tight">
                  03
                </div>
                <div className="text-xs text-slate-500 font-medium mt-1">
                  Live platforms
                </div>
              </div>
              <div>
                <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-mono tabular-nums tracking-tight">
                  01
                </div>
                <div className="text-xs text-slate-500 font-medium mt-1">
                  Connected vision
                </div>
              </div>
              <div>
                <div className="text-2xl sm:text-3xl font-extrabold text-cyan-700 font-mono tabular-nums tracking-tight">
                  99+
                </div>
                <div className="text-xs text-slate-500 font-medium mt-1">
                  Room to grow
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: 3D Connected Sphere Canvas */}
          <div className="lg:col-span-5 flex items-center justify-center relative">
            <NetworkSphere />
          </div>
        </div>
      </div>
    </section>
  );
};
