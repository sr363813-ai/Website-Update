import React, { useEffect, useRef, useState } from 'react';
import { Globe, Cpu, Database, Layers, Wrench } from 'lucide-react';

interface NodeItem {
  id: string;
  label: string;
  icon: React.ReactNode;
  phi: number;
  theta: number;
  color: string;
  description: string;
  stat: string;
}

const NODES: NodeItem[] = [
  {
    id: 'websites',
    label: 'Websites',
    icon: <Globe className="w-3.5 h-3.5 text-blue-700" />,
    phi: 0.3,
    theta: 0.8,
    color: 'from-blue-500/20 to-blue-600/30 border-blue-500/40 text-blue-700',
    description: 'High-speed modern web applications & digital experiences',
    stat: '99.98% Uptime',
  },
  {
    id: 'ai-tools',
    label: 'AI Tools',
    icon: <Cpu className="w-3.5 h-3.5 text-purple-700" />,
    phi: -0.4,
    theta: 2.3,
    color: 'from-purple-500/20 to-purple-600/30 border-purple-500/50 text-purple-800',
    description: 'Smart agents, predictive lead scoring & workflow automation',
    stat: '10x Productivity',
  },
  {
    id: 'erp',
    label: 'ERP',
    icon: <Database className="w-3.5 h-3.5 text-cyan-700" />,
    phi: 0.6,
    theta: 3.8,
    color: 'from-cyan-500/20 to-cyan-600/30 border-cyan-500/50 text-cyan-800',
    description: 'Operations, inventory, billing & resource planning engines',
    stat: 'Real-time Sync',
  },
  {
    id: 'digital-products',
    label: 'Digital Products',
    icon: <Layers className="w-3.5 h-3.5 text-indigo-400" />,
    phi: -0.5,
    theta: 5.1,
    color: 'from-indigo-500/20 to-indigo-600/30 border-indigo-500/50 text-indigo-800',
    description: 'Cross-platform mobile apps & SaaS platforms',
    stat: 'Multi-device',
  },
  {
    id: 'tools',
    label: 'Tools',
    icon: <Wrench className="w-3.5 h-3.5 text-violet-400" />,
    phi: 0.7,
    theta: 1.6,
    color: 'from-violet-500/20 to-violet-600/30 border-violet-500/50 text-violet-800',
    description: 'Internal developer APIs, analytics & automation suites',
    stat: 'Custom APIs',
  },
];

export const NetworkSphere: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [activeNode, setActiveNode] = useState<NodeItem | null>(null);
  const [nodePositions, setNodePositions] = useState<{ [id: string]: { x: number; y: number; visible: boolean } }>({});
  const rotationRef = useRef({ x: 0.2, y: 0 });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = canvas.parentElement?.clientWidth || 500);
    let height = (canvas.height = canvas.parentElement?.clientHeight || 500);

    const handleResize = () => {
      if (!canvas || !canvas.parentElement) return;
      width = canvas.width = canvas.parentElement.clientWidth;
      height = canvas.height = canvas.parentElement.clientHeight;
    };
    window.addEventListener('resize', handleResize);

    // Generate sphere points
    const pointsCount = 520;
    const radius = Math.min(width, height) * 0.37;
    const spherePoints: { x: number; y: number; z: number; size: number; alpha: number }[] = [];

    for (let i = 0; i < pointsCount; i++) {
      const u = Math.random();
      const v = Math.random();
      const theta = u * 2.0 * Math.PI;
      const phi = Math.acos(2.0 * v - 1.0);
      const r = radius * (0.95 + Math.random() * 0.1);
      const sinPhi = Math.sin(phi);
      spherePoints.push({
        x: r * sinPhi * Math.cos(theta),
        y: r * sinPhi * Math.sin(theta),
        z: r * Math.cos(phi),
        size: Math.random() * 2.0 + 1.0,
        alpha: Math.random() * 0.45 + 0.5,
      });
    }

    let rotY = 0;
    let rotX = 0.25;

    const render = () => {
      ctx.clearRect(0, 0, width, height);
      const cx = width / 2;
      const cy = height / 2;

      rotY += 0.004;
      rotationRef.current.y = rotY;

      // Glow behind sphere
      const gradient = ctx.createRadialGradient(cx, cy, 10, cx, cy, radius * 1.25);
      gradient.addColorStop(0, 'rgba(37, 99, 235, 0.42)');
      gradient.addColorStop(0.5, 'rgba(124, 58, 237, 0.25)');
      gradient.addColorStop(1, 'rgba(7, 11, 20, 0)');
      ctx.fillStyle = gradient;
      ctx.beginPath();
      ctx.arc(cx, cy, radius * 1.3, 0, Math.PI * 2);
      ctx.fill();

      // Draw latitude/longitude ring contours
      ctx.strokeStyle = 'rgba(37, 99, 235, 0.58)';
      ctx.lineWidth = 1;
      for (let lat = -60; lat <= 60; lat += 30) {
        const radLat = (lat * Math.PI) / 180;
        const rLat = radius * Math.cos(radLat);
        const yLat = radius * Math.sin(radLat);

        ctx.beginPath();
        for (let lon = 0; lon <= 360; lon += 10) {
          const radLon = (lon * Math.PI) / 180 + rotY;
          const x = rLat * Math.sin(radLon);
          const z = rLat * Math.cos(radLon);

          // Rotate around X
          const yRot = yLat * Math.cos(rotX) - z * Math.sin(rotX);
          const zRot = yLat * Math.sin(rotX) + z * Math.cos(rotX);

          const scale = 500 / (500 + zRot);
          const screenX = cx + x * scale;
          const screenY = cy + yRot * scale;

          if (lon === 0) ctx.moveTo(screenX, screenY);
          else ctx.lineTo(screenX, screenY);
        }
        ctx.stroke();
      }

      // Rotate and project particle points
      const projectedPoints: { x: number; y: number; z: number; size: number; alpha: number }[] = [];

      spherePoints.forEach((p) => {
        // Rotate Y
        const cosY = Math.cos(rotY);
        const sinY = Math.sin(rotY);
        const x1 = p.x * cosY - p.z * sinY;
        const z1 = p.x * sinY + p.z * cosY;

        // Rotate X
        const cosX = Math.cos(rotX);
        const sinX = Math.sin(rotX);
        const y2 = p.y * cosX - z1 * sinX;
        const z2 = p.y * sinX + z1 * cosX;

        const scale = 500 / (500 + z2);
        projectedPoints.push({
          x: cx + x1 * scale,
          y: cy + y2 * scale,
          z: z2,
          size: p.size * scale,
          alpha: p.alpha * ((z2 + radius) / (2 * radius) * 0.7 + 0.3),
        });
      });

      // Draw connection lines between nearby points
      ctx.lineWidth = 0.6;
      for (let i = 0; i < projectedPoints.length; i += 7) {
        const p1 = projectedPoints[i];
        if (p1.z < -radius * 0.3) continue;
        for (let j = i + 1; j < projectedPoints.length; j += 12) {
          const p2 = projectedPoints[j];
          const dist = Math.hypot(p1.x - p2.x, p1.y - p2.y);
          if (dist < 45) {
            ctx.strokeStyle = `rgba(37, 99, 235, ${0.48 * (1 - dist / 45)})`;
            ctx.beginPath();
            ctx.moveTo(p1.x, p1.y);
            ctx.lineTo(p2.x, p2.y);
            ctx.stroke();
          }
        }
      }

      // Draw particle points
      projectedPoints.forEach((p) => {
        ctx.fillStyle = p.z > 0 ? `rgba(8, 105, 250, ${Math.min(1, p.alpha)})` : `rgba(124, 58, 237, ${p.alpha * 0.82})`;
        ctx.beginPath();
        ctx.arc(p.x, p.y, Math.max(0.6, p.size), 0, Math.PI * 2);
        ctx.fill();
      });

      // Calculate 3D positions of the featured nodes
      const newPositions: { [id: string]: { x: number; y: number; visible: boolean } } = {};

      NODES.forEach((node) => {
        const nodeR = radius * 1.05;
        const thetaRot = node.theta + rotY;

        const x0 = nodeR * Math.cos(node.phi) * Math.sin(thetaRot);
        const y0 = nodeR * Math.sin(node.phi);
        const z0 = nodeR * Math.cos(node.phi) * Math.cos(thetaRot);

        const cosX = Math.cos(rotX);
        const sinX = Math.sin(rotX);
        const y1 = y0 * cosX - z0 * sinX;
        const z1 = y0 * sinX + z0 * cosX;

        const scale = 500 / (500 + z1);
        const screenX = cx + x0 * scale;
        const screenY = cy + y1 * scale;

        // Draw connecting ray from sphere center to node point
        ctx.strokeStyle = z1 > 0 ? 'rgba(99, 102, 241, 0.4)' : 'rgba(99, 102, 241, 0.1)';
        ctx.lineWidth = 1;
        ctx.setLineDash([3, 4]);
        ctx.beginPath();
        ctx.moveTo(cx, cy);
        ctx.lineTo(screenX, screenY);
        ctx.stroke();
        ctx.setLineDash([]);

        // Pulsing glowing target ring
        ctx.strokeStyle = z1 > 0 ? 'rgba(56, 189, 248, 0.8)' : 'rgba(56, 189, 248, 0.25)';
        ctx.fillStyle = z1 > 0 ? 'rgba(59, 130, 246, 0.4)' : 'rgba(59, 130, 246, 0.1)';
        ctx.beginPath();
        ctx.arc(screenX, screenY, 6 * scale, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();

        newPositions[node.id] = {
          x: screenX,
          y: screenY,
          visible: z1 > -radius * 0.4,
        };
      });

      setNodePositions(newPositions);
      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  return (
    <div className="relative w-full h-[380px] sm:h-[440px] lg:h-[500px] flex items-center justify-center select-none overflow-visible">
      {/* Background ambient circular glow */}
      <div className="absolute w-72 h-72 sm:w-96 sm:h-96 rounded-full bg-blue-600/25 filter blur-3xl animate-pulse pointer-events-none" />
      <div className="absolute w-60 h-60 rounded-full bg-purple-600/25 filter blur-2xl animate-pulse pointer-events-none" />

      {/* 3D Canvas */}
      <canvas ref={canvasRef} className="w-full h-full block relative z-10 drop-shadow-[0_0_18px_rgba(37,99,235,0.24)]" />

      {/* Floating Interactive Platform Badges */}
      {NODES.map((node) => {
        const pos = nodePositions[node.id];
        if (!pos || !pos.visible) return null;

        const isHovered = activeNode?.id === node.id;

        return (
          <div
            key={node.id}
            style={{
              position: 'absolute',
              left: `${pos.x}px`,
              top: `${pos.y}px`,
              transform: 'translate(-50%, -50%)',
              transition: 'transform 0.1s ease-out',
            }}
            onMouseEnter={() => setActiveNode(node)}
            onMouseLeave={() => setActiveNode(null)}
            className="z-20 cursor-pointer"
          >
            <div
              className={`flex items-center gap-2 px-3 py-1.5 rounded-full backdrop-blur-md border text-xs font-medium shadow-lg transition-all duration-300 ${
                isHovered
                  ? 'bg-blue-950/90 border-blue-400 scale-110 shadow-blue-500/40 text-white'
                  : `bg-white/70 ${node.color} hover:scale-105`
              }`}
            >
              <span className="p-1 rounded-full bg-white shrink-0">
                {node.icon}
              </span>
              <span className="whitespace-nowrap font-semibold tracking-wide">
                {node.label}
              </span>
            </div>

            {/* Hover tooltip card */}
            {isHovered && (
              <div className="absolute left-1/2 -bottom-2 translate-y-full -translate-x-1/2 w-48 p-2.5 rounded-xl bg-slate-50/95 border border-blue-500/30 shadow-2xl backdrop-blur-xl text-left pointer-events-none z-30 animate-in fade-in zoom-in-95 duration-150">
                <div className="flex items-center justify-between text-[11px] font-semibold text-blue-700 mb-1">
                  <span>{node.label}</span>
                  <span className="text-[10px] text-emerald-800 font-mono bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-500/40">
                    {node.stat}
                  </span>
                </div>
                <p className="text-[11px] text-slate-600 leading-snug">
                  {node.description}
                </p>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
};
