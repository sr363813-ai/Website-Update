import React from 'react';
import { ArrowUpRight, Building2, ShoppingBag, GraduationCap, HeartPulse, CheckCircle2, Sparkles } from 'lucide-react';

const industries = [
  { icon: <Building2 className="h-5 w-5" />, title: 'Growing businesses', copy: 'Professional websites, lead-generation journeys, and connected business tools.' },
  { icon: <ShoppingBag className="h-5 w-5" />, title: 'Retail & e-commerce', copy: 'Clear product experiences, conversion-focused storefronts, and useful automation.' },
  { icon: <GraduationCap className="h-5 w-5" />, title: 'Education & training', copy: 'Informative websites, course journeys, and digital experiences built for learners.' },
  { icon: <HeartPulse className="h-5 w-5" />, title: 'Professional services', copy: 'Trust-building websites that explain your value and make enquiries easy.' },
];

const benefits = [
  'Mobile-first, responsive experiences',
  'Search-friendly page structure and metadata',
  'Accessible layouts with clear calls to action',
  'Performance-conscious implementation',
  'Analytics-ready goals and conversion journeys',
  'Scalable foundations for future growth',
];

export const SEOContentSection: React.FC = () => (
  <section aria-labelledby="growth-heading" className="relative overflow-hidden bg-slate-950 py-20 text-white sm:py-24">
    <div className="absolute -right-32 -top-32 h-96 w-96 rounded-full bg-blue-600/20 blur-3xl" />
    <div className="absolute -bottom-32 -left-24 h-80 w-80 rounded-full bg-violet-600/20 blur-3xl" />
    <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
      <div className="grid gap-12 lg:grid-cols-2 lg:items-center">
        <div>
          <span className="mb-4 inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-3 py-1.5 text-xs font-semibold tracking-wide text-cyan-200"><Sparkles className="h-4 w-4" /> Built for meaningful growth</span>
          <h2 id="growth-heading" className="max-w-2xl text-3xl font-extrabold leading-tight tracking-tight sm:text-4xl lg:text-5xl">A stronger digital presence starts with the right foundation.</h2>
          <p className="mt-5 max-w-xl text-base leading-7 text-slate-300">WebNova Solutions brings website development, UI/UX design, search engine optimization, business software, and AI automation together in one connected digital strategy. We focus on useful experiences that help visitors understand your offer, trust your business, and take the next step.</p>
          <div className="mt-8 flex flex-wrap gap-3">
            <a href="#contact" className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-blue-500 to-violet-500 px-5 py-3 text-sm font-bold text-white shadow-lg shadow-blue-950/40 transition hover:-translate-y-0.5">Discuss your project <ArrowUpRight className="h-4 w-4" /></a>
            <a href="#services" className="inline-flex items-center gap-2 rounded-xl border border-white/20 px-5 py-3 text-sm font-semibold text-white transition hover:bg-white/10">Explore services</a>
          </div>
        </div>
        <div className="rounded-3xl border border-white/10 bg-white/[0.06] p-6 shadow-2xl shadow-black/20 backdrop-blur sm:p-8">
          <h3 className="text-lg font-bold">Designed around the details that matter</h3>
          <p className="mt-2 text-sm leading-6 text-slate-300">A polished website should look great and make it easy for people—and search engines—to understand what you do.</p>
          <ul className="mt-6 grid gap-4 sm:grid-cols-2">
            {benefits.map((benefit) => <li key={benefit} className="flex items-start gap-3 text-sm leading-6 text-slate-200"><CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-cyan-300" />{benefit}</li>)}
          </ul>
          <p className="mt-6 border-t border-white/10 pt-5 text-xs leading-5 text-slate-400">SEO results depend on competition, content quality, site health, and ongoing work; no ranking position can be guaranteed.</p>
        </div>
      </div>
      <div className="mt-16 border-t border-white/10 pt-12">
        <div className="mb-7 max-w-2xl">
          <h3 className="text-2xl font-extrabold tracking-tight sm:text-3xl">Digital solutions for different kinds of teams</h3>
          <p className="mt-3 text-sm leading-6 text-slate-300">Start with the challenge you need to solve. We can shape the right combination of design, development, marketing, and automation around your goals.</p>
        </div>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {industries.map((item) => <article key={item.title} className="rounded-2xl border border-white/10 bg-white/[0.04] p-5 transition duration-300 hover:-translate-y-1 hover:border-cyan-300/40 hover:bg-white/[0.07]">
            <div className="mb-4 flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-blue-500/25 to-violet-500/25 text-cyan-200">{item.icon}</div>
            <h4 className="font-bold text-white">{item.title}</h4>
            <p className="mt-2 text-sm leading-6 text-slate-300">{item.copy}</p>
          </article>)}
        </div>
      </div>
    </div>
  </section>
);
