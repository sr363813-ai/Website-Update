import React from 'react';

interface LogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  showTagline?: boolean;
  lightText?: boolean;
}

export const Logo: React.FC<LogoProps> = ({ className = '', size = 'md' }) => {
  const sizes = { sm: 'h-9', md: 'h-12', lg: 'h-16' };
  return (
    <img
      src="/webnova-logo.png"
      alt="WebNova Solutions — We build websites that grow businesses"
      className={`${sizes[size]} w-auto max-w-[190px] object-contain ${className}`}
      loading="eager"
    />
  );
};
