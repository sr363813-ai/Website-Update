import React, { useState, useEffect } from 'react';
import { Logo } from './Logo.tsx';
import { Menu, X, ArrowRight, UserCheck } from 'lucide-react';

interface NavbarProps {
  onOpenLogin: () => void;
  userPhone?: string | null;
  onLogout?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenLogin,
  userPhone,
  onLogout,
}) => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', href: '#hero' },
    { name: 'Services', href: '#services' },
    { name: 'Portfolio', href: '/portfolio' },
    { name: 'Free SEO Audit', href: '/seo-audit' },
    { name: 'AI Tools', href: '#ai-command' },
    { name: 'Blog', href: '/blog' },
    { name: 'Contact', href: '#contact' },
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'bg-white/90 backdrop-blur-xl border-b border-slate-200/80 shadow-lg shadow-black/30 py-3'
          : 'bg-transparent py-4'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-6">
          {/* Brand Logo */}
          <a href="#hero" className="shrink-0 flex items-center">
            <Logo size="md" />
          </a>

          {/* Desktop Nav Links */}
          <nav className="hidden xl:flex items-center gap-5 text-[13px] font-medium text-slate-600">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="hover:text-blue-700 transition-colors whitespace-nowrap py-1 relative group"
              >
                {link.name}
                <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-blue-400 to-indigo-500 transition-all duration-200 group-hover:w-full" />
              </a>
            ))}
          </nav>

          {/* Action Area: Login / Portal */}
          <div className="hidden sm:flex items-center gap-3 shrink-0">
            {userPhone ? (
              <div className="flex items-center gap-2">
                <button
                  onClick={onOpenLogin}
                  className="flex items-center gap-2 px-3.5 py-1.5 rounded-lg bg-blue-950/80 border border-blue-500/40 text-blue-700 text-xs font-semibold hover:bg-blue-50/60 transition-all"
                >
                  <UserCheck className="w-3.5 h-3.5 text-blue-700" />
                  <span>Dashboard</span>
                </button>
                {onLogout && (
                  <button
                    onClick={onLogout}
                    className="text-xs text-slate-500 hover:text-rose-400 transition-colors px-2 py-1"
                  >
                    Logout
                  </button>
                )}
              </div>
            ) : (
              <button
                onClick={onOpenLogin}
                className="px-5 py-2 text-xs font-semibold text-white bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 rounded-lg shadow-md shadow-blue-600/30 transition-all transform hover:-translate-y-0.5 whitespace-nowrap"
              >
                Login
              </button>
            )}
          </div>

          {/* Mobile hamburger button */}
          <div className="flex xl:hidden items-center gap-2">
            <button
              onClick={onOpenLogin}
              className="sm:hidden px-3 py-1.5 text-xs font-semibold text-white bg-blue-600 rounded-lg"
            >
              Login
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-slate-700 hover:text-blue-700 rounded-lg focus:outline-none"
              aria-label="Toggle Navigation Menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="xl:hidden bg-[#090e1a]/95 backdrop-blur-2xl border-b border-slate-200 px-6 py-5 shadow-2xl animate-in slide-in-from-top-4 duration-200">
          <div className="flex flex-col gap-3">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="text-sm font-medium text-slate-100 hover:text-cyan-300 py-1.5 transition-colors border-b border-white/10"
              >
                {link.name}
              </a>
            ))}
            <div className="pt-2 flex items-center justify-between">
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenLogin();
                }}
                className="w-full flex items-center justify-center gap-2 py-2.5 text-xs font-semibold text-white bg-gradient-to-r from-blue-600 to-indigo-600 rounded-lg shadow-lg"
              >
                <span>{userPhone ? 'Open Dashboard' : 'Login to User Portal'}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
