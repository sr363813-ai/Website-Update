import { useEffect } from 'react';
import { addDoc, collection, serverTimestamp } from 'firebase/firestore';
import { db, firebaseConfigured } from '../firebase';

export type FormSubmission = {
  id: string;
  firestoreDocId?: string;
  submittedAt: string;
  page: string;
  formName: string;
  fields: Record<string, string>;
};

export const FORM_SUBMISSIONS_KEY = 'webnova_form_submissions_v1';
const configuredTurnstileKey = (import.meta as ImportMeta & { env?: Record<string, string | undefined> }).env?.VITE_TURNSTILE_SITE_KEY || '';
const TURNSTILE_SITE_KEY = configuredTurnstileKey.startsWith('0x') ? configuredTurnstileKey : '';
declare global { interface Window { turnstile?: { render: (container: HTMLElement, options: Record<string, unknown>) => string; reset?: (widgetId?: string) => void }; } }

export function readFormSubmissions(): FormSubmission[] {
  try {
    const value = JSON.parse(localStorage.getItem(FORM_SUBMISSIONS_KEY) || '[]');
    return Array.isArray(value) ? value : [];
  } catch {
    return [];
  }
}

function saveSubmission(submission: FormSubmission) {
  const current = readFormSubmissions();
  localStorage.setItem(FORM_SUBMISSIONS_KEY, JSON.stringify([submission, ...current].slice(0, 500)));
  window.dispatchEvent(new CustomEvent('webnova-form-submission', { detail: submission }));
}

/**
 * Adds a lightweight human-check challenge to every HTML form and records
 * non-secret form fields for the Admin > Form Inbox. With Firebase configured,
 * submissions are also saved centrally; CAPTCHA still needs server verification.
 */
export function FormSecurityAndCapture() {
  useEffect(() => {
    const mountTurnstile = (form: HTMLFormElement) => {
      if (!TURNSTILE_SITE_KEY || !window.turnstile) return;
      const holder = form.querySelector<HTMLElement>('[data-webnova-turnstile]');
      if (!holder || holder.dataset.widgetMounted === 'true') return;
      holder.dataset.widgetMounted = 'true';
      window.turnstile.render(holder, {
        sitekey: TURNSTILE_SITE_KEY,
        theme: 'light',
        callback: () => {
          const message = holder.querySelector<HTMLElement>('[data-turnstile-message]');
          if (message) message.textContent = 'Challenge completed. Submit the form to finish verification.';
        },
        'expired-callback': () => {
          form.dataset.webnovaCaptchaPassed = 'false';
          holder.dataset.widgetMounted = 'false';
        },
        'error-callback': () => {
          const message = holder.querySelector<HTMLElement>('[data-turnstile-message]');
          if (message) message.textContent = 'CAPTCHA could not load. Please refresh and try again.';
        },
      });
    };

    const attach = (form: HTMLFormElement) => {
      if (form.dataset.webnovaSecured === 'true') { mountTurnstile(form); return; }
      if (form.closest('[data-no-global-captcha="true"]')) return;
      form.dataset.webnovaSecured = 'true';
      form.dataset.webnovaCaptchaPassed = 'false';

      const block = document.createElement('fieldset');
      block.dataset.webnovaCaptcha = 'true';
      block.className = 'my-4 rounded-xl border border-blue-100 bg-blue-50/70 p-3 text-sm text-slate-800';
      if (TURNSTILE_SITE_KEY) {
        block.innerHTML = `
          <legend class="px-1 text-xs font-bold text-slate-700">Security verification</legend>
          <div data-webnova-turnstile class="min-h-[65px]"></div>
          <p data-turnstile-message class="mt-2 text-xs text-slate-600">Complete the Cloudflare security challenge before submitting.</p>
        `;
      } else {
        const a = Math.floor(Math.random() * 8) + 2;
        const b = Math.floor(Math.random() * 8) + 1;
        block.dataset.captchaExpected = String(a + b);
        block.innerHTML = `
          <legend class="px-1 text-xs font-bold text-slate-700">Security check</legend>
          <label class="flex items-center gap-2 font-semibold">
            <input data-captcha-check type="checkbox" class="h-4 w-4 accent-blue-600" />
            I am a person submitting this form
          </label>
          <label class="mt-3 flex flex-wrap items-center gap-2 text-xs font-semibold">
            <span>Quick check: ${a} + ${b} =</span>
            <input data-captcha-answer type="number" inputmode="numeric" aria-label="Answer to security question" class="w-20 rounded-lg border border-slate-300 bg-white px-2 py-2 text-sm text-slate-900" />
          </label>
          <p data-captcha-message class="mt-2 text-xs text-slate-600">Complete both checks before submitting.</p>
        `;
        const update = () => {
          const check = block.querySelector<HTMLInputElement>('[data-captcha-check]');
          const answer = block.querySelector<HTMLInputElement>('[data-captcha-answer]');
          const message = block.querySelector<HTMLElement>('[data-captcha-message]');
          const passed = Boolean(check?.checked && answer?.value.trim() && Number(answer.value) === Number(block.dataset.captchaExpected));
          form.dataset.webnovaCaptchaPassed = passed ? 'true' : 'false';
          if (message) {
            message.textContent = passed ? 'Verification complete.' : 'Complete both checks before submitting.';
            message.className = `mt-2 text-xs ${passed ? 'text-emerald-700' : 'text-slate-600'}`;
          }
        };
        block.addEventListener('input', update);
        block.addEventListener('change', update);
      }
      const submitButtons = Array.from(form.querySelectorAll<HTMLElement>('button[type="submit"], input[type="submit"], button:not([type])'));
      if (submitButtons.length) submitButtons[0].before(block);
      else form.appendChild(block);
      mountTurnstile(form);
    };

    const loadTurnstile = () => {
      if (!TURNSTILE_SITE_KEY || document.querySelector('script[data-webnova-turnstile-script]')) return;
      const script = document.createElement('script');
      script.src = 'https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit';
      script.async = true;
      script.defer = true;
      script.dataset.webnovaTurnstileScript = 'true';
      script.onload = () => document.querySelectorAll<HTMLFormElement>('form[data-webnova-secured="true"]').forEach(mountTurnstile);
      document.head.appendChild(script);
    };
    const scan = () => document.querySelectorAll<HTMLFormElement>('form').forEach(attach);
    scan();
    loadTurnstile();
    const observer = new MutationObserver(() => { scan(); loadTurnstile(); });
    observer.observe(document.documentElement, { childList: true, subtree: true });

    const onSubmit = (event: Event) => {
      const form = event.target;
      if (!(form instanceof HTMLFormElement) || form.dataset.webnovaSecured !== 'true') return;
      if (TURNSTILE_SITE_KEY && form.dataset.webnovaCaptchaPassed !== 'true') {
        event.preventDefault();
        event.stopImmediatePropagation();
        const token = form.querySelector<HTMLInputElement>('input[name="cf-turnstile-response"]')?.value;
        const message = form.querySelector<HTMLElement>('[data-turnstile-message]');
        if (!token) {
          if (message) { message.textContent = 'Please complete the Cloudflare CAPTCHA first.'; message.className = 'mt-2 text-xs font-bold text-rose-700'; }
          return;
        }
        if (form.dataset.webnovaVerifying === 'true') return;
        form.dataset.webnovaVerifying = 'true';
        if (message) message.textContent = 'Verifying security challenge…';
        fetch('/api/verify-turnstile', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ token }) })
          .then(response => response.ok ? response.json() : Promise.reject(new Error('Verification failed')))
          .then(result => {
            if (!result?.success) throw new Error('Verification failed');
            form.dataset.webnovaCaptchaPassed = 'true';
            form.requestSubmit();
          })
          .catch(() => {
            form.dataset.webnovaCaptchaPassed = 'false';
            if (message) { message.textContent = 'CAPTCHA verification failed. Please complete the challenge again.'; message.className = 'mt-2 text-xs font-bold text-rose-700'; }
            window.turnstile?.reset?.();
          })
          .finally(() => { form.dataset.webnovaVerifying = 'false'; });
        return;
      }
      if (form.dataset.webnovaCaptchaPassed !== 'true') {
        event.preventDefault();
        event.stopImmediatePropagation();
        const block = form.querySelector<HTMLElement>('[data-webnova-captcha]');
        const message = block?.querySelector<HTMLElement>('[data-captcha-message]');
        if (message) {
          message.textContent = 'Please complete the security check correctly.';
          message.className = 'mt-2 text-xs font-bold text-rose-700';
        }
        block?.scrollIntoView({ behavior: 'smooth', block: 'center' });
        return;
      }

      const fields: Record<string, string> = {};
      const data = new FormData(form);
      data.forEach((value, key) => {
        if (/password|passcode|otp|token|secret|captcha|credit.?card|cvv/i.test(key)) return;
        if (typeof value === 'string') {
          const clean = value.trim();
          if (clean) fields[key] = clean.slice(0, 4000);
        } else if (value instanceof File && value.name) {
          fields[`${key} (file)`] = value.name.slice(0, 255);
        }
      });
      const inputs = Array.from(form.querySelectorAll<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>('input, textarea, select'));
      inputs.forEach((input, index) => {
        if (input.closest('[data-webnova-captcha]')) return;
        const key = input.name || input.id || input.getAttribute('aria-label') || input.getAttribute('placeholder') || `field_${index + 1}`;
        if (!key || /password|passcode|otp|token|secret|captcha|credit.?card|cvv/i.test(key)) return;
        if (input instanceof HTMLInputElement && ['password', 'hidden', 'file', 'submit', 'button'].includes(input.type)) return;
        if (input instanceof HTMLInputElement && input.type === 'checkbox' && !input.checked) return;
        if (input instanceof HTMLInputElement && input.type === 'radio' && !input.checked) return;
        if (input.value.trim()) fields[key] = input.value.trim().slice(0, 4000);
      });
      const heading = form.querySelector('h1,h2,h3')?.textContent?.trim();
      const submission: FormSubmission = {
        id: `WN-FORM-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).slice(2, 6).toUpperCase()}`,
        submittedAt: new Date().toISOString(),
        page: window.location.pathname,
        formName: form.getAttribute('aria-label') || form.dataset.formName || heading || form.id || 'Website form',
        fields,
      };
      saveSubmission(submission);
      // With Firebase configured, also persist the non-secret submission centrally so
      // authorized administrators can review it from another device/browser.
      if (firebaseConfigured && db) {
        void addDoc(collection(db, 'formSubmissions'), {
          ...submission,
          createdAt: serverTimestamp(),
        }).catch((error) => console.error('Unable to store website form submission in Firestore:', error));
      }
    };
    document.addEventListener('submit', onSubmit, true);
    return () => {
      observer.disconnect();
      document.removeEventListener('submit', onSubmit, true);
    };
  }, []);

  return null;
}
