import React, { useMemo, useState } from 'react';
import { addDoc, collection, serverTimestamp } from 'firebase/firestore';
import { db, firebaseConfigured } from '../firebase';
import { ArrowRight, CheckCircle2, Clock3, Mail, MessageCircle, Phone, Send, Video } from 'lucide-react';

type MeetingPreference = 'Google Meet' | 'Zoom' | 'Phone Call' | 'WhatsApp Call';

export type CallBooking = {
  id: string; firestoreDocId?: string; name: string; email: string; phone: string;
  service: string; date: string; time: string; meeting: MeetingPreference; details: string;
  status: 'Pending' | 'Confirmed' | 'Contacted' | 'Completed' | 'Cancelled'; submittedAt: string;
};
export const CALL_BOOKINGS_KEY = 'webnova_call_bookings_v1';
export function readCallBookings(): CallBooking[] {
  try { const value = JSON.parse(localStorage.getItem(CALL_BOOKINGS_KEY) || '[]'); return Array.isArray(value) ? value : []; }
  catch { return []; }
}
function saveLocalBooking(booking: CallBooking) {
  const current = readCallBookings();
  localStorage.setItem(CALL_BOOKINGS_KEY, JSON.stringify([booking, ...current.filter(item => item.id !== booking.id)].slice(0, 500)));
  window.dispatchEvent(new CustomEvent('webnova-call-booking', { detail: booking }));
}

const services = [
  'Website Design & Development',
  'Mobile App Development',
  'UI/UX Design',
  'ERP / CRM / Business Systems',
  'AI Tools & Automation',
  'Digital Marketing',
  'E-commerce Development',
  'Other / Not Sure Yet',
];

const timeSlots = [
  '10:00 AM', '10:30 AM', '11:00 AM', '11:30 AM',
  '12:00 PM', '12:30 PM', '02:00 PM', '02:30 PM',
  '03:00 PM', '03:30 PM', '04:00 PM', '04:30 PM', '05:00 PM',
];

const inputClass = 'mt-1.5 block w-full min-w-0 rounded-xl border border-slate-200 bg-white px-3.5 py-3 text-sm text-slate-900 shadow-sm outline-none transition placeholder:text-slate-400 hover:border-slate-300 focus:border-blue-500 focus:ring-4 focus:ring-blue-100';
const labelClass = 'block text-[13px] font-semibold text-slate-800';

export const ScheduleCall: React.FC = () => {
  const today = useMemo(() => {
    const date = new Date();
    const local = new Date(date.getTime() - date.getTimezoneOffset() * 60000);
    return local.toISOString().slice(0, 10);
  }, []);

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [service, setService] = useState('');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [meeting, setMeeting] = useState<MeetingPreference>('Google Meet');
  const [details, setDetails] = useState('');
  const [bookingRef, setBookingRef] = useState('');

  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState('');

  const submitBooking = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!name.trim() || !email.trim() || !phone.trim() || !service || !date || !time || !details.trim()) return;

    setSaving(true);
    setSaveError('');
    const reference = `WN-CALL-${Date.now().toString().slice(-7)}`;
    const booking: CallBooking = { id: reference, name: name.trim(), email: email.trim(), phone: phone.trim(), service, date, time, meeting, details: details.trim(), status: 'Pending', submittedAt: new Date().toISOString() };
    // Keep a local fallback and persist to the shared database when Firebase is configured.
    saveLocalBooking(booking);
    if (firebaseConfigured && db) {
      try {
        const created = await addDoc(collection(db, 'callBookings'), { ...booking, createdAt: serverTimestamp(), statusUpdatedAt: serverTimestamp() });
        saveLocalBooking({ ...booking, firestoreDocId: created.id });
      } catch (error) {
        console.error('Unable to save booking to Firestore:', error);
        setSaveError('Your request is saved in this browser, but shared admin storage failed. Please contact us on WhatsApp as a backup.');
      }
    } else {
      setSaveError('Firebase is not configured yet. This request is visible only in this browser until you connect Firebase.');
    }
    setBookingRef(reference);
    const message = [
      'Hello WebNova Solutions, I would like to request a consultation.',
      `Booking reference: ${reference}`,
      `Name: ${name.trim()}`,
      `Work email: ${email.trim()}`,
      `Phone / WhatsApp: ${phone.trim()}`,
      `Service: ${service}`,
      `Preferred date: ${date}`,
      `Preferred time (IST): ${time}`,
      `Meeting preference: ${meeting}`,
      `Project details: ${details.trim()}`,
    ].join('\n');
    setSaving(false);
    window.open(`https://wa.me/918765051912?text=${encodeURIComponent(message)}`, '_blank', 'noopener,noreferrer');
  };

  return (
    <section id="schedule-call" className="relative isolate overflow-hidden bg-gradient-to-b from-[#f6f8ff] via-white to-[#f8faff] py-14 sm:py-20">
      <div aria-hidden="true" className="pointer-events-none absolute -right-32 top-12 -z-10 h-96 w-96 rounded-full bg-violet-200/45 blur-3xl" />
      <div aria-hidden="true" className="pointer-events-none absolute -left-32 bottom-0 -z-10 h-96 w-96 rounded-full bg-sky-200/40 blur-3xl" />

      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mb-9 text-center">
          <span className="inline-flex items-center gap-2 rounded-full border border-indigo-100 bg-white/90 px-4 py-2 text-xs font-bold uppercase tracking-[.16em] text-indigo-700 shadow-sm">
            <span className="h-2 w-2 animate-pulse rounded-full bg-violet-500" /> Free 15–30 minute consultation
          </span>
          <h2 className="mt-4 text-3xl font-extrabold tracking-tight text-[#071531] sm:text-5xl">Schedule a <span className="bg-gradient-to-r from-blue-600 via-indigo-600 to-violet-600 bg-clip-text text-transparent">Call</span></h2>
          <p className="mx-auto mt-3 max-w-2xl text-sm leading-6 text-slate-600 sm:text-base">Tell us what you want to build. We'll discuss your goals, recommend a practical next step, and help you plan your project.</p>
        </div>

        <div className="grid items-stretch gap-7 lg:grid-cols-[1.02fr_.98fr] lg:gap-10">
          <div className="rounded-3xl border border-slate-200/80 bg-white p-5 shadow-[0_18px_60px_-32px_rgba(37,99,235,.3)] sm:p-8 lg:p-9">
            {bookingRef ? (
              <div className="flex min-h-[540px] flex-col items-center justify-center text-center">
                <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-600"><CheckCircle2 className="h-9 w-9" /></div>
                <h3 className="mt-5 text-2xl font-extrabold text-slate-900">Your request is ready</h3>
                <p className="mt-2 max-w-md text-sm leading-6 text-slate-600">Your request has been recorded. WhatsApp can open with your booking details as a backup. Our team will confirm availability and send your meeting link after confirming the slot.</p>{saveError && <p role="status" className="mt-3 max-w-md rounded-xl border border-amber-200 bg-amber-50 p-3 text-xs leading-5 text-amber-900">{saveError}</p>}
                <div className="mt-5 rounded-xl border border-blue-100 bg-blue-50 px-5 py-3 text-sm font-bold text-blue-800">Reference: {bookingRef}</div>
                <button type="button" onClick={() => { setBookingRef(''); setName(''); setEmail(''); setPhone(''); setService(''); setDate(''); setTime(''); setMeeting('Google Meet'); setDetails(''); }} className="mt-6 rounded-xl bg-gradient-to-r from-blue-600 to-violet-600 px-5 py-3 text-sm font-bold text-white shadow-lg shadow-blue-600/20 hover:-translate-y-0.5">Book another call</button>
              </div>
            ) : (
              <>
                <div className="mb-6">
                  <p className="text-xs font-bold uppercase tracking-[.18em] text-indigo-600">Let's plan your project</p>
                  <h3 className="mt-2 text-2xl font-extrabold tracking-tight text-[#071531] sm:text-3xl">Book your consultation</h3>
                  <p className="mt-2 text-sm text-slate-500">Fill in the details below. Fields marked * are required.</p>
                </div>
                <form onSubmit={submitBooking} aria-label="Schedule a Call Booking" data-form-name="Schedule a Call Booking" className="space-y-5">
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div><label className={labelClass} htmlFor="call-name">Full name <span className="text-rose-500">*</span></label><input id="call-name" className={inputClass} autoComplete="name" required value={name} onChange={e => setName(e.target.value)} placeholder="Your full name" /></div>
                    <div><label className={labelClass} htmlFor="call-email">Work email <span className="text-rose-500">*</span></label><input id="call-email" className={inputClass} type="email" autoComplete="email" required value={email} onChange={e => setEmail(e.target.value)} placeholder="you@company.com" /></div>
                  </div>
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div><label className={labelClass} htmlFor="call-phone">Phone / WhatsApp <span className="text-rose-500">*</span></label><input id="call-phone" className={inputClass} type="tel" autoComplete="tel" required value={phone} onChange={e => setPhone(e.target.value)} placeholder="+91 87650 51912" /></div>
                    <div><label className={labelClass} htmlFor="call-service">What do you need help with? <span className="text-rose-500">*</span></label><select id="call-service" className={inputClass} required value={service} onChange={e => setService(e.target.value)}><option value="" disabled>Select a service</option>{services.map(item => <option key={item} value={item}>{item}</option>)}</select></div>
                  </div>
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div><label className={labelClass} htmlFor="call-date">Preferred date <span className="text-rose-500">*</span></label><input id="call-date" className={inputClass} type="date" min={today} required value={date} onChange={e => setDate(e.target.value)} /></div>
                    <div><label className={labelClass} htmlFor="call-time">Preferred time (IST) <span className="text-rose-500">*</span></label><select id="call-time" className={inputClass} required value={time} onChange={e => setTime(e.target.value)}><option value="" disabled>Select a time</option>{timeSlots.map(slot => <option key={slot} value={slot}>{slot}</option>)}</select></div>
                  </div>
                  <fieldset>
                    <legend className={labelClass}>Meeting preference <span className="text-rose-500">*</span></legend>
                    <div className="mt-2 grid grid-cols-2 gap-2 sm:grid-cols-4">
                      {(['Google Meet', 'Zoom', 'Phone Call', 'WhatsApp Call'] as MeetingPreference[]).map(option => (
                        <label key={option} className={`flex cursor-pointer items-center gap-2 rounded-xl border px-3 py-3 text-xs font-semibold transition ${meeting === option ? 'border-indigo-300 bg-indigo-50 text-indigo-800 ring-2 ring-indigo-100' : 'border-slate-200 bg-white text-slate-600 hover:border-slate-300'}`}>
                          <input className="h-4 w-4 accent-indigo-600" type="radio" name="meeting-preference" value={option} checked={meeting === option} onChange={() => setMeeting(option)} />
                          <span>{option}</span>
                        </label>
                      ))}
                    </div>
                  </fieldset>
                  <div><div className="flex items-center justify-between gap-3"><label className={labelClass} htmlFor="call-details">Tell us about your project <span className="text-rose-500">*</span></label><span className="text-xs text-slate-400">{details.length}/500</span></div><textarea id="call-details" className={`${inputClass} min-h-28 resize-y`} required maxLength={500} value={details} onChange={e => setDetails(e.target.value)} placeholder="What are you looking to build or improve?" /></div>
                  <button type="submit" disabled={saving} className="group flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-blue-600 via-indigo-600 to-violet-600 px-5 py-3.5 text-sm font-bold text-white shadow-lg shadow-indigo-600/20 transition hover:-translate-y-0.5 hover:shadow-xl focus:outline-none focus:ring-4 focus:ring-indigo-200"><Send className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />{saving ? 'Saving booking…' : 'Request a call'} <ArrowRight className="h-4 w-4" /></button>
                  <p className="text-center text-xs leading-5 text-slate-500">No obligation. Your details are used to respond to your consultation request.</p>
                </form>
              </>
            )}
          </div>

          <div className="flex flex-col justify-between gap-7 py-2 lg:py-5">
            <div>
              <p className="text-sm font-bold uppercase tracking-[.18em] text-indigo-600">Let's talk about your project</p>
              <h3 className="mt-4 max-w-xl text-4xl font-extrabold leading-tight tracking-tight text-[#071531] sm:text-5xl">Turn your ideas into <span className="bg-gradient-to-r from-blue-600 to-violet-600 bg-clip-text text-transparent">real solutions.</span></h3>
              <p className="mt-5 max-w-xl text-base leading-7 text-slate-600">At WebNova Solutions, we help businesses build better digital experiences through web development, UI/UX design, ERP and CRM systems, digital marketing, and AI-powered automation.</p>
              <div className="mt-7 grid gap-3 sm:grid-cols-2">
                <div className="flex items-center gap-3 rounded-2xl border border-indigo-100 bg-white/80 p-4 shadow-sm"><span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-indigo-50 text-indigo-600"><Clock3 className="h-6 w-6" /></span><div><p className="text-sm font-bold text-slate-900">15–30 minutes</p><p className="mt-1 text-xs text-slate-500">Free consultation</p></div></div>
                <div className="flex items-center gap-3 rounded-2xl border border-indigo-100 bg-white/80 p-4 shadow-sm"><span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-violet-50 text-violet-600"><Video className="h-6 w-6" /></span><div><p className="text-sm font-bold text-slate-900">Online meeting</p><p className="mt-1 text-xs text-slate-500">Meet, Zoom or phone</p></div></div>
              </div>
              <div className="mt-9">
                <h4 className="text-lg font-extrabold text-[#071531]">What to expect</h4>
                <ul className="mt-4 space-y-4 text-sm text-slate-600">
                  {['A discussion about your goals and requirements', 'Practical recommendations tailored to your business', 'An overview of possible solutions and next steps', 'No pressure and no obligation to proceed'].map(item => <li key={item} className="flex items-start gap-3"><CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-indigo-600" /><span>{item}</span></li>)}
                </ul>
              </div>
            </div>
            <div className="rounded-2xl border border-indigo-100 bg-gradient-to-br from-indigo-50/90 via-white to-violet-50/90 p-5 sm:p-6">
              <h4 className="text-lg font-extrabold text-[#071531]">Prefer to contact us directly?</h4>
              <p className="mt-1 text-sm text-slate-600">We're always happy to chat.</p>
              <div className="mt-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:gap-5">
                <a className="inline-flex items-center gap-2 text-sm font-bold text-slate-800 hover:text-indigo-700" href="tel:+918765051912"><Phone className="h-5 w-5 text-indigo-600" /> +91 87650 51912</a>
                <span className="hidden h-6 w-px bg-slate-200 sm:block" />
                <a className="inline-flex items-center gap-2 text-sm font-bold text-emerald-700 hover:text-emerald-800" href="https://wa.me/918765051912" target="_blank" rel="noreferrer"><MessageCircle className="h-5 w-5" /> Schedule through WhatsApp <ArrowRight className="h-4 w-4" /></a>
              </div>
              <a href="mailto:info@webnovasolutions.com" className="mt-4 inline-flex items-center gap-2 text-sm text-slate-600 hover:text-blue-700"><Mail className="h-4 w-4" /> info@webnovasolutions.com</a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
