import React, { useState } from 'react';
import { Send, FileText, Calendar, CheckCircle2, Clock, Video, ArrowRight } from 'lucide-react';

export const ActionHubs: React.FC = () => {
  // Form 1: Request a Service
  const [serviceName, setServiceName] = useState('');
  const [serviceEmail, setServiceEmail] = useState('');
  const [serviceType, setServiceType] = useState('Website Design');
  const [serviceSubmitted, setServiceSubmitted] = useState<string | null>(null);

  // Form 2: Request a Quotation
  const [quoteName, setQuoteName] = useState('');
  const [quoteEmail, setQuoteEmail] = useState('');
  const [quoteDetails, setQuoteDetails] = useState('');
  const [quoteResult, setQuoteResult] = useState<string | null>(null);

  // Form 4: Schedule a Call
  const [callName, setCallName] = useState('');
  const [callEmail, setCallEmail] = useState('');
  const [callDate, setCallDate] = useState(() => { const d = new Date(); d.setDate(d.getDate() + 2); return d.toISOString().slice(0, 10); });
  const [callTime, setCallTime] = useState('02:30 PM IST');
  const [callPlatform, setCallPlatform] = useState<'Zoom'|'Google Meet'|'Phone call'>('Zoom');
  const [callScheduled, setCallScheduled] = useState<string | null>(null);

  const handleServiceSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!serviceName || !serviceEmail) return;
    const ticketId = `WN-REQ-${Math.floor(1000 + Math.random() * 9000)}`;
    setServiceSubmitted(ticketId);
  };

  const handleQuoteSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quoteName || !quoteEmail || !quoteDetails) return;
    const quoteId = `WN-Q-${Math.floor(2000 + Math.random() * 8000)}`;
    setQuoteResult(quoteId);
  };

  const handleScheduleCall = (e: React.FormEvent) => {
    e.preventDefault();
    if (!callName || !callEmail) return;
    const bookingRef = `WN-CALL-${Math.floor(5000 + Math.random() * 5000)}`;
    setCallScheduled(bookingRef);
    const details = `Hello WebNova Solutions, I would like to book a 30-minute consultation.\\nName: ${callName}\\nEmail: ${callEmail}\\nDate: ${callDate}\\nTime: ${callTime}\\nPreferred meeting: ${callPlatform}\\nBooking reference: ${bookingRef}`;
    window.open(`https://wa.me/918765051912?text=${encodeURIComponent(details)}`, '_blank', 'noopener,noreferrer');
  };

  return (
    <section id="action-hub" className="py-20 relative z-10 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-14">
          <span className="text-[11px] font-bold uppercase tracking-wider text-blue-700 block mb-2">
            Action Hub
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight mb-4">
            Let’s plan your next digital move.
          </h2>
          <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
            Tell us what you need, request a tailored estimate, or reserve a free consultation with the WebNova team.
          </p>
        </div>

        {/* Focused action cards: service request, quotation, and a premium call booking experience */}
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6 items-stretch">
          {/* Panel 1: Request a Service */}
          <div className="bg-white border border-slate-200 rounded-2xl p-6 flex flex-col justify-between hover:border-blue-500/40 transition-all shadow-xl">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <Send className="w-4 h-4 text-blue-700" />
                <h3 className="text-base font-bold text-slate-900">Request a Service</h3>
              </div>
              <p className="text-xs text-slate-500 mb-5">
                Tell us what you need and we&apos;ll get back to you.
              </p>

              {serviceSubmitted ? (
                <div className="p-4 rounded-xl bg-blue-950/50 border border-blue-500/30 text-center animate-in fade-in">
                  <CheckCircle2 className="w-8 h-8 text-blue-700 mx-auto mb-2" />
                  <h4 className="text-xs font-bold text-slate-900 mb-1">Request Received!</h4>
                  <p className="text-[11px] text-slate-600 mb-2">Ticket: <span className="font-mono text-cyan-700">{serviceSubmitted}</span></p>
                  <p className="text-[10px] text-slate-500">Our senior solutions engineer will contact you within 2 business hours.</p>
                  <button
                    onClick={() => setServiceSubmitted(null)}
                    className="mt-3 text-[11px] text-blue-700 hover:underline block mx-auto"
                  >
                    Send another request
                  </button>
                </div>
              ) : (
                <form onSubmit={handleServiceSubmit} className="space-y-3.5">
                  <div>
                    <label className="text-[11px] font-medium text-slate-600 block mb-1">Name</label>
                    <input
                      type="text"
                      required
                      value={serviceName}
                      onChange={(e) => setServiceName(e.target.value)}
                      placeholder="Your Full Name"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200/80 rounded-lg text-xs text-slate-900 placeholder-slate-500 focus:outline-none focus:border-blue-500"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] font-medium text-slate-600 block mb-1">Email</label>
                    <input
                      type="email"
                      required
                      value={serviceEmail}
                      onChange={(e) => setServiceEmail(e.target.value)}
                      placeholder="name@company.com"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200/80 rounded-lg text-xs text-slate-900 placeholder-slate-500 focus:outline-none focus:border-blue-500"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] font-medium text-slate-600 block mb-1">Service Interested In</label>
                    <select
                      value={serviceType}
                      onChange={(e) => setServiceType(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200/80 rounded-lg text-xs text-slate-900 focus:outline-none focus:border-blue-500"
                    >
                      <option value="Website Design">Website Design</option>
                      <option value="Web Development">Web Development</option>
                      <option value="Business Systems / ERP">Business Systems / ERP</option>
                      <option value="Mobile App">Mobile App (iOS/Android)</option>
                      <option value="AI Automation Tools">AI Automation Tools</option>
                    </select>
                  </div>

                  <button
                    type="submit"
                    className="w-full mt-2 py-2.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs shadow-md shadow-blue-600/30 transition-colors"
                  >
                    Submit Request
                  </button>
                </form>
              )}
            </div>
          </div>

          {/* Panel 2: Request a Quotation */}
          <div id="quotation" className="bg-white border border-slate-200 rounded-2xl p-6 flex flex-col justify-between hover:border-blue-500/40 transition-all shadow-xl">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <FileText className="w-4 h-4 text-cyan-700" />
                <h3 className="text-base font-bold text-slate-900">Request a Quotation</h3>
              </div>
              <p className="text-xs text-slate-500 mb-5">
                Get a detailed quote for your project.
              </p>

              {quoteResult ? (
                <div className="p-4 rounded-xl bg-cyan-950/50 border border-cyan-500/30 text-center animate-in fade-in">
                  <CheckCircle2 className="w-8 h-8 text-cyan-700 mx-auto mb-2" />
                  <h4 className="text-xs font-bold text-slate-900 mb-1">Quotation Generated!</h4>
                  <p className="text-[11px] text-slate-600 mb-2">Reference: <span className="font-mono text-cyan-300">{quoteResult}</span></p>
                  <p className="text-[10px] text-slate-500">Our automated estimator dispatched preliminary breakdown to {quoteEmail}.</p>
                  <button
                    onClick={() => setQuoteResult(null)}
                    className="mt-3 text-[11px] text-cyan-700 hover:underline block mx-auto"
                  >
                    New quotation
                  </button>
                </div>
              ) : (
                <form onSubmit={handleQuoteSubmit} className="space-y-3.5">
                  <div>
                    <label className="text-[11px] font-medium text-slate-600 block mb-1">Name</label>
                    <input
                      type="text"
                      required
                      value={quoteName}
                      onChange={(e) => setQuoteName(e.target.value)}
                      placeholder="Your Name"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200/80 rounded-lg text-xs text-slate-900 placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] font-medium text-slate-600 block mb-1">Email</label>
                    <input
                      type="email"
                      required
                      value={quoteEmail}
                      onChange={(e) => setQuoteEmail(e.target.value)}
                      placeholder="name@domain.com"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200/80 rounded-lg text-xs text-slate-900 placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] font-medium text-slate-600 block mb-1">Project Details</label>
                    <textarea
                      required
                      rows={2}
                      value={quoteDetails}
                      onChange={(e) => setQuoteDetails(e.target.value)}
                      placeholder="Tell us about your project..."
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200/80 rounded-lg text-xs text-slate-900 placeholder-slate-500 focus:outline-none focus:border-cyan-500 resize-none"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full mt-2 py-2.5 rounded-lg bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-semibold text-xs shadow-md shadow-indigo-600/30 transition-colors"
                  >
                    Get Quotation
                  </button>
                </form>
              )}
            </div>
          </div>

          {/* Premium Schedule a Call card */}
          <div id="schedule" className="group relative isolate overflow-hidden rounded-3xl border border-indigo-400/30 bg-gradient-to-br from-[#071531] via-[#14265b] to-[#5525a8] p-6 text-white shadow-2xl shadow-indigo-950/20 transition duration-500 hover:-translate-y-1 hover:shadow-indigo-500/20 sm:p-7">
            <div aria-hidden="true" className="pointer-events-none absolute -right-16 -top-16 -z-10 h-52 w-52 rounded-full bg-cyan-400/20 blur-3xl transition duration-700 group-hover:bg-cyan-400/30" />
            <div aria-hidden="true" className="pointer-events-none absolute -bottom-20 -left-16 -z-10 h-56 w-56 rounded-full bg-violet-500/30 blur-3xl" />
            <div>
              <div className="mb-5 flex items-center justify-between gap-3">
                <div className="flex h-12 w-12 items-center justify-center rounded-2xl border border-white/15 bg-white/10 shadow-inner shadow-white/10"><Calendar className="h-6 w-6 text-cyan-200" /></div>
                <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-300/25 bg-emerald-300/10 px-3 py-1.5 text-[10px] font-bold uppercase tracking-[.16em] text-emerald-100"><span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-300" /> Free consultation</span>
              </div>
              <h3 className="text-2xl font-extrabold tracking-tight sm:text-3xl">Schedule a call</h3>
              <p className="mt-2 max-w-sm text-sm leading-6 text-blue-100/80">Bring your idea. Leave with a clearer next step.</p>
              <div className="my-5 grid grid-cols-2 gap-3 rounded-2xl border border-white/10 bg-white/[0.06] p-3">
                <div className="flex items-center gap-2 text-xs text-blue-50"><Clock className="h-4 w-4 shrink-0 text-cyan-200"/><span>30 minutes</span></div>
                <div className="flex items-center gap-2 text-xs text-blue-50"><Video className="h-4 w-4 shrink-0 text-violet-200"/><span>Zoom / Meet / Phone</span></div>
              </div>

              {callScheduled ? (
                <div className="p-4 rounded-xl bg-white/10 border border-white/15 text-center animate-in fade-in">
                  <CheckCircle2 className="w-8 h-8 text-emerald-200 mx-auto mb-2" />
                  <h4 className="text-sm font-bold text-white mb-1">Booking request created!</h4>
                  <p className="text-[11px] text-cyan-100 mb-1 font-mono">{callDate} @ {callTime}</p>
                  <p className="text-[10px] leading-5 text-blue-100/80 mb-2">WhatsApp will open with your request so our team can confirm the slot and send your meeting details.</p>
                  <button
                    onClick={() => setCallScheduled(null)}
                    className="mt-2 text-[11px] text-cyan-200 hover:underline block mx-auto"
                  >
                    Book another slot
                  </button>
                </div>
              ) : (
                <form onSubmit={handleScheduleCall} className="space-y-4">
                  <div>
                    <label className="text-[11px] font-semibold text-blue-100 block mb-1">Name</label>
                    <input
                      type="text"
                      required
                      value={callName}
                      onChange={(e) => setCallName(e.target.value)}
                      placeholder="Your Name"
                      className="w-full px-3 py-2.5 bg-white/95 border border-white/20 rounded-xl text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-cyan-300/60 focus:border-cyan-300"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] font-semibold text-blue-100 block mb-1">Email</label>
                    <input
                      type="email"
                      required
                      value={callEmail}
                      onChange={(e) => setCallEmail(e.target.value)}
                      placeholder="name@domain.com"
                      className="w-full px-3 py-2.5 bg-white/95 border border-white/20 rounded-xl text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-cyan-300/60 focus:border-cyan-300"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] font-semibold text-blue-100 block mb-1">Meeting platform</label>
                    <select value={callPlatform} onChange={(e) => setCallPlatform(e.target.value as 'Zoom'|'Google Meet'|'Phone call')} className="w-full px-3 py-2.5 bg-white/95 border border-white/20 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-cyan-300/60">
                      <option value="Zoom">Zoom meeting</option>
                      <option value="Google Meet">Google Meet</option>
                      <option value="Phone call">Phone call</option>
                    </select>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-[10px] font-semibold text-blue-100 block mb-1">Date</label>
                      <input
                        type="date"
                        min={new Date().toISOString().slice(0, 10)}
                        required
                        value={callDate}
                        onChange={(e) => setCallDate(e.target.value)}
                        className="w-full px-2.5 py-2.5 bg-white/95 border border-white/20 rounded-xl text-[11px] text-slate-900 focus:outline-none focus:ring-2 focus:ring-cyan-300/60"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] font-semibold text-blue-100 block mb-1">Time Slot</label>
                      <select
                        value={callTime}
                        onChange={(e) => setCallTime(e.target.value)}
                        className="w-full px-2 py-2.5 bg-white/95 border border-white/20 rounded-xl text-[11px] text-slate-900 focus:outline-none focus:ring-2 focus:ring-cyan-300/60"
                      >
                        <option value="11:00 AM IST">11:00 AM IST</option>
                        <option value="02:30 PM IST">02:30 PM IST</option>
                        <option value="04:00 PM IST">04:00 PM IST</option>
                        <option value="07:00 PM IST">07:00 PM IST</option>
                      </select>
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="group/btn mt-2 flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-cyan-300 via-blue-400 to-violet-400 px-4 py-3.5 text-sm font-extrabold text-[#071531] shadow-lg shadow-blue-950/25 transition duration-300 hover:brightness-110 focus:outline-none focus:ring-2 focus:ring-white/70"
                  >
                    Request my call <ArrowRight className="h-4 w-4 transition-transform group-hover/btn:translate-x-1" />
                  </button>
                </form>
              )}
              <p className="mt-4 text-center text-[10px] leading-5 text-blue-100/65">We’ll confirm your selected slot and share the meeting details. No payment required.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
