import React from 'react';
import {
  Palette, Code2, Cpu, Search, Megaphone, Mail, Users, Video,
  PenTool, Workflow, Bot, Network, ArrowUpRight, Database
} from 'lucide-react';

export const ServicesSection: React.FC = () => {
  const serviceRoutes: Record<string, string> = { 'UI/UX Design': '/services/ui-ux-design', 'Web Development': '/services/web-development', 'SEO': '/services/seo', 'Business Automations': '/services/business-automation', 'ERP Development': '/services/erp-crm', 'CRM Solutions': '/services/erp-crm', 'E-commerce': '/services/ecommerce', 'Graphic Designing': '/services/branding' };
  const services = [
    { title: 'UI/UX Design', desc: 'User research, wireframes, interactive prototypes, and polished interface design that makes every interaction feel effortless.', icon: <Palette className="w-5 h-5 text-blue-700" />, tag: 'Design' },
    { title: 'Web Development', desc: 'Responsive, accessible, fast websites and web applications built around your goals and your customers.', icon: <Code2 className="w-5 h-5 text-cyan-700" />, tag: 'Web' },
    { title: 'ERP Development', desc: 'Custom ERP systems and business dashboards to connect teams, processes, inventory, and reporting.', icon: <Database className="w-5 h-5 text-purple-700" />, tag: 'Business systems' },
    { title: 'SEO', desc: 'Technical SEO, on-page optimization, content structure, and performance improvements to help customers find you.', icon: <Search className="w-5 h-5 text-emerald-700" />, tag: 'Organic growth' },
    { title: 'Meta Ads', desc: 'Campaign strategy and creative testing for Facebook and Instagram advertising, built around measurable goals.', icon: <Megaphone className="w-5 h-5 text-indigo-700" />, tag: 'Paid marketing' },
    { title: 'Email Marketing', desc: 'Newsletters, audience segmentation, campaign journeys, and lifecycle emails that build lasting relationships.', icon: <Mail className="w-5 h-5 text-rose-700" />, tag: 'Retention' },
    { title: 'CRM Solutions', desc: 'Customer relationship management setup, sales pipelines, lead tracking, and useful team workflows.', icon: <Users className="w-5 h-5 text-sky-700" />, tag: 'Customer success' },
    { title: 'Video Editing', desc: 'Engaging edits for brand videos, social reels, explainers, ads, and product stories.', icon: <Video className="w-5 h-5 text-orange-700" />, tag: 'Video' },
    { title: 'Graphic Designing', desc: 'Brand identities, social creatives, marketing materials, presentations, and campaign graphics.', icon: <PenTool className="w-5 h-5 text-pink-700" />, tag: 'Creative' },
    { title: 'Business Automations', desc: 'Automate repetitive tasks, connect your apps, and streamline approvals, notifications, and reporting.', icon: <Workflow className="w-5 h-5 text-teal-700" />, tag: 'Automation' },
    { title: 'AI Agents', desc: 'Practical AI assistants and agents for customer support, internal knowledge, lead qualification, and operations.', icon: <Bot className="w-5 h-5 text-violet-700" />, tag: 'AI solutions' },
    { title: 'Connected Platforms', desc: 'Integrations, APIs, and cross-platform experiences that help your digital tools work together.', icon: <Network className="w-5 h-5 text-indigo-700" />, tag: 'Integrations' },
    { title: 'And Many More', desc: 'Have a unique idea or challenge? We can shape a tailored digital solution around your requirements.', icon: <Cpu className="w-5 h-5 text-slate-700" />, tag: 'Custom solutions' },
  ];

  return (
    <section id="services" className="py-20 relative z-10 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-14">
          <span className="text-[11px] font-bold uppercase tracking-wider text-blue-700 block mb-2">Our Services</span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight mb-4">What we build</h2>
          <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
            From standout design and dependable development to marketing, automation, and AI—we bring the pieces together to help your business grow.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
          {services.map((srv) => (
            <div key={srv.title} className="p-6 rounded-2xl bg-white border border-slate-200 hover:border-blue-500/50 hover:shadow-lg transition-all duration-300 flex flex-col justify-between group hover:-translate-y-1">
              <div>
                <div className="flex items-center justify-between gap-3 mb-4">
                  <div className="w-10 h-10 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-center group-hover:scale-110 transition-transform">{srv.icon}</div>
                  <span className="text-[9px] font-mono text-slate-500 bg-slate-50 px-2 py-1 rounded border border-slate-200">{srv.tag}</span>
                </div>
                <h3 className="text-base font-bold text-slate-900 mb-2 group-hover:text-blue-700 transition-colors">{srv.title}</h3>
                <p className="text-xs text-slate-600 leading-relaxed mb-6">{srv.desc}</p>
              </div>
              <a href={serviceRoutes[srv.title] || '#contact'} className="flex items-center justify-between pt-3 border-t border-slate-200 text-xs font-semibold text-blue-700 hover:text-blue-800 transition-colors">
                <span>Discuss your project</span><ArrowUpRight className="w-3.5 h-3.5" />
              </a>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
