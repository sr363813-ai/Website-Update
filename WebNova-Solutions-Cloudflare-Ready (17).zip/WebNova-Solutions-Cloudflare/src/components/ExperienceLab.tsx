import React, { useState, useEffect } from 'react';
import { LayoutGrid, BrainCircuit, Shield, Activity, RefreshCw } from 'lucide-react';

export const ExperienceLab: React.FC = () => {
  const [lastCheck, setLastCheck] = useState('Just now');
  const [latency, setLatency] = useState({ web: 24, erp: 38, api: 18 });
  const [isRefreshing, setIsRefreshing] = useState(false);

  const refreshStatus = () => {
    setIsRefreshing(true);
    setTimeout(() => {
      setLatency({
        web: Math.floor(Math.random() * 10) + 20,
        erp: Math.floor(Math.random() * 15) + 30,
        api: Math.floor(Math.random() * 8) + 14,
      });
      setLastCheck('Just now');
      setIsRefreshing(false);
    }, 600);
  };

  useEffect(() => {
    const timer = setInterval(() => {
      setLastCheck('1m ago');
    }, 60000);
    return () => clearInterval(timer);
  }, []);

  return (
    <section className="py-20 relative z-10 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-14">
          <span className="text-[11px] font-bold uppercase tracking-wider text-blue-700 block mb-2">
            Modern Experience Lab
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight mb-4">
            Build. Test. Improve.
          </h2>
          <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
            Our experience lab brings next-gen UI, intelligent insights and secure systems together for a better digital experience.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 items-stretch">
          {/* Feature 1: Glass UI System */}
          <div className="p-6 rounded-2xl bg-slate-50/50 border border-slate-200/80 backdrop-blur-xl hover:border-blue-500/30 transition-all">
            <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-700 mb-4">
              <LayoutGrid className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-slate-900 mb-2">Glass UI System</h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              Modern, beautiful, intuitive interfaces. Engineered with sub-millisecond fluid responsiveness and adaptive contrast.
            </p>
          </div>

          {/* Feature 2: Smart Decisions */}
          <div className="p-6 rounded-2xl bg-slate-50/50 border border-slate-200/80 backdrop-blur-xl hover:border-purple-500/30 transition-all">
            <div className="w-10 h-10 rounded-xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-700 mb-4">
              <BrainCircuit className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-slate-900 mb-2">Smart Decisions</h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              Data-driven insights & automation. Continuous metric evaluation to proactively tune conversions and speed.
            </p>
          </div>

          {/* Feature 3: Secure Flow */}
          <div className="p-6 rounded-2xl bg-slate-50/50 border border-slate-200/80 backdrop-blur-xl hover:border-cyan-500/30 transition-all">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-700 mb-4">
              <Shield className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-slate-900 mb-2">Secure Flow</h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              End-to-end security & compliance. Enterprise encryption, hardened headers, role guards, and automated audits.
            </p>
          </div>

          {/* Feature 4: Live System Status Card (matches screenshot) */}
          <div className="p-6 rounded-2xl bg-[#090d19] border border-blue-500/30 backdrop-blur-xl shadow-lg shadow-blue-950/40 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <Activity className="w-4 h-4 text-emerald-400" />
                  <span className="text-xs font-bold text-white uppercase tracking-wider">
                    System Status
                  </span>
                </div>
                <button
                  onClick={refreshStatus}
                  disabled={isRefreshing}
                  className="p-1 text-slate-500 hover:text-white rounded transition-colors"
                  title="Check live status"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
                </button>
              </div>

              <div className="space-y-3">
                <div className="flex items-center justify-between py-1.5 border-b border-slate-200/80">
                  <span className="text-xs text-slate-200 font-medium">Website</span>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-mono text-slate-300">{latency.web}ms</span>
                    <span className="flex items-center gap-1 text-[11px] font-semibold text-emerald-400">
                      <span className="w-2 h-2 rounded-full bg-emerald-400" />
                      Online
                    </span>
                  </div>
                </div>

                <div className="flex items-center justify-between py-1.5 border-b border-slate-200/80">
                  <span className="text-xs text-slate-200 font-medium">ERP Engine</span>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-mono text-slate-300">{latency.erp}ms</span>
                    <span className="flex items-center gap-1 text-[11px] font-semibold text-emerald-400">
                      <span className="w-2 h-2 rounded-full bg-emerald-400" />
                      Online
                    </span>
                  </div>
                </div>

                <div className="flex items-center justify-between py-1.5">
                  <span className="text-xs text-slate-200 font-medium">API Gateway</span>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-mono text-slate-300">{latency.api}ms</span>
                    <span className="flex items-center gap-1 text-[11px] font-semibold text-emerald-400">
                      <span className="w-2 h-2 rounded-full bg-emerald-400" />
                      Online
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-200/60 flex items-center justify-between text-[10px] text-slate-300 font-mono">
              <span>99.98% Global SLA</span>
              <span>Updated: {lastCheck}</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
