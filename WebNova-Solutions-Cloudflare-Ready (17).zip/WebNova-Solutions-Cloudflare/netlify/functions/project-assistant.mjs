const json = (body, status = 200) => new Response(JSON.stringify(body), {
  status,
  headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' },
});

export default async (request) => {
  if (request.method !== 'POST') return json({ error: 'Method not allowed.' }, 405);
  const apiKey = Netlify.env.get('GEMINI_API_KEY');
  if (!apiKey) return json({ error: 'AI assistant is not configured. Set GEMINI_API_KEY in the hosting environment.' }, 503);

  let input;
  try { input = await request.json(); } catch { return json({ error: 'Send a valid JSON request.' }, 400); }
  const clean = (value, max = 500) => typeof value === 'string' ? value.trim().slice(0, max) : '';
  const business = clean(input?.business, 180);
  const service = clean(input?.service, 100);
  const budget = clean(input?.budget, 80);
  const timeline = clean(input?.timeline, 80);
  const features = Array.isArray(input?.features) ? input.features.filter((v) => typeof v === 'string').slice(0, 12).map((v) => clean(v, 80)) : [];
  if (!service) return json({ error: 'Choose a project type first.' }, 400);

  const model = clean(Netlify.env.get('GEMINI_MODEL'), 80) || 'gemini-2.5-flash';
  const prompt = `You are the WebNova Solutions project discovery assistant. Help the visitor prepare for a human consultation. Do not invent company facts, portfolio results, prices, deadlines, guarantees, or claim to have inspected their systems. Clearly label any assumptions. Give a concise useful response with: (1) your understanding of the project, (2) recommended first-phase scope, (3) important questions to confirm, (4) risks or dependencies, and (5) next steps. This is guidance, not a binding quotation.\n\nBusiness: ${business || 'Not specified'}\nProject type: ${service}\nFeatures requested: ${features.join(', ') || 'Not specified'}\nBudget range: ${budget || 'Not specified'}\nTimeline: ${timeline || 'Not specified'}`;
  try {
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-goog-api-key': apiKey },
      body: JSON.stringify({ contents: [{ role: 'user', parts: [{ text: prompt }] }], generationConfig: { temperature: 0.4, maxOutputTokens: 700 } }),
      signal: AbortSignal.timeout(25000),
    });
    if (!response.ok) {
      const status = response.status === 429 ? 429 : 502;
      return json({ error: status === 429 ? 'AI usage is temporarily limited. Please try again shortly.' : 'The AI service is temporarily unavailable. Your project brief can still be prepared.' }, status);
    }
    const payload = await response.json();
    const text = payload?.candidates?.[0]?.content?.parts?.map((part) => part.text || '').join('\n').trim();
    if (!text) return json({ error: 'The AI service did not return a recommendation.' }, 502);
    return json({ text, model, generatedAt: new Date().toISOString() });
  } catch {
    return json({ error: 'The AI service could not be reached. Your project brief can still be prepared.' }, 502);
  }
};

export const config = {
  path: '/api/project-assistant',
  method: ['POST'],
  rateLimit: { action: 'rate_limit', aggregateBy: 'ip', windowSize: 60, windowLimit: 10 },
};
